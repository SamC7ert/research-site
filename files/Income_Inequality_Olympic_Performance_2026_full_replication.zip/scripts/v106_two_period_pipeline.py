#!/usr/bin/env python3
"""
v1.06 Two-Period Pipeline — SECONDARY (Robustness)
====================================================
Two-period panel analysis for Sections 7.4, 7.8, and supplementary results.
The primary analysis is game-level (v106_game_level_pipeline.py).

Identical to v1.01 — the two-period aggregation has no game-level lag
variable, so the two-lag change in the primary spec does not apply here.

Input:  ../data/v106_country_sport_panel_2period.json + ancillary data
Output: ../results/v106_two_period_results.json
"""

import json
import os
import sys
import numpy as np
import pandas as pd
from collections import defaultdict
from scipy import stats
import warnings
warnings.filterwarnings('ignore')
import statsmodels.api as sm
from statsmodels.stats.sandwich_covariance import cov_cluster

# ============================================================
# PATHS (relative)
# ============================================================
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, '..', 'data')
RESULTS_DIR = os.path.join(SCRIPT_DIR, '..', 'results')
os.makedirs(RESULTS_DIR, exist_ok=True)

# ============================================================
# LOAD DATA
# ============================================================
print("=" * 70)
print("v1.06 TWO-PERIOD PIPELINE — Secondary (Robustness)")
print("  Religion (4 vars, other=ref), GDP split >= median")
print("=" * 70)

with open(os.path.join(DATA_DIR, 'v106_country_sport_panel_2period.json')) as f:
    d1_data = json.load(f)
df1 = pd.DataFrame(d1_data)
print(f"D1 panel: {len(df1)} rows, {df1['country'].nunique()} countries, {df1['sport_name'].nunique()} sports")

with open(os.path.join(DATA_DIR, 'v106_predictors_master.json')) as f:
    predictors_raw = json.load(f)
predictors = {k: v for k, v in predictors_raw.items() if k != '_metadata'}

with open(os.path.join(DATA_DIR, 'v106_religion_classification.json')) as f:
    religion_data = json.load(f)
religion_lookup = religion_data['countries']
host_periods = religion_data['host_countries']

with open(os.path.join(DATA_DIR, 'v106_region_classification.json')) as f:
    regions_raw = json.load(f)
region_lookup = regions_raw['countries']

with open(os.path.join(DATA_DIR, 'v106_sport_cost_classification.json')) as f:
    sport_cost = json.load(f)
sport_info = sport_cost['sports']

efw_path = os.path.join(DATA_DIR, 'v106_efw_data.json')
efw_available = os.path.exists(efw_path)
if efw_available:
    with open(efw_path) as f:
        efw_data = json.load(f)
    print(f"EFW data: {len(efw_data)} countries")

# ============================================================
# HELPER FUNCTIONS
# ============================================================

def run_ols_clustered(y, X, cluster_ids, add_const=True, return_vcov=False):
    """OLS with clustered standard errors at country level."""
    if add_const:
        X = sm.add_constant(X)
    model = sm.OLS(y, X).fit()
    cluster_arr = np.array(cluster_ids)
    cov_cl = None
    try:
        cov_cl = cov_cluster(model, cluster_arr)
        se_cl = np.sqrt(np.diag(cov_cl))
        t_cl = model.params / se_cl
        p_cl = 2 * stats.t.sf(np.abs(t_cl), df=len(set(cluster_arr)) - 1)
    except:
        se_cl = model.bse
        t_cl = model.tvalues
        p_cl = model.pvalues
    cols = X.columns if hasattr(X, 'columns') else [f'x{i}' for i in range(X.shape[1])]
    result = {
        'params': dict(zip(cols, model.params)),
        'se': dict(zip(cols, se_cl)),
        'pvalues': dict(zip(cols, p_cl)),
        'r2': model.rsquared,
        'r2_adj': model.rsquared_adj,
        'n_obs': int(model.nobs),
        'n_clusters': len(set(cluster_arr)),
        'model': model,
        'df_resid': model.df_resid,
    }
    if return_vcov and cov_cl is not None:
        result['cov_cl'] = cov_cl
        result['col_names'] = list(cols)
    return result

def fmt(val, decimals=3):
    return round(float(val), decimals)

def make_sport_dummies(df, col='sport_name'):
    df = df.copy()
    sports = sorted(df[col].unique())
    cols = []
    for i, s in enumerate(sports[1:], 1):
        cname = f'sd_{i}'
        df[cname] = (df[col] == s).astype(float)
        cols.append(cname)
    return df, cols

# ============================================================
# PREPARE REGRESSION VARIABLES
# ============================================================
print("\n### Preparing regression variables ###")

df1['ln_gdp'] = np.log(df1['gdp_pc_ppp'].astype(float))
df1['ln_pop'] = np.log(df1['population'].astype(float))
df1['soviet'] = df1['soviet_legacy'].astype(float)
df1['gini'] = df1['gini'].astype(float)
df1['gdp_level_k'] = df1['gdp_pc_ppp'].astype(float) / 1000

# RELIGION variables (continuous shares)
for country in df1['country'].unique():
    rel = religion_lookup.get(country, {})
    for var in ['pct_muslim', 'pct_hindu', 'pct_buddhist', 'pct_christian']:
        df1.loc[df1['country'] == country, var] = rel.get(var, 0.0)

religion_cols = ['pct_muslim', 'pct_hindu', 'pct_buddhist', 'pct_christian']
print(f"Religion variables added: {religion_cols}")

# REGION dummies (for comparison run)
for rid in range(1, 10):
    df1[f'r{rid}'] = (df1['region_id'] == rid).astype(float)
region_cols = [f'r{i}' for i in range(1, 10)]

# Sport dummies (full panel)
sport_list = sorted(df1['sport_name'].unique())
sport_dummy_cols = []
for i, s in enumerate(sport_list[1:], 1):
    col = f's_{i}'
    df1[col] = (df1['sport_name'] == s).astype(float)
    sport_dummy_cols.append(col)

# Cost variables
df1['ln_equip'] = np.log(df1['cost_equip_eur_pr_year'].astype(float))
df1['ln_fac_marg'] = np.log(df1['cost_marginal_facility_eur'].astype(float))
df1['ln_fac_maxcomp'] = np.log(df1['cost_national_facility_eur'].astype(float))
df1['ln_ecco'] = np.log((df1['cost_equip_eur_pr_year'] + df1['coaching_annual_eur'] + df1['competition_annual_eur']).astype(float))
df1['ln_total_cost'] = np.log(df1['household_total_annual_eur'].astype(float))

# Interactions
df1['gini_x_ln_equip'] = df1['gini'] * df1['ln_equip']

# ============================================================
# GDP SPLIT: TIME-INVARIANT, >= MEDIAN
# ============================================================
# v1.04.1 fix: Compute from game-level panel (same method as game-level pipeline)
# rather than predictors_master period averages, to ensure identical country sets.
# The game-level panel uses NOC codes; this pipeline uses full country names,
# so we map via the noc->country field present in the game-level panel.
with open(os.path.join(DATA_DIR, 'v106_game_level_panel.json')) as f:
    _gl_rows = json.load(f)
_gl_reg = [r for r in _gl_rows if r.get('regression_eligible')]

_noc_to_country = {}
_gdp_by_noc = defaultdict(list)
for r in _gl_reg:
    _noc_to_country[r['noc']] = r['country']
    if r['gdp_pc_ppp'] is not None:
        _gdp_by_noc[r['noc']].append(r['gdp_pc_ppp'])

_gdp_avg_noc = {}
for noc, gdps in _gdp_by_noc.items():
    unique_gdps = list(set(gdps))  # deduplicate: one value per game-year
    _gdp_avg_noc[noc] = np.mean(unique_gdps)

gdp_median = np.median(list(_gdp_avg_noc.values()))

# Use upper_gdp_half from panel if available (single source of truth)
if _gl_reg and 'upper_gdp_half' in _gl_reg[0]:
    _upper_nocs = {r['noc'] for r in _gl_reg if r.get('upper_gdp_half')}
    gdp_avg = {_noc_to_country[noc]: g for noc, g in _gdp_avg_noc.items()}
    upper_countries = [_noc_to_country[noc] for noc in _upper_nocs if noc in _noc_to_country]
    lower_countries = [c for c in gdp_avg if c not in upper_countries]
else:
    # Fallback: compute from median
    gdp_avg = {_noc_to_country[noc]: g for noc, g in _gdp_avg_noc.items()}
    upper_countries = [c for c, g in gdp_avg.items() if g >= gdp_median]
    lower_countries = [c for c, g in gdp_avg.items() if g < gdp_median]
del _gl_rows, _gl_reg, _gdp_by_noc, _gdp_avg_noc, _noc_to_country  # free memory
print(f"GDP split (>= median, game-level method): median={gdp_median:.0f}, upper={len(upper_countries)}, lower={len(lower_countries)}")

# Host dummy
host_map = {}
for c in host_periods.get('period_1', []):
    host_map[(c, 1)] = 1
for c in host_periods.get('period_2', []):
    host_map[(c, 2)] = 1
df1['host'] = df1.apply(lambda r: host_map.get((r['country'], r['period']), 0), axis=1)

# Subsets
individual_mask = df1['sport_type'] == 'individual'
scoring_mask = df1['total_olympic_6pt'] > 0
upper_mask = df1['country'].isin(upper_countries)

print(f"Individual scoring: {(individual_mask & scoring_mask).sum()} rows")
print(f"Individual upper scoring: {(individual_mask & scoring_mask & upper_mask).sum()} rows")


# ============================================================
# RUN ALL ANALYSES WITH BOTH GALTON CONTROLS
# ============================================================

def run_full_pipeline(galton_cols, galton_label):
    """Run the complete analysis pipeline with given Galton controls."""
    print(f"\n{'='*70}")
    print(f"RUNNING FULL PIPELINE — Galton control: {galton_label}")
    print(f"  Variables: {galton_cols}")
    print(f"{'='*70}")

    R = {}

    # ----------------------------------------------------------
    # §3 AGGREGATE MODEL LADDER (Table 2)
    # ----------------------------------------------------------
    print(f"\n--- §3 Aggregate model ladder ({galton_label}) ---")

    agg = df1.groupby(['country', 'period']).agg({
        'total_olympic_6pt': 'sum',
        'gini': 'first', 'ln_gdp': 'first', 'ln_pop': 'first',
        'soviet': 'first', 'region_id': 'first', 'population': 'first',
        'gdp_level_k': 'first', 'host': 'first',
    }).reset_index()
    agg['period_f'] = agg['period'].astype(float)
    for col in galton_cols:
        agg[col] = agg['country'].map(
            df1.groupby('country')[col].first()
        )
    for rid in range(1, 10):
        agg[f'r{rid}'] = (agg['region_id'] == rid).astype(float)

    ladder = {}
    r = run_ols_clustered(agg['total_olympic_6pt'], agg[['ln_gdp', 'ln_pop', 'period_f']], agg['country'])
    ladder['M1'] = {'r2': fmt(r['r2']), 'gini_b': None, 'gini_p': None}

    r = run_ols_clustered(agg['total_olympic_6pt'], agg[['ln_gdp', 'ln_pop', 'period_f', 'gini']], agg['country'])
    ladder['M2'] = {'r2': fmt(r['r2']), 'gini_b': fmt(r['params']['gini']), 'gini_p': fmt(r['pvalues']['gini'])}

    r = run_ols_clustered(agg['total_olympic_6pt'], agg[['ln_gdp', 'ln_pop', 'period_f', 'gini', 'soviet']], agg['country'])
    ladder['M3'] = {'r2': fmt(r['r2']), 'gini_b': fmt(r['params']['gini']), 'gini_p': fmt(r['pvalues']['gini'])}

    r = run_ols_clustered(agg['total_olympic_6pt'],
        agg[['ln_gdp', 'ln_pop', 'period_f', 'gini', 'soviet'] + galton_cols], agg['country'])
    ladder['M4'] = {'r2': fmt(r['r2']), 'gini_b': fmt(r['params']['gini']), 'gini_p': fmt(r['pvalues']['gini']),
                     'n': r['n_obs']}

    for m, v in ladder.items():
        g = f"Gini β={v['gini_b']}, p={v['gini_p']}" if v['gini_b'] else ""
        print(f"  {m}: R²={v['r2']} {g}")
    R['aggregate_ladder'] = ladder

    # ----------------------------------------------------------
    # §4 SPORT-TYPE DECOMPOSITION (Table 3) + GDP×facility
    # ----------------------------------------------------------
    print(f"\n--- §4 Sport-type decomposition ({galton_label}) ---")

    type_results = {}
    for cost_label, cost_col in [('equipment', 'ln_equip')]:
        for type_label, type_filter in [('All', None), ('Individual', 'individual'), ('Team', 'team'), ('Duel', 'duel')]:
            for sample_label, country_filter in [('Full', None), ('Upper', upper_countries)]:
                sub = df1[df1['simulation_eligible']].copy()
                if type_filter:
                    sub = sub[sub['sport_type'] == type_filter]
                if country_filter:
                    sub = sub[sub['country'].isin(country_filter)]
                # POSITIVE-POINTS FILTER
                sub = sub[sub['total_olympic_6pt'] > 0].copy().reset_index(drop=True)
                if len(sub) < 30:
                    continue

                sub['gini_x_cost'] = sub['gini'] * sub[cost_col]
                sub, s_cols = make_sport_dummies(sub)

                X = sub[['ln_gdp', 'ln_pop', 'period', 'soviet', 'gini', 'gini_x_cost'] + galton_cols + s_cols]
                res = run_ols_clustered(sub['total_olympic_6pt'], X, sub['country'])
                key = f'{type_label}_{sample_label}'
                type_results[key] = {
                    'gini_x_cost_b': fmt(res['params']['gini_x_cost']),
                    'gini_x_cost_p': fmt(res['pvalues']['gini_x_cost']),
                    'gini_b': fmt(res['params']['gini']),
                    'gini_p': fmt(res['pvalues']['gini']),
                    'n': res['n_obs'],
                    'n_clusters': res['n_clusters'],
                }
                print(f"  {key:20s} n={res['n_obs']:5d} Gini×equip={res['params']['gini_x_cost']:+.4f} p={res['pvalues']['gini_x_cost']:.4f}")

    R['sport_type_decomposition'] = type_results

    # GDP × facility
    facility_results = {}
    for fac_label, fac_col in [('marginal', 'ln_fac_marg'), ('maxcomp', 'ln_fac_maxcomp')]:
        for label, type_filter, country_filter in [
            ('Ind Full', 'individual', None), ('Ind Upper', 'individual', upper_countries), ('Ind Lower', 'individual', lower_countries)]:
            sub = df1[(df1['simulation_eligible']) & (df1['sport_type'] == type_filter)].copy()
            if country_filter:
                sub = sub[sub['country'].isin(country_filter)]
            # POSITIVE-POINTS FILTER
            sub = sub[sub['total_olympic_6pt'] > 0].copy().reset_index(drop=True)
            sub['gdp_x_fac'] = sub['ln_gdp'] * sub[fac_col]
            sub['gini_x_fac'] = sub['gini'] * sub[fac_col]
            sub, s_cols = make_sport_dummies(sub)
            res_gdp = run_ols_clustered(sub['total_olympic_6pt'],
                sub[['ln_gdp', 'ln_pop', 'period', 'soviet', 'gini', 'gdp_x_fac'] + galton_cols + s_cols],
                sub['country'])
            res_gini = run_ols_clustered(sub['total_olympic_6pt'],
                sub[['ln_gdp', 'ln_pop', 'period', 'soviet', 'gini', 'gini_x_fac'] + galton_cols + s_cols],
                sub['country'])
            key = f'{fac_label}_{label}'
            facility_results[key] = {
                'gdp_x_fac': {'b': fmt(res_gdp['params']['gdp_x_fac']), 'p': fmt(res_gdp['pvalues']['gdp_x_fac'])},
                'gini_x_fac': {'b': fmt(res_gini['params']['gini_x_fac']), 'p': fmt(res_gini['pvalues']['gini_x_fac'])},
                'n': res_gdp['n_obs'],
            }
        print(f"  GDP×fac({fac_label}) Ind Upper: β={facility_results[f'{fac_label}_Ind Upper']['gdp_x_fac']['b']}, p={facility_results[f'{fac_label}_Ind Upper']['gdp_x_fac']['p']}")
    R['facility_standalone'] = facility_results

    # ----------------------------------------------------------
    # §5 COST GRADIENT + CROSSOVER (Tables 4-5)
    # ----------------------------------------------------------
    print(f"\n--- §5 Cost gradient + crossover ({galton_label}) ---")

    gradient_results = {}
    for cost_label, cost_col in [('equipment', 'ln_equip'), ('ecco', 'ln_ecco'), ('total', 'ln_total_cost')]:
        for label, country_filter in [('Ind Full', None), ('Ind Upper', upper_countries)]:
            # POSITIVE-POINTS FILTER
            sub = df1[(df1['simulation_eligible']) & (df1['sport_type'] == 'individual') & (df1['total_olympic_6pt'] > 0)].copy()
            if country_filter:
                sub = sub[sub['country'].isin(country_filter)]
            sub = sub.reset_index(drop=True)
            sub['gini_x_cost'] = sub['gini'] * sub[cost_col]
            sub, s_cols = make_sport_dummies(sub)
            X = sub[['ln_gdp', 'ln_pop', 'period', 'soviet', 'gini', 'gini_x_cost'] + galton_cols + s_cols]
            res = run_ols_clustered(sub['total_olympic_6pt'], X, sub['country'])
            key = f'{cost_label}_{label}'
            gradient_results[key] = {
                'b': fmt(res['params']['gini_x_cost']), 'se': fmt(res['se']['gini_x_cost']),
                'p': fmt(res['pvalues']['gini_x_cost']), 'n': res['n_obs'],
            }
            if cost_label == 'equipment':
                print(f"  {key:25s} n={res['n_obs']:5d} β={res['params']['gini_x_cost']:+.4f} p={res['pvalues']['gini_x_cost']:.4f}")
    R['cost_gradient'] = gradient_results

    # Crossover analysis (equipment only, delta method)
    crossover_results = {}
    for label, country_filter in [('Ind Full', None), ('Ind Upper', upper_countries)]:
        sub = df1[(df1['simulation_eligible']) & (df1['sport_type'] == 'individual') & (df1['total_olympic_6pt'] > 0)].copy()
        if country_filter:
            sub = sub[sub['country'].isin(country_filter)]
        sub = sub.reset_index(drop=True)
        sub['gini_x_cost'] = sub['gini'] * sub['ln_equip']
        sub, s_cols = make_sport_dummies(sub)
        X_cols = ['ln_gdp', 'ln_pop', 'period', 'soviet', 'gini', 'gini_x_cost'] + galton_cols + s_cols
        res = run_ols_clustered(sub['total_olympic_6pt'], sub[X_cols], sub['country'], return_vcov=True)

        gini_b = res['params']['gini']
        inter_b = res['params']['gini_x_cost']
        gini_se = res['se']['gini']
        inter_se = res['se']['gini_x_cost']

        col_names = res.get('col_names', [])
        cov_gi = 0
        if res.get('cov_cl') is not None and 'gini' in col_names and 'gini_x_cost' in col_names:
            gi = col_names.index('gini')
            ii = col_names.index('gini_x_cost')
            cov_gi = res['cov_cl'][gi, ii]

        if inter_b != 0:
            cross_ln = -gini_b / inter_b
            cross_eur = np.exp(cross_ln)
            d_m = -1 / inter_b
            d_i = gini_b / (inter_b**2)
            var_c = d_m**2 * gini_se**2 + d_i**2 * inter_se**2 + 2*d_m*d_i*cov_gi
            se_c = np.sqrt(max(var_c, 0))
            ci_lo = np.exp(cross_ln - 1.96*se_c)
            ci_hi = np.exp(cross_ln + 1.96*se_c)
        else:
            cross_eur = ci_lo = ci_hi = None

        cost_points = [300, 500, 650, 1000, 1400, 2000, 4000, 10000, 50000]
        effects = []
        for cost in cost_points:
            ln_c = np.log(cost)
            total_eff = gini_b + inter_b * ln_c
            var_t = gini_se**2 + ln_c**2 * inter_se**2 + 2*ln_c*cov_gi
            se_t = np.sqrt(max(var_t, 0))
            n_cl = len(sub['country'].unique())
            t_s = total_eff / se_t if se_t > 0 else 0
            p_v = 2*stats.t.sf(abs(t_s), df=n_cl-1) if se_t > 0 else 1
            effects.append({'cost': cost, 'effect': fmt(total_eff), 'p': fmt(p_v), 'sig05': p_v < 0.05})

        crossover_results[label] = {
            'gini_main_b': fmt(gini_b), 'gini_inter_b': fmt(inter_b),
            'gini_main_p': fmt(res['pvalues']['gini']), 'gini_inter_p': fmt(res['pvalues']['gini_x_cost']),
            'crossover_eur': fmt(cross_eur) if cross_eur else None,
            'crossover_ci': [fmt(ci_lo), fmt(ci_hi)] if ci_lo else None,
            'cost_point_effects': effects, 'n': res['n_obs'],
        }
        if cross_eur:
            print(f"  Crossover {label}: €{cross_eur:,.0f} (CI: €{ci_lo:,.0f}–€{ci_hi:,.0f})")
    R['crossover'] = crossover_results

    # ----------------------------------------------------------
    # §5/§7 HORSE RACE + FOUR-WAY
    # ----------------------------------------------------------
    print(f"\n--- §7.6 Horse race + four-way ({galton_label}) ---")

    horse_race = {}
    four_way = {}
    for fac_label, fac_col in [('marginal', 'ln_fac_marg'), ('maxcomp', 'ln_fac_maxcomp')]:
        for cost_label, cost_col in [('equipment', 'ln_equip'), ('ecco', 'ln_ecco'), ('total', 'ln_total_cost')]:
            for label, country_filter in [('Ind Full', None), ('Ind Upper', upper_countries)]:
                sub = df1[(df1['simulation_eligible']) & (df1['sport_type'] == 'individual') & (df1['total_olympic_6pt'] > 0)].copy()
                if country_filter:
                    sub = sub[sub['country'].isin(country_filter)]
                sub = sub.reset_index(drop=True)
                sub['gini_x_cost'] = sub['gini'] * sub[cost_col]
                sub['gdp_x_fac'] = sub['ln_gdp'] * sub[fac_col]
                sub['gini_x_fac'] = sub['gini'] * sub[fac_col]
                sub['gdp_x_cost'] = sub['ln_gdp'] * sub[cost_col]
                sub, s_cols = make_sport_dummies(sub)

                X_alone = sub[['ln_gdp', 'ln_pop', 'period', 'soviet', 'gini', 'gini_x_cost'] + galton_cols + s_cols]
                r_alone = run_ols_clustered(sub['total_olympic_6pt'], X_alone, sub['country'])

                X_both = sub[['ln_gdp', 'ln_pop', 'period', 'soviet', 'gini', 'gini_x_cost', 'gdp_x_fac'] + galton_cols + s_cols]
                r_both = run_ols_clustered(sub['total_olympic_6pt'], X_both, sub['country'])

                g_alone = r_alone['params']['gini_x_cost']
                g_joint = r_both['params']['gini_x_cost']
                atten = ((g_joint - g_alone) / abs(g_alone)) * 100 if g_alone != 0 else 0

                hk = f'{fac_label}_{cost_label}_{label}'
                horse_race[hk] = {
                    'gini_alone': {'b': fmt(g_alone), 'p': fmt(r_alone['pvalues']['gini_x_cost'])},
                    'gini_joint': {'b': fmt(g_joint), 'p': fmt(r_both['pvalues']['gini_x_cost'])},
                    'gdp_x_fac': {'b': fmt(r_both['params']['gdp_x_fac']), 'p': fmt(r_both['pvalues']['gdp_x_fac'])},
                    'attenuation_pct': fmt(atten, 1), 'n': r_both['n_obs'],
                }

                inter_vars = ['gini_x_cost', 'gini_x_fac', 'gdp_x_cost', 'gdp_x_fac']
                X_4 = sub[['ln_gdp', 'ln_pop', 'period', 'soviet', 'gini'] + inter_vars + galton_cols + s_cols]
                r_4 = run_ols_clustered(sub['total_olympic_6pt'], X_4, sub['country'])
                four_way[hk] = {v: {'b': fmt(r_4['params'][v]), 'p': fmt(r_4['pvalues'][v])} for v in inter_vars}
                four_way[hk]['n'] = r_4['n_obs']

    for fac in ['marginal', 'maxcomp']:
        k = f'{fac}_equipment_Ind Upper'
        hr = horse_race[k]
        print(f"  HR {fac} upper: alone={hr['gini_alone']['b']}(p={hr['gini_alone']['p']}) joint={hr['gini_joint']['b']}(p={hr['gini_joint']['p']}) atten={hr['attenuation_pct']}%")

    R['horse_race'] = horse_race
    R['four_way'] = four_way

    # ----------------------------------------------------------
    # §6 GENDER DECOMPOSITION (Tables 6-8)
    # ----------------------------------------------------------
    print(f"\n--- §6 Gender decomposition ({galton_label}) ---")

    gender_results = {}
    for gender_label, pts_col in [('men', 'olympic_6pt_men'), ('women', 'olympic_6pt_women')]:
        for fac_label, fac_col in [('marginal', 'ln_fac_marg'), ('maxcomp', 'ln_fac_maxcomp')]:
            for label, country_filter in [('Ind Full', None), ('Ind Upper', upper_countries)]:
                # POSITIVE-POINTS FILTER: filter on gender-specific points
                sub = df1[(df1['simulation_eligible']) & (df1['sport_type'] == 'individual') & (df1[pts_col] > 0)].copy()
                if country_filter:
                    sub = sub[sub['country'].isin(country_filter)]
                sub = sub.reset_index(drop=True)
                sub['gini_x_cost'] = sub['gini'] * sub['ln_equip']
                sub['gdp_x_fac'] = sub['ln_gdp'] * sub[fac_col]
                sub, s_cols = make_sport_dummies(sub)
                X = sub[['ln_gdp', 'ln_pop', 'period', 'soviet', 'gini', 'gini_x_cost', 'gdp_x_fac'] + galton_cols + s_cols]
                res = run_ols_clustered(sub[pts_col], X, sub['country'])
                gk = f'{gender_label}_{fac_label}_{label}'
                gender_results[gk] = {
                    'gini_x_cost': {'b': fmt(res['params']['gini_x_cost']), 'p': fmt(res['pvalues']['gini_x_cost'])},
                    'gdp_x_fac': {'b': fmt(res['params']['gdp_x_fac']), 'p': fmt(res['pvalues']['gdp_x_fac'])},
                    'n': res['n_obs'],
                    'n_clusters': res['n_clusters'],
                }
    for g in ['men', 'women']:
        k = f'{g}_marginal_Ind Upper'
        print(f"  {g} upper marg: Gini×eq={gender_results[k]['gini_x_cost']['b']}(p={gender_results[k]['gini_x_cost']['p']})")
    R['gender'] = gender_results

    # GGI model ladder
    ggi_results = {}
    agg_ggi = agg.copy()
    agg_ggi['ggi'] = agg_ggi['country'].map(
        df1[df1['ggi'].notna()].groupby('country')['ggi'].first()
    )
    agg_ggi = agg_ggi[agg_ggi['ggi'].notna()].copy()
    if len(agg_ggi) > 20:
        for step_label, X_cols in [
            ('GGI_only', ['ln_gdp', 'ln_pop', 'period_f', 'ggi']),
            ('GGI+Soviet', ['ln_gdp', 'ln_pop', 'period_f', 'ggi', 'soviet']),
            ('GGI+Galton', ['ln_gdp', 'ln_pop', 'period_f', 'ggi', 'soviet'] + galton_cols),
            ('GGI+Gini+Galton', ['ln_gdp', 'ln_pop', 'period_f', 'ggi', 'gini', 'soviet'] + galton_cols),
        ]:
            valid = agg_ggi[X_cols + ['total_olympic_6pt']].notna().all(axis=1)
            df_v = agg_ggi[valid]
            r = run_ols_clustered(df_v['total_olympic_6pt'], df_v[X_cols], df_v['country'])
            ggi_results[step_label] = {
                'ggi_b': fmt(r['params']['ggi']), 'ggi_p': fmt(r['pvalues']['ggi']),
                'gini_b': fmt(r['params'].get('gini', 0)), 'gini_p': fmt(r['pvalues'].get('gini', 1)),
                'r2': fmt(r['r2']), 'n': r['n_obs'],
            }
        print(f"  GGI+Galton: β={ggi_results['GGI+Galton']['ggi_b']}, p={ggi_results['GGI+Galton']['ggi_p']}")
    R['ggi_ladder'] = ggi_results

    # ----------------------------------------------------------
    # §7 ROBUSTNESS
    # ----------------------------------------------------------
    print(f"\n--- §7 Robustness ({galton_label}) ---")

    robustness = {}

    # Period robustness (§7.5)
    for period in [1, 2]:
        for label, country_filter in [('Ind Full', None), ('Ind Upper', upper_countries)]:
            sub = df1[(df1['simulation_eligible']) & (df1['sport_type'] == 'individual') &
                       (df1['period'] == period) & (df1['total_olympic_6pt'] > 0)].copy()
            if country_filter:
                sub = sub[sub['country'].isin(country_filter)]
            sub = sub.reset_index(drop=True)
            sub['gini_x_cost'] = sub['gini'] * sub['ln_equip']
            sub, s_cols = make_sport_dummies(sub)
            X = sub[['ln_gdp', 'ln_pop', 'soviet', 'gini', 'gini_x_cost'] + galton_cols + s_cols]
            res = run_ols_clustered(sub['total_olympic_6pt'], X, sub['country'])
            robustness[f'period_P{period}_{label}'] = {
                'b': fmt(res['params']['gini_x_cost']), 'p': fmt(res['pvalues']['gini_x_cost']), 'n': res['n_obs']}
            print(f"  P{period} {label}: β={res['params']['gini_x_cost']:+.4f} p={res['pvalues']['gini_x_cost']:.4f}")

    # With-zeros OLS
    for label, country_filter in [('Ind Full', None), ('Ind Upper', upper_countries)]:
        sub = df1[(df1['simulation_eligible']) & (df1['sport_type'] == 'individual')].copy()
        if country_filter:
            sub = sub[sub['country'].isin(country_filter)]
        sub = sub.reset_index(drop=True)
        sub['gini_x_cost'] = sub['gini'] * sub['ln_equip']
        sub, s_cols = make_sport_dummies(sub)
        X = sub[['ln_gdp', 'ln_pop', 'period', 'soviet', 'gini', 'gini_x_cost'] + galton_cols + s_cols]
        res = run_ols_clustered(sub['total_olympic_6pt'], X, sub['country'])
        robustness[f'with_zeros_{label}'] = {
            'b': fmt(res['params']['gini_x_cost']), 'p': fmt(res['pvalues']['gini_x_cost']), 'n': res['n_obs']}

    # Soviet split
    for legacy_label, legacy_val in [('soviet', True), ('non_soviet', False)]:
        sub = df1[(df1['simulation_eligible']) & (df1['sport_type'] == 'individual') &
                   (df1['soviet_legacy'] == legacy_val) & (df1['total_olympic_6pt'] > 0)].copy()
        sub = sub.reset_index(drop=True)
        sub['gini_x_cost'] = sub['gini'] * sub['ln_equip']
        sub, s_cols = make_sport_dummies(sub)
        X = sub[['ln_gdp', 'ln_pop', 'period', 'gini', 'gini_x_cost'] + galton_cols + s_cols]
        res = run_ols_clustered(sub['total_olympic_6pt'], X, sub['country'])
        robustness[f'{legacy_label}_split'] = {
            'b': fmt(res['params']['gini_x_cost']), 'p': fmt(res['pvalues']['gini_x_cost']), 'n': res['n_obs']}

    R['robustness'] = robustness

    # Per-sport betas
    per_sport = []
    for sport in sport_list:
        for sample_label, country_filter in [('full', None), ('upper', upper_countries)]:
            sub = df1[(df1['sport_name'] == sport) & (df1['total_olympic_6pt'] > 0)].copy()
            if country_filter:
                sub = sub[sub['country'].isin(country_filter)]
            if sub['country'].nunique() < 5:
                continue
            X = sub[['ln_gdp', 'ln_pop', 'period', 'soviet', 'gini'] + galton_cols]
            try:
                res = run_ols_clustered(sub['total_olympic_6pt'], X, sub['country'])
                si = sport_info.get(sport, {})
                per_sport.append({
                    'sport_name': sport, 'sample': sample_label, 'type': si.get('sport_type', ''),
                    'equip_cost': si.get('equipment_annual_eur', 0),
                    'gini_b': fmt(res['params']['gini']), 'gini_p': fmt(res['pvalues']['gini']),
                    'n': res['n_obs'],
                })
            except:
                pass
    R['per_sport_betas'] = per_sport
    print(f"  Per-sport regressions: {len(per_sport)}")

    # ----------------------------------------------------------
    # §8.5 PER-CAPITA DISSECTION (Table 9)
    # ----------------------------------------------------------
    print(f"\n--- §8.5 Per-capita dissection ({galton_label}) ---")

    pc_results = {}

    # Fix #3: Population elasticity uses ln(total_olympic_6pt) NOT ln(total_olympic_6pt + 1).
    # Filter to positive total points first.
    agg_pos = agg[agg['total_olympic_6pt'] > 0].copy()
    agg_pos['ln_total_olympic_6pt'] = np.log(agg_pos['total_olympic_6pt'])

    X_e = agg_pos[['ln_gdp', 'ln_pop', 'gini', 'soviet', 'period_f'] + galton_cols]
    r_log = run_ols_clustered(agg_pos['ln_total_olympic_6pt'], X_e, agg_pos['country'])
    alpha = r_log['params']['ln_pop']
    alpha_se = r_log['se']['ln_pop']
    t_not1 = (alpha - 1) / alpha_se
    p_not1 = 2*stats.t.sf(abs(t_not1), df=agg_pos['country'].nunique()-1)
    pc_results['pop_elasticity'] = {'alpha': fmt(alpha), 'se': fmt(alpha_se), 'p_not_1': fmt(p_not1)}
    print(f"  Pop elasticity α = {alpha:.3f} (SE={alpha_se:.3f}), differs from 1: p={p_not1:.3f}")

    # Table 9: alternative pop specs (use full agg for these since they use total_olympic_6pt directly)
    agg['points_pc'] = agg['total_olympic_6pt'] / (agg['population'] / 1e6)
    agg['points_adj'] = agg['total_olympic_6pt'] / ((agg['population'] / 1e6) ** alpha)
    X_pc = ['ln_gdp', 'gini', 'soviet', 'period_f'] + galton_cols
    X_total = ['ln_gdp', 'ln_pop', 'gini', 'soviet', 'period_f'] + galton_cols

    r_free = run_ols_clustered(agg['total_olympic_6pt'], agg[X_total], agg['country'])
    r_pc = run_ols_clustered(agg['points_pc'], agg[X_pc], agg['country'])
    r_adj = run_ols_clustered(agg['points_adj'], agg[X_pc], agg['country'])

    # Pop quartile dummies
    agg['pop_q'] = pd.qcut(agg['population'], 4, labels=False)
    for q in range(1, 4):
        agg[f'pq{q}'] = (agg['pop_q'] == q).astype(float)
    pq_cols = [f'pq{q}' for q in range(1, 4)]
    r_qd = run_ols_clustered(agg['total_olympic_6pt'], agg[['ln_gdp'] + pq_cols + ['gini', 'soviet', 'period_f'] + galton_cols], agg['country'])

    pc_results['table9'] = {
        'free_pop': {'gini_b': fmt(r_free['params']['gini']), 'gini_p': fmt(r_free['pvalues']['gini'])},
        'per_capita': {'gini_b': fmt(r_pc['params']['gini']), 'gini_p': fmt(r_pc['pvalues']['gini'])},
        'pop_adjusted': {'gini_b': fmt(r_adj['params']['gini']), 'gini_p': fmt(r_adj['pvalues']['gini']), 'alpha': fmt(alpha)},
        'pop_quartile': {'gini_b': fmt(r_qd['params']['gini']), 'gini_p': fmt(r_qd['pvalues']['gini'])},
    }
    for k, v in pc_results['table9'].items():
        print(f"  {k:20s}: Gini β={v['gini_b']}, p={v['gini_p']}")
    R['percapita_dissection'] = pc_results

    # ----------------------------------------------------------
    # §8.6 EFW, MUNDLAK, HOST
    # ----------------------------------------------------------
    print(f"\n--- §8.6 EFW / Mundlak / Host ({galton_label}) ---")

    supp_results = {}

    # Host effect
    r_no = run_ols_clustered(agg['total_olympic_6pt'],
        agg[['ln_gdp', 'ln_pop', 'gini', 'soviet', 'period_f'] + galton_cols], agg['country'])
    r_host = run_ols_clustered(agg['total_olympic_6pt'],
        agg[['ln_gdp', 'ln_pop', 'gini', 'soviet', 'host', 'period_f'] + galton_cols], agg['country'])
    supp_results['host_aggregate'] = {
        'gini_no_host': {'b': fmt(r_no['params']['gini']), 'p': fmt(r_no['pvalues']['gini'])},
        'gini_with_host': {'b': fmt(r_host['params']['gini']), 'p': fmt(r_host['pvalues']['gini'])},
        'host': {'b': fmt(r_host['params']['host']), 'p': fmt(r_host['pvalues']['host'])},
    }
    print(f"  Host aggregate: β={supp_results['host_aggregate']['host']['b']}, p={supp_results['host_aggregate']['host']['p']}")

    # Host in cost gradient
    for label, country_filter in [('Ind Full', None), ('Ind Upper', upper_countries)]:
        sub = df1[(df1['simulation_eligible']) & (df1['sport_type'] == 'individual') & (df1['total_olympic_6pt'] > 0)].copy()
        if country_filter:
            sub = sub[sub['country'].isin(country_filter)]
        sub = sub.reset_index(drop=True)
        sub['gini_x_cost'] = sub['gini'] * sub['ln_equip']
        sub, s_cols = make_sport_dummies(sub)
        X_h = sub[['ln_gdp', 'ln_pop', 'gini', 'gini_x_cost', 'host', 'period', 'soviet'] + galton_cols + s_cols]
        r_h = run_ols_clustered(sub['total_olympic_6pt'], X_h, sub['country'])
        supp_results[f'host_gradient_{label}'] = {
            'gini_x_equip': {'b': fmt(r_h['params']['gini_x_cost']), 'p': fmt(r_h['pvalues']['gini_x_cost'])},
            'host': {'b': fmt(r_h['params']['host']), 'p': fmt(r_h['pvalues']['host'])},
        }

    # Mundlak means
    country_means = df1.groupby('country').agg({
        'ln_gdp': 'mean', 'gini': 'mean', 'ln_pop': 'mean',
    }).rename(columns={'ln_gdp': 'mean_ln_gdp', 'gini': 'mean_gini', 'ln_pop': 'mean_ln_pop'})
    mundlak_cols = ['mean_ln_gdp', 'mean_gini', 'mean_ln_pop']
    df1_m = df1.merge(country_means, on='country', how='left', suffixes=('', '_mund'))

    for label, country_filter in [('Ind Full', None), ('Ind Upper', upper_countries)]:
        sub = df1_m[(df1_m['simulation_eligible']) & (df1_m['sport_type'] == 'individual') & (df1_m['total_olympic_6pt'] > 0)].copy()
        if country_filter:
            sub = sub[sub['country'].isin(country_filter)]
        sub = sub.reset_index(drop=True)
        sub['gini_x_cost'] = sub['gini'] * sub['ln_equip']
        sub, s_cols = make_sport_dummies(sub)

        X_no = sub[['ln_gdp', 'ln_pop', 'gini', 'gini_x_cost', 'period', 'soviet'] + galton_cols + s_cols]
        r_no = run_ols_clustered(sub['total_olympic_6pt'], X_no, sub['country'])

        X_mu = sub[['ln_gdp', 'ln_pop', 'gini', 'gini_x_cost', 'period', 'soviet'] + mundlak_cols + galton_cols + s_cols]
        r_mu = run_ols_clustered(sub['total_olympic_6pt'], X_mu, sub['country'])

        supp_results[f'mundlak_{label}'] = {
            'no_mundlak': {'b': fmt(r_no['params']['gini_x_cost']), 'p': fmt(r_no['pvalues']['gini_x_cost'])},
            'with_mundlak': {'b': fmt(r_mu['params']['gini_x_cost']), 'p': fmt(r_mu['pvalues']['gini_x_cost']),
                            'mean_gini_p': fmt(r_mu['pvalues']['mean_gini'])},
        }
        print(f"  Mundlak {label}: no={supp_results[f'mundlak_{label}']['no_mundlak']['b']}(p={supp_results[f'mundlak_{label}']['no_mundlak']['p']}) with={supp_results[f'mundlak_{label}']['with_mundlak']['b']}(p={supp_results[f'mundlak_{label}']['with_mundlak']['p']})")

    # EFW
    if efw_available:
        efw_lookup = {}
        for cn, info in efw_data.items():
            efw_lookup[(cn, 1)] = info.get('efw_p1')
            efw_lookup[(cn, 2)] = info.get('efw_p2')
        agg['efw'] = agg.apply(lambda r: efw_lookup.get((r['country'], r['period'])), axis=1)
        agg_efw = agg[agg['efw'].notna()].copy()

        if len(agg_efw) > 20:
            r_efw = run_ols_clustered(agg_efw['total_olympic_6pt'],
                agg_efw[['ln_gdp', 'ln_pop', 'gini', 'soviet', 'efw', 'period_f'] + galton_cols], agg_efw['country'])
            supp_results['efw_aggregate'] = {
                'efw_b': fmt(r_efw['params']['efw']), 'efw_p': fmt(r_efw['pvalues']['efw']),
                'gini_b': fmt(r_efw['params']['gini']), 'gini_p': fmt(r_efw['pvalues']['gini']),
                'n': r_efw['n_obs'],
            }
            print(f"  EFW aggregate: β={supp_results['efw_aggregate']['efw_b']}, p={supp_results['efw_aggregate']['efw_p']}")

            df1['efw'] = df1.apply(lambda r: efw_lookup.get((r['country'], r['period'])), axis=1)
            for label, country_filter in [('Ind Upper', upper_countries)]:
                sub = df1[(df1['simulation_eligible']) & (df1['sport_type'] == 'individual') &
                           (df1['total_olympic_6pt'] > 0) & (df1['efw'].notna())].copy()
                if country_filter:
                    sub = sub[sub['country'].isin(country_filter)]
                sub = sub.reset_index(drop=True)
                sub['gini_x_cost'] = sub['gini'] * sub['ln_equip']
                sub['efw_x_equip'] = sub['efw'] * sub['ln_equip']
                sub, s_cols = make_sport_dummies(sub)
                X = sub[['ln_gdp', 'ln_pop', 'gini', 'gini_x_cost', 'efw', 'efw_x_equip', 'period', 'soviet'] + galton_cols + s_cols]
                res = run_ols_clustered(sub['total_olympic_6pt'], X, sub['country'])
                supp_results[f'efw_gradient_{label}'] = {
                    'gini_x_equip': {'b': fmt(res['params']['gini_x_cost']), 'p': fmt(res['pvalues']['gini_x_cost'])},
                    'efw_x_equip': {'b': fmt(res['params']['efw_x_equip']), 'p': fmt(res['pvalues']['efw_x_equip'])},
                }
                print(f"  EFW×equip {label}: β={supp_results[f'efw_gradient_{label}']['efw_x_equip']['b']}, p={supp_results[f'efw_gradient_{label}']['efw_x_equip']['p']}")

    R['supplementary'] = supp_results

    # GDP specification sensitivity
    print(f"\n--- GDP spec sensitivity ({galton_label}) ---")
    gdp_spec = {}
    for label, country_filter in [('Ind Full', None), ('Ind Upper', upper_countries)]:
        sub = df1[(df1['simulation_eligible']) & (df1['sport_type'] == 'individual') & (df1['total_olympic_6pt'] > 0)].copy()
        if country_filter:
            sub = sub[sub['country'].isin(country_filter)]
        sub = sub.reset_index(drop=True)
        sub['gini_x_cost'] = sub['gini'] * sub['ln_equip']
        sub, s_cols = make_sport_dummies(sub)
        for gdp_var, gdp_label in [('ln_gdp', 'ln_GDP'), ('gdp_level_k', 'GDP_levels')]:
            X = sub[[gdp_var, 'ln_pop', 'gini', 'gini_x_cost', 'period', 'soviet'] + galton_cols + s_cols]
            res = run_ols_clustered(sub['total_olympic_6pt'], X, sub['country'])
            gdp_spec[f'{gdp_label}_{label}'] = {
                'gini_x_equip_b': fmt(res['params']['gini_x_cost']),
                'gini_x_equip_p': fmt(res['pvalues']['gini_x_cost']),
                'n': res['n_obs'],
            }
    R['gdp_specification'] = gdp_spec

    return R


# ============================================================
# RUN BOTH SPECIFICATIONS
# ============================================================

results_religion = run_full_pipeline(religion_cols, 'RELIGION')
results_region = run_full_pipeline(region_cols, 'REGION')

# ============================================================
# SAVE ALL RESULTS
# ============================================================
print("\n" + "=" * 70)
print("SAVING RESULTS")
print("=" * 70)

def clean_for_json(obj):
    if isinstance(obj, dict):
        return {k: clean_for_json(v) for k, v in obj.items() if k not in ('model', 'cov_cl')}
    elif isinstance(obj, list):
        return [clean_for_json(v) for v in obj]
    elif isinstance(obj, (np.integer,)):
        return int(obj)
    elif isinstance(obj, (np.floating,)):
        return float(obj)
    elif isinstance(obj, np.ndarray):
        return obj.tolist()
    return obj

output = {
    'religion': clean_for_json(results_religion),
    'region': clean_for_json(results_region),
    'metadata': {
        'version': 'v1.06',
        'religion_vars': religion_cols,
        'region_vars': region_cols,
        'n_countries': len(gdp_avg),
        'n_upper': len(upper_countries),
        'n_lower': len(lower_countries),
        'gdp_median': round(gdp_median),
        'gdp_split': 'time-invariant, mean GDP, >= median = upper',
        'fixes_applied': [
            '#1: GDP split >= median (was > in v0.99)',
            '#3: Pop elasticity uses ln(total) not ln(total+1)',
        ],
    }
}

out_path = os.path.join(RESULTS_DIR, 'v106_two_period_results.json')
with open(out_path, 'w') as f:
    json.dump(output, f, indent=2, default=str)
print(f"Results saved to {out_path}")

print("\n" + "=" * 70)
print("v1.06 TWO-PERIOD PIPELINE COMPLETE")
print("=" * 70)
