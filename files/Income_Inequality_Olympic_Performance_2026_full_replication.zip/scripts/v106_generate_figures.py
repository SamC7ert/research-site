#!/usr/bin/env python3
"""
v106_generate_figures.py — Generate all figures for paper v1.06.

Changes from v1.05:
  - Dropped: old fig2 (religion vs region bars) — robustness check, not needed as figure
  - NEW: Regional Gini slope world map
  - Improved fig7: drop bivariate line, shade error zone between α=0.63 and α=1,
    annotate misranked countries

Renumbered in v1.06:
  - figures/fig1_sport_cost_segmentation.png      Figure 1
  - figures/fig2_regional_gini_map.png            Figure 2
  - figures/fig3_per_sport_gini_scatter.png       Figure 3  (adjustText labels)
  - figures/fig4_crossover_marginal_effect.png    Figure 4
  - figures/fig5_persistence_vs_facility.png      Figure 5  (was Fig 6)
  - DROPPED in v1.06.5: fig6_population_elasticity (moved to Methods text, figure removed)
  - DROPPED: fig5_simulation_comparison (was Fig 5)
"""

import json
import os
import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
from adjustText import adjust_text
from pathlib import Path
from collections import defaultdict

# ── Configuration ──────────────────────────────────────────────────────────

JOURNAL_MODE = False

DPI = 600 if JOURNAL_MODE else 300
FIG_FORMAT = 'tiff' if JOURNAL_MODE else 'png'
SHOW_TITLE = not JOURNAL_MODE

# Paths (relative to script location)
SCRIPT_DIR = Path(__file__).resolve().parent
BASE_DIR = SCRIPT_DIR.parent
RESULTS_FILE = BASE_DIR / 'results' / 'v106_game_level_results.json'
COST_FILE = BASE_DIR / 'data' / 'v106_sport_cost_classification.json'
PANEL_FILE = BASE_DIR / 'data' / 'v106_game_level_panel.json'
SIM_RESULTS_FILE = BASE_DIR / 'results' / 'simulation' / 'v106_simulation_results.json'
FIG_DIR = BASE_DIR / 'figures'
FIG_DIR.mkdir(exist_ok=True)

# Okabe-Ito palette
C_INDIVIDUAL = '#0072B2'   # Blue
C_TEAM       = '#E69F00'   # Orange
C_DUEL       = '#009E73'   # Green
C_CI         = '#56B4E9'   # Sky blue
C_ANNOT      = '#D55E00'   # Vermillion
C_BLACK      = '#000000'
C_POS        = '#009E73'   # Green for positive slopes
C_NEG        = '#D55E00'   # Vermillion for negative slopes
C_ERROR_ZONE = '#D55E00'   # Light vermillion for error zone

SPORT_COLORS = {
    'individual': C_INDIVIDUAL,
    'team': C_TEAM,
    'duel': C_DUEL,
}

SPORT_MARKERS = {
    'individual': 'o',
    'team': 's',
    'duel': 'D',
}

SPORT_LABELS = {
    'individual': 'Individual',
    'team': 'Team',
    'duel': 'Duel',
}

# Matplotlib defaults
plt.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Times New Roman', 'DejaVu Serif'],
    'font.size': 10,
    'axes.linewidth': 0.8,
    'axes.edgecolor': '#333333',
    'xtick.direction': 'out',
    'ytick.direction': 'out',
    'xtick.major.width': 0.6,
    'ytick.major.width': 0.6,
    'figure.facecolor': 'white',
    'axes.facecolor': 'white',
    'axes.grid': False,
})


# ── Data Loading ───────────────────────────────────────────────────────────

def load_json(path):
    with open(path, 'r') as f:
        return json.load(f)

def load_json_nan(path):
    """Load JSON that may contain NaN/Infinity."""
    with open(path, 'r') as f:
        text = f.read()
    text = text.replace(': NaN', ': null').replace(': Infinity', ': null').replace(': -Infinity', ': null')
    return json.loads(text)

print("Loading data...")
results = load_json_nan(RESULTS_FILE)
cost_data = load_json(COST_FILE)
panel = load_json(PANEL_FILE)
if SIM_RESULTS_FILE.exists():
    sim_results = load_json(SIM_RESULTS_FILE)
else:
    sim_results = {}
print("  Done.")

# Build facility build cost lookup
FACILITY_BUILD_COST = {}
for s in results['J_discussion']['per_sport_lags']:
    FACILITY_BUILD_COST[s['sport_name']] = s['facility_cost']


# ── Helper ─────────────────────────────────────────────────────────────────

def savefig(fig, name):
    path = FIG_DIR / f'{name}.{FIG_FORMAT}'
    fig.savefig(path, dpi=DPI, bbox_inches='tight', facecolor='white')
    plt.close(fig)
    print(f"  Saved {path.name}")


def add_title(ax, title):
    if SHOW_TITLE:
        ax.set_title(title, fontsize=11, fontweight='bold', pad=12)


# ── Figure 1: Sport Cost Segmentation (UNCHANGED) ─────────────────────────

def fig1_sport_cost_segmentation():
    """Scatter of equipment cost vs facility build cost (max), coloured by sport type."""
    print("Figure 1: Sport cost segmentation...")

    sports = cost_data['sports']
    fig, ax = plt.subplots(figsize=(10, 4.5))

    for stype in ['individual', 'duel', 'team']:
        xs, ys, labels = [], [], []
        for name, s in sports.items():
            if s.get('sport_type') == stype and s.get('in_main_sample'):
                fac = FACILITY_BUILD_COST.get(name, 0)
                if fac <= 0:
                    continue
                xs.append(fac)
                ys.append(s['equipment_annual_eur'])
                labels.append(name)

        ax.scatter(xs, ys, c=SPORT_COLORS[stype], marker=SPORT_MARKERS[stype],
                   s=50, alpha=0.85, label=SPORT_LABELS[stype], edgecolors='white',
                   linewidths=0.5, zorder=3)

        for x, y, lab in zip(xs, ys, labels):
            if lab in ['Swimming', 'Equestrian', 'Sailing', 'Shooting',
                        'Athletics — Track', 'Football (Soccer)', 'Judo',
                        'Road Cycling', 'Tennis', 'Rowing', 'Fencing',
                        'Basketball', 'Volleyball', 'Artistic Swimming']:
                ax.annotate(lab.replace(' (Soccer)', ''), (x, y),
                           textcoords='offset points', xytext=(6, 4),
                           fontsize=7, color='#555555')

    ax.set_xscale('log')
    ax.set_yscale('log')
    ax.set_xlabel('Facility Cost (EUR, log scale)', fontsize=10)
    ax.set_ylabel('Annual Equipment Cost (EUR, log scale)', fontsize=10)
    add_title(ax, 'Sport Cost Classification: Equipment vs Facility Cost')
    ax.legend(loc='upper left', frameon=True, framealpha=0.9, fontsize=9)
    ax.grid(True, alpha=0.2, linewidth=0.5)
    ax.set_axisbelow(True)

    savefig(fig, 'fig1_sport_cost_segmentation')


# ── Figure 2: Regional Gini Slope Map ─────────────────────────────────────

def fig2_regional_gini_map():
    """World map coloured by sign of regional Gini–performance slope."""
    print("Figure 2: Regional Gini slope map...")

    import geopandas as gpd

    # Regional slopes from results
    region_data = results['A_aggregate_ladder']['A2_regional_heterogeneity']['region_slopes']

    # Region ID → name mapping and countries
    region_id_to_name = {}
    region_id_to_countries = defaultdict(list)
    for row in panel:
        rid = str(row.get('region_id', ''))
        rname = row.get('region', '')
        country = row.get('country', '')
        if rid and rname:
            region_id_to_name[rid] = rname
            if country not in region_id_to_countries[rid]:
                region_id_to_countries[rid].append(country)

    # Country → slope sign mapping
    country_slope = {}
    country_slope_value = {}
    for rid, slope_info in region_data.items():
        beta = slope_info['beta']
        for country in region_id_to_countries.get(rid, []):
            country_slope[country] = 'positive' if beta > 0 else 'negative'
            country_slope_value[country] = beta

    # Country name mapping for geopandas naturalearth
    name_map = {
        'Great Britain': 'United Kingdom',
        'South Korea': 'South Korea',
        'North Korea': 'North Korea',
        'United States': 'United States of America',
        'Czech Republic': 'Czechia',
        'Taiwan': 'Taiwan',
    }

    # Load world shapefile (geopandas >= 1.0 removed built-in datasets)
    world = gpd.read_file('https://naciscdn.org/naturalearth/110m/cultural/ne_110m_admin_0_countries.zip')
    # Normalize column name: Natural Earth uses 'NAME' or 'ADMIN'
    if 'name' not in world.columns:
        if 'NAME' in world.columns:
            world = world.rename(columns={'NAME': 'name'})
        elif 'ADMIN' in world.columns:
            world = world.rename(columns={'ADMIN': 'name'})

    # Map our countries to geopandas names
    world['slope_sign'] = 'not_in_sample'
    for our_name, sign in country_slope.items():
        geo_name = name_map.get(our_name, our_name)
        mask = world['name'] == geo_name
        if mask.any():
            world.loc[mask, 'slope_sign'] = sign
        else:
            # Try partial match
            mask2 = world['name'].str.contains(geo_name.split()[0], case=False, na=False)
            if mask2.any():
                world.loc[mask2, 'slope_sign'] = sign

    # Colour mapping
    color_map = {
        'positive': C_POS,      # Green
        'negative': C_NEG,      # Vermillion
        'not_in_sample': '#E8E8E8',  # Light grey
    }

    fig, ax = plt.subplots(figsize=(10, 5))

    for sign, color in color_map.items():
        subset = world[world['slope_sign'] == sign]
        subset.plot(ax=ax, color=color, edgecolor='white', linewidth=0.3,
                    alpha=0.85 if sign != 'not_in_sample' else 0.4)

    # Add region labels with β values
    region_centroids = {
        'Northern Europe': (15, 62),
        'Western Europe': (5, 48),
        'Southern Europe': (15, 40),
        'Eastern Europe': (30, 52),
        'Eastern Asia': (115, 35),
        'South & SE Asia': (95, 15),
        'Western & Central Asia': (55, 40),
        'Africa': (20, 5),
        'Latin America & Caribbean': (-60, -10),
        'NA & Oceania (Anglosphere)': (-100, 45),
    }

    for rid, slope_info in region_data.items():
        rname = region_id_to_name.get(rid, f'Region {rid}')
        beta = slope_info['beta']
        p = slope_info['p']
        sign = '+' if beta > 0 else ''

        # Short region name for label
        short_names = {
            'Northern Europe': 'N. Europe',
            'Western Europe': 'W. Europe',
            'Southern Europe': 'S. Europe',
            'Eastern Europe': 'E. Europe',
            'Eastern Asia': 'E. Asia',
            'South & SE Asia': 'S/SE Asia',
            'Western & Central Asia': 'W/C Asia',
            'Africa': 'Africa',
            'Latin America & Caribbean': 'Latin Am.',
            'NA & Oceania (Anglosphere)': 'Anglosphere',
        }

        short = short_names.get(rname, rname)
        color = C_POS if beta > 0 else C_NEG
        centroid = region_centroids.get(rname)

        if centroid:
            sig = '**' if p < 0.01 else '*' if p < 0.05 else '†' if p < 0.10 else ''
            ax.annotate(f'{short}\n{sign}{beta:.1f}{sig}',
                       xy=centroid, fontsize=6, fontweight='bold',
                       color=color, ha='center', va='center',
                       bbox=dict(boxstyle='round,pad=0.2', facecolor='white',
                                edgecolor=color, alpha=0.8, linewidth=0.5))

    ax.set_xlim(-150, 180)
    ax.set_ylim(-60, 80)
    ax.set_axis_off()
    add_title(ax, 'Regional Gini–Performance Slopes: Five Positive, Five Negative')

    # Legend
    from matplotlib.patches import Patch
    legend_elements = [
        Patch(facecolor=C_POS, edgecolor='white', label='Positive slope (inequality helps)'),
        Patch(facecolor=C_NEG, edgecolor='white', label='Negative slope (inequality hurts)'),
        Patch(facecolor='#E8E8E8', edgecolor='white', label='Not in sample'),
    ]
    ax.legend(handles=legend_elements, loc='lower left', frameon=True,
             framealpha=0.9, fontsize=7)

    savefig(fig, 'fig2_regional_gini_map')


# ── Figure 3: Per-Sport Gini Scatter ──────────────────────────────────────

def fig3_per_sport_gini_scatter():
    """Per-sport Gini coefficient vs equipment cost."""
    print("Figure 3: Per-sport Gini scatter...")

    per_sport = results['G_robustness']['per_sport']
    sports = cost_data['sports']

    fig, ax = plt.subplots(figsize=(12, 5.5))

    ind_xs, ind_ys, ind_labels = [], [], []
    for s in per_sport:
        ind_xs.append(np.log(s['equipment_eur']))
        ind_ys.append(s['gini_b'])
        ind_labels.append(s['sport_name'])

    ind_xs = np.array(ind_xs)
    ind_ys = np.array(ind_ys)

    s_arr = np.array([s['n'] for s in per_sport])
    s_scaled = 25 + 70 * (s_arr - s_arr.min()) / max(1, s_arr.max() - s_arr.min())

    ax.scatter(ind_xs, ind_ys, c=SPORT_COLORS['individual'], marker=SPORT_MARKERS['individual'],
               s=s_scaled, alpha=0.8, label=SPORT_LABELS['individual'],
               edgecolors='white', linewidths=0.5, zorder=3)

    z = np.polyfit(ind_xs, ind_ys, 1)
    p = np.poly1d(z)
    x_line = np.linspace(ind_xs.min(), ind_xs.max(), 50)
    ax.plot(x_line, p(x_line), color=SPORT_COLORS['individual'],
            linewidth=1.5, linestyle='--', alpha=0.6)

    team_beta = results['B_sport_type']['religion']['team_full']['gini_x_cost']['beta']
    duel_beta = results['B_sport_type']['religion']['duel_full']['gini_x_cost']['beta']

    for stype, beta in [('team', team_beta), ('duel', duel_beta)]:
        xs_other, labels_other = [], []
        for name, s in sports.items():
            if s.get('sport_type') == stype and s.get('in_main_sample'):
                xs_other.append(np.log(s['equipment_annual_eur']))
                labels_other.append(name)

        ys_other = [beta] * len(xs_other)
        ax.scatter(xs_other, ys_other, c=SPORT_COLORS[stype], marker=SPORT_MARKERS[stype],
                   s=35, alpha=0.5, label=f'{SPORT_LABELS[stype]} (type β={beta:.2f})',
                   edgecolors='white', linewidths=0.5, zorder=2)

    texts = []
    for x, y, lab in zip(ind_xs, ind_ys, ind_labels):
        short = lab.replace('Athletics — ', '').replace('Artistic ', 'Art. ')
        short = short.replace('Rhythmic ', 'Rhy. ').replace('Marathon ', 'Mar. ')
        short = short.replace('Mountain ', 'Mt. ').replace('Modern ', 'Mod. ')
        texts.append(ax.text(x, y, short, fontsize=7, color='#555555'))
    adjust_text(texts, x=ind_xs, y=ind_ys, ax=ax,
                arrowprops=dict(arrowstyle='-', color='#cccccc', lw=0.4),
                force_text=(1.0, 1.5), force_points=(0.5, 0.5),
                expand_text=(1.5, 1.8), expand_points=(1.5, 1.5),
                iterations=200)

    ax.axhline(0, color=C_BLACK, linewidth=0.8, linestyle='--', alpha=0.5)

    cost_ticks = [200, 400, 800, 1200, 2000, 4000]
    ax.set_xticks([np.log(c) for c in cost_ticks])
    ax.set_xticklabels([f'€{c:,}' for c in cost_ticks], fontsize=8)

    ax.set_xlabel('Equipment Cost (EUR, log scale)', fontsize=10)
    ax.set_ylabel('Per-Sport Gini Coefficient (β)', fontsize=10)
    add_title(ax, 'Per-Sport Gini–Performance Relationship vs Equipment Cost')
    ax.legend(loc='upper right', frameon=True, framealpha=0.9, fontsize=8)
    ax.grid(True, alpha=0.15, linewidth=0.5)
    ax.set_axisbelow(True)

    savefig(fig, 'fig3_per_sport_gini_scatter')


# ── Figure 4: Crossover Marginal Effect ───────────────────────────────────

def fig4_crossover_marginal_effect():
    """Marginal effect of Gini at different equipment cost levels (upper GDP)."""
    print("Figure 4: Crossover marginal effect...")

    cross = results['D_cost_gradient']['crossover']['ind_upper']
    effects = cross['effects_at_cost']

    costs = [e['cost_eur'] for e in effects]
    effs = [e['effect'] for e in effects]
    ses = [e['se'] for e in effects]
    ci_lo = [e - 1.96*s for e, s in zip(effs, ses)]
    ci_hi = [e + 1.96*s for e, s in zip(effs, ses)]

    ln_costs = [np.log(c) for c in costs]
    crossover_ln = cross['crossover_ln']
    crossover_eur = cross['crossover_eur']
    ci_lo_cross = np.log(cross['ci_lo'])
    ci_hi_cross = np.log(cross['ci_hi'])

    fig, ax = plt.subplots(figsize=(4.5, 3.5))

    ax.fill_between(ln_costs, ci_lo, ci_hi, color=C_CI, alpha=0.3, label='95% CI')
    ax.plot(ln_costs, effs, color=C_INDIVIDUAL, linewidth=2, marker='o',
            markersize=4, zorder=4)
    ax.axhline(0, color=C_BLACK, linewidth=0.8, linestyle='--', alpha=0.5)
    ax.axvline(crossover_ln, color=C_ANNOT, linewidth=1.2, linestyle=':',
               label=f'Crossover: €{crossover_eur:,.0f}')
    ax.axvspan(ci_lo_cross, ci_hi_cross, color=C_ANNOT, alpha=0.08)

    cost_ticks = [300, 500, 1000, 2000, 4000, 10000, 50000]
    ax.set_xticks([np.log(c) for c in cost_ticks])
    ax.set_xticklabels([f'€{c:,}' if c < 10000 else f'€{c//1000}k' for c in cost_ticks],
                       fontsize=7, rotation=30, ha='right')

    ax.set_xlabel('Equipment Cost (EUR, log scale)', fontsize=8)
    ax.set_ylabel('Marginal Effect of Gini', fontsize=8)
    add_title(ax, 'Crossover: Marginal Effect of Inequality\nby Equipment Cost (Upper GDP)')
    ax.legend(loc='upper right', frameon=True, framealpha=0.9, fontsize=7)
    ax.grid(True, alpha=0.15, linewidth=0.5)
    ax.set_axisbelow(True)

    savefig(fig, 'fig4_crossover_marginal_effect')


# ── Figure 5 (was 6): Persistence vs Facility Cost ────────────────────────

def fig5_persistence_vs_facility():
    """Per-sport lag coefficients vs facility cost."""
    print("Figure 5: Persistence vs facility cost...")

    lags = results['J_discussion']['per_sport_lags']

    fig, ax = plt.subplots(figsize=(10, 4.5))

    data_by_type = {'individual': [], 'duel': [], 'team': []}
    for s in lags:
        fac = s['facility_cost']
        if fac <= 0:
            continue
        data_by_type[s['sport_type']].append(s)

    for stype in ['team', 'duel', 'individual']:
        items = data_by_type[stype]
        xs = [np.log(s['facility_cost']) for s in items]
        ys = [s['lag_beta'] for s in items]
        sizes = [s['n'] for s in items]
        labels_s = [s['sport_name'] for s in items]

        s_arr = np.array(sizes) if sizes else np.array([1])
        s_scaled = 25 + 75 * (s_arr - s_arr.min()) / max(1, s_arr.max() - s_arr.min())

        ax.scatter(xs, ys, c=SPORT_COLORS[stype], marker=SPORT_MARKERS[stype],
                   s=s_scaled, alpha=0.8, label=SPORT_LABELS[stype],
                   edgecolors='white', linewidths=0.5, zorder=3)

        for x, y, lab in zip(xs, ys, labels_s):
            if lab in ['Swimming', 'Equestrian', 'Sailing', 'Shooting',
                        'Athletics — Track', 'Football (Soccer)',
                        'Road Cycling', 'Tennis', 'Rowing', 'Fencing',
                        'Judo', 'Basketball', 'Volleyball',
                        'Artistic Gymnastics', 'Diving']:
                short = lab.replace(' (Soccer)', '').replace('Athletics — ', '')
                ax.annotate(short, (x, y), textcoords='offset points',
                           xytext=(5, 3), fontsize=7, color='#555555')

    # Trend lines for individual only
    ind_items = data_by_type['individual']
    ind_xs = np.array([np.log(s['facility_cost']) for s in ind_items])
    ind_ys = np.array([s['lag_beta'] for s in ind_items])

    if len(ind_xs) >= 3:
        z = np.polyfit(ind_xs, ind_ys, 1)
        p_raw = np.poly1d(z)
        x_line = np.linspace(ind_xs.min(), ind_xs.max(), 50)
        ax.plot(x_line, p_raw(x_line), color=C_INDIVIDUAL,
                linewidth=1.8, linestyle='-', alpha=0.7, label='Individual (OLS trend)')

    ax.axhline(0, color=C_BLACK, linewidth=0.6, linestyle='-', alpha=0.3)

    fac_ticks = [100000, 500000, 1000000, 5000000, 25000000]
    ax.set_xticks([np.log(c) for c in fac_ticks])
    ax.set_xticklabels(['€100k', '€500k', '€1M', '€5M', '€25M'], fontsize=8)

    ax.set_xlabel('Facility Cost (EUR, log scale)', fontsize=10)
    ax.set_ylabel('Persistence Coefficient (λ)', fontsize=10)
    add_title(ax, 'Persistence vs Facility Cost by Sport Type')
    ax.legend(loc='upper left', frameon=True, framealpha=0.9, fontsize=8)
    ax.grid(True, alpha=0.15, linewidth=0.5)
    ax.set_axisbelow(True)

    savefig(fig, 'fig5_persistence_vs_facility')


# ── Figure 6 (was 7): Population Elasticity ───────────────────────────────

def fig6_population_elasticity():
    """Log–log scatter of aggregate performance vs population.
    Improved: drop bivariate line, shade error zone between α=0.63 and α=1,
    annotate countries that get misranked by per-capita scoring.
    """
    print("Figure 6: Population elasticity...")

    # Aggregate country-game level
    country_game = defaultdict(lambda: {'olympic_6pt': 0, 'pop': 0, 'gdp': 0, 'gini': 0, 'country': ''})
    for row in panel:
        if not row.get('regression_eligible'):
            continue
        key = (row['country'], row['game_year'])
        country_game[key]['olympic_6pt'] += row['olympic_6pt']
        country_game[key]['pop'] = row['population']
        country_game[key]['gdp'] = row['gdp_pc_ppp']
        country_game[key]['gini'] = row['gini']
        country_game[key]['country'] = row['country']

    # Filter positive points
    ln_pop, ln_pts, countries, ginis = [], [], [], []
    for key, v in country_game.items():
        if v['olympic_6pt'] > 0 and v['pop'] > 0:
            ln_pop.append(np.log(v['pop']))
            ln_pts.append(np.log(v['olympic_6pt']))
            countries.append(v['country'])
            ginis.append(v['gini'])

    ln_pop = np.array(ln_pop)
    ln_pts = np.array(ln_pts)
    ginis = np.array(ginis)

    # Controlled α from regression
    alpha_controlled = results['H_pop_elasticity']['aggregate_log_log']['alpha']['beta']

    fig, ax = plt.subplots(figsize=(5.5, 4.5))

    # Scatter points
    ax.scatter(ln_pop, ln_pts, c=C_INDIVIDUAL, alpha=0.25, s=12, edgecolors='none')

    x_fit = np.linspace(ln_pop.min(), ln_pop.max(), 100)

    # Intercepts: both lines pass through the mean
    mean_lnpop = np.mean(ln_pop)
    mean_lnpts = np.mean(ln_pts)

    # Controlled line (α = 0.63)
    y_controlled = alpha_controlled * x_fit + (mean_lnpts - alpha_controlled * mean_lnpop)
    ax.plot(x_fit, y_controlled, color=C_INDIVIDUAL, linewidth=2, linestyle='-',
            label=f'Controlled α = {alpha_controlled:.2f}')

    # Proportional line (α = 1)
    y_proportional = 1.0 * x_fit + (mean_lnpts - 1.0 * mean_lnpop)
    ax.plot(x_fit, y_proportional, color=C_BLACK, linewidth=1.2, linestyle=':',
            alpha=0.6, label='α = 1 (per-capita assumption)')

    # Shade the error zone between the two lines
    ax.fill_between(x_fit, y_controlled, y_proportional,
                    color=C_ERROR_ZONE, alpha=0.10, label='Per-capita error zone')

    # Annotate select countries that get misranked
    # Find country averages for annotation
    country_avg = defaultdict(lambda: {'ln_pop': [], 'ln_pts': [], 'gini': []})
    for lp, lpt, c, g in zip(ln_pop, ln_pts, countries, ginis):
        country_avg[c]['ln_pop'].append(lp)
        country_avg[c]['ln_pts'].append(lpt)
        country_avg[c]['gini'].append(g)

    # Countries to annotate: small low-Gini (boosted by per-capita) and large high-Gini (penalised)
    annotate_countries = {
        # Small, low-Gini — per-capita over-credits
        'Norway': {'offset': (8, 6), 'side': 'boosted'},
        'Sweden': {'offset': (8, -8), 'side': 'boosted'},
        'Denmark': {'offset': (8, 4), 'side': 'boosted'},
        'New Zealand': {'offset': (8, -8), 'side': 'boosted'},
        'Jamaica': {'offset': (8, 4), 'side': 'boosted'},
        # Large, high-Gini — per-capita penalises
        'Brazil': {'offset': (8, -8), 'side': 'penalised'},
        'India': {'offset': (8, 6), 'side': 'penalised'},
        'China': {'offset': (8, -10), 'side': 'penalised'},
        'Mexico': {'offset': (8, 6), 'side': 'penalised'},
        'United States': {'offset': (8, -10), 'side': 'penalised'},
    }

    for cname, info in annotate_countries.items():
        if cname in country_avg:
            avg_lp = np.mean(country_avg[cname]['ln_pop'])
            avg_lpt = np.mean(country_avg[cname]['ln_pts'])
            color = C_POS if info['side'] == 'boosted' else C_NEG
            ax.annotate(cname, (avg_lp, avg_lpt),
                       textcoords='offset points', xytext=info['offset'],
                       fontsize=6.5, color=color, fontweight='bold',
                       arrowprops=dict(arrowstyle='-', color=color, lw=0.5))

    # Population labels
    pop_ticks = [1e6, 5e6, 20e6, 100e6, 500e6, 1.4e9]
    pop_labels = ['1M', '5M', '20M', '100M', '500M', '1.4B']
    ax.set_xticks([np.log(p) for p in pop_ticks])
    ax.set_xticklabels(pop_labels, fontsize=7)

    ax.set_xlabel('Population (log scale)', fontsize=9)
    ax.set_ylabel('Total Olympic Points (log scale)', fontsize=9)
    add_title(ax, 'Population Elasticity: Per-Capita Scoring Error')
    ax.legend(loc='upper left', frameon=True, framealpha=0.9, fontsize=7)
    ax.grid(True, alpha=0.15, linewidth=0.5)
    ax.set_axisbelow(True)

    savefig(fig, 'fig6_population_elasticity')


# ── Main ───────────────────────────────────────────────────────────────────

if __name__ == '__main__':
    print(f"\nGenerating figures for v1.06 (JOURNAL_MODE={JOURNAL_MODE})...\n")

    fig1_sport_cost_segmentation()
    fig2_regional_gini_map()
    fig3_per_sport_gini_scatter()
    fig4_crossover_marginal_effect()
    fig5_persistence_vs_facility()
    # fig6_population_elasticity()  # Dropped in v1.06.5: moved to Methods text, figure removed

    print(f"\nAll figures saved to {FIG_DIR}/")
    print(f"Format: {FIG_FORMAT.upper()}, DPI: {DPI}")
