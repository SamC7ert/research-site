#!/usr/bin/env python3
"""
v1.06 Production Simulation
==============================
Matches the v1.06 production code with updated field names and data files.
Based on the v1.05.1 source with these v1.06 changes:
  - Field name updates: 'sport' -> 'sport_name', 'points' -> 'olympic_6pt', etc.
  - Data file updates: v106 versions of game panel, sport properties, cost classification
  - Experience-based persistence (not Olympic points)
  - disc_share in Dagum threshold (R_eff = R / disc_share)
  - Experience seed data for 1992/1996
  - Event counts from empirical panel (total_pts / 21)
  - v1.06 calibrated parameters

Additional output: accumulated country-sport points across regression years,
averaged over 100 seeds, for NCAA/cost analysis.
"""

import json
import os
import sys
import time
from datetime import datetime
from collections import defaultdict

import numpy as np
from scipy import stats as spstats

# ============================================================================
# PATHS (relative to script)
# ============================================================================
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, '..', 'data')
RESULTS_DIR = os.path.join(SCRIPT_DIR, '..', 'results', 'simulation')
os.makedirs(RESULTS_DIR, exist_ok=True)

# ============================================================================
# LOAD DATA
# ============================================================================
print("Loading data...")

with open(os.path.join(DATA_DIR, 'v106_game_level_panel.json')) as f:
    game_panel = json.load(f)

with open(os.path.join(DATA_DIR, 'v106_religion_classification.json')) as f:
    religion_data = json.load(f)

with open(os.path.join(DATA_DIR, 'v106_non_olympic_sport_drain.json')) as f:
    drain_data = json.load(f)

with open(os.path.join(DATA_DIR, 'v106_sport_properties.json')) as f:
    sport_props_raw = json.load(f)

with open(os.path.join(DATA_DIR, 'v106_sport_cost_classification.json')) as f:
    sport_costs_raw = json.load(f)

with open(os.path.join(DATA_DIR, 'v106_gdp_by_game_year.json')) as f:
    gdp_by_game = json.load(f)

with open(os.path.join(DATA_DIR, 'v106_population_by_game_year.json')) as f:
    pop_by_game = json.load(f)

with open(os.path.join(DATA_DIR, 'v106_gini_by_game_year.json')) as f:
    gini_by_game = json.load(f)

with open(os.path.join(DATA_DIR, 'v106_experience_seed_data.json')) as f:
    exp_seed_data = json.load(f)

with open(os.path.join(DATA_DIR, 'v106_sim_parameters.json')) as f:
    params_file = json.load(f)

# ============================================================================
# PARAMETERS
# ============================================================================
params = {}
params.update(params_file.get('calibrated_parameters', {}))
params.update(params_file.get('fixed_allocation_parameters', {}))

base_seed = params_file.get('reproduction_settings', {}).get('base_seed', 0)
n_runs = 100

# ============================================================================
# BUILD REFERENCE STRUCTURES
# ============================================================================
print("Building reference structures...")

# --- Countries ---
all_countries = sorted(set(r['country'] for r in game_panel))
country_to_idx = {c: i for i, c in enumerate(all_countries)}
n_countries = len(all_countries)

# --- GDP classification: fixed set from panel's upper_gdp_half field ---
# Use both country names and NOC codes (regression rows use 'noc')
_UPPER_GDP_COUNTRIES = set(r['country'] for r in game_panel if r.get('upper_gdp_half'))
_UPPER_GDP_NOCS = set(r['noc'] for r in game_panel if r.get('upper_gdp_half'))
print(f"  Upper GDP countries from panel: {len(_UPPER_GDP_COUNTRIES)} ({len(_UPPER_GDP_NOCS)} NOCs)")

# --- Sports (from sport_properties, 41 sports) ---
sport_props = sport_props_raw.get('sports', sport_props_raw)
if isinstance(sport_props, dict) and 'metadata' in sport_props:
    sport_dict = {k: v for k, v in sport_props.items() if k != 'metadata'}
else:
    sport_dict = sport_props

all_sports = sorted(s for s, p in sport_dict.items() if p.get('simulation_eligible', True))
sport_to_idx = {s: i for i, s in enumerate(all_sports)}
n_sports = len(all_sports)

# Sport arrays
equip_cost = np.array([sport_dict[s]['cost_equip_eur_pr_year'] for s in all_sports], dtype=float)
ln_equip = np.log(np.maximum(equip_cost, 1.0))

# Facility build cost (EUR) — used in Layer 2 GDP quality interaction
# Matches regression specification: GDP × ln(facility)
sport_costs = sport_costs_raw['sports']
facility_cost = np.array([sport_dict[s].get('cost_national_facility_eur', 0)
                          for s in all_sports], dtype=float)
ln_facility = np.log(np.maximum(facility_cost, 1.0))

# Infrastructure cost (facility build cost in millions) — used in allocation sigmoid
infra_cost_m = facility_cost / 1e6

sport_types = [sport_dict[s]['sport_type'] for s in all_sports]
sport_type_arr = np.array(sport_types)

# --- Experience map (top 40 positions) ---
exp_map_raw = {int(k): v for k, v in exp_seed_data['scoring_schemes']['biathlon_full'].items()}
EXP_LEN = 40
EXPERIENCE_ARRAY = np.zeros(EXP_LEN)
for pos in range(1, EXP_LEN + 1):
    if pos in exp_map_raw:
        EXPERIENCE_ARRAY[pos - 1] = exp_map_raw[pos]
    else:
        EXPERIENCE_ARRAY[pos - 1] = max(1, int(round(35 - (pos - 7) * (34 / 33))))

# --- Games ---
GAME_YEARS = [1984, 1988, 1992, 1996, 2000, 2004, 2008, 2012, 2016, 2020, 2024]
SEED_YEARS = {1984, 1988, 1992, 1996}
REGRESSION_YEARS = {2000, 2004, 2008, 2012, 2016, 2020, 2024}
n_games = len(GAME_YEARS)

LAG2_DECAY = 0.68
LAG3_DECAY = 0.0

HOSTS = {
    1992: 'Spain', 1996: 'United States', 2000: 'Australia', 2004: 'Greece',
    2008: 'China', 2012: 'Great Britain', 2016: 'Brazil', 2020: 'Japan', 2024: 'France',
}

# --- Country data per game year ---
gini_countries = gini_by_game.get('countries', gini_by_game)

country_game_data = {}
for c in all_countries:
    gdp_c = gdp_by_game.get(c, {})
    pop_c = pop_by_game.get(c, {})
    gini_c = gini_countries.get(c, {})
    for gy in GAME_YEARS:
        gy_str = str(gy)
        gdp_val = gdp_c.get(gy_str)
        pop_val = pop_c.get(gy_str)
        gini_raw = gini_c.get(gy_str)
        if isinstance(gini_raw, dict):
            gini_val = gini_raw.get('value')
        else:
            gini_val = gini_raw
        if gdp_val and pop_val and gini_val:
            country_game_data[(c, gy)] = {
                'gdp': float(gdp_val),
                'pop': float(pop_val),
                'gini': float(gini_val),
            }

# --- Religion ---
country_religion = {}
for c in all_countries:
    cdata = religion_data['countries'].get(c, {})
    country_religion[c] = {
        'pct_muslim': cdata.get('pct_muslim', 0),
        'pct_hindu': cdata.get('pct_hindu', 0),
        'pct_buddhist': cdata.get('pct_buddhist', 0),
        'pct_christian': cdata.get('pct_christian', 0),
    }

# --- Drain ---
drain_countries_data = drain_data.get('country_drain_fractions', {}).get('countries', {})
country_drain = {}
for c in all_countries:
    country_drain[c] = drain_countries_data.get(c, {}).get('drain_fraction', 0.0)

# --- Events per sport per game year (from empirical panel: total_pts / 21) ---
sport_game_total_pts = defaultdict(float)
for r in game_panel:
    if r['sport_name'] in sport_to_idx:
        sport_game_total_pts[(r['sport_name'], r['game_year'])] += r['olympic_6pt']

events_per_sport_game = {}
for (s, g), pts in sport_game_total_pts.items():
    events_per_sport_game[(s, g)] = max(1, round(pts / 21))

# --- Empirical data for seeding ---
empirical_pts = {}
empirical_exp = {}
noc_to_country = {}
for r in game_panel:
    noc_to_country[r['noc']] = r['country']
    if r['sport_name'] in sport_to_idx:
        empirical_pts[(r['country'], r['sport_name'], r['game_year'])] = r['olympic_6pt']

# Load empirical experience for seed years
for yr_str in ['1992', '1996']:
    yr = int(yr_str)
    for entry in exp_seed_data['by_game_year'].get(yr_str, []):
        noc = entry['noc']
        sport_name = entry['sport_name']
        if noc in noc_to_country and sport_name in sport_to_idx:
            c = noc_to_country[noc]
            ci = country_to_idx[c]
            si = sport_to_idx[sport_name]
            empirical_exp[(ci, si, yr)] = entry.get('biathlon_full', 0)

# --- Game panel variables for regression ---
country_game_vars = {}
for r in game_panel:
    key = (r['country'], r['game_year'])
    if key not in country_game_vars:
        country_game_vars[key] = {
            'noc': r['noc'],
            'gdp_pc_ppp': r['gdp_pc_ppp'],
            'population': r['population'],
            'gini': r['gini'],
            'soviet_legacy': r['soviet_legacy'],
            'pct_christian': r.get('pct_christian', 0) or 0,
            'pct_muslim': r.get('pct_muslim', 0) or 0,
            'pct_hindu': r.get('pct_hindu', 0) or 0,
            'pct_buddhist': r.get('pct_buddhist', 0) or 0,
        }

YOUTH_SHARE = 0.30
SCORE_ARRAY = np.array([6, 5, 4, 3, 2, 1])
EULER_MASCHERONI = 0.5772156649

print(f"  {n_countries} countries, {n_sports} sports, {n_games} games")
print(f"  Equipment cost range: EUR {equip_cost.min():.0f} - EUR {equip_cost.max():.0f}")

# ============================================================================
# DAGUM PREFERENCE (with disc_share)
# ============================================================================

def dagum_mean_factor(a):
    return np.pi / (a * np.sin(np.pi / a))


def build_preference_vectorized(gdp_arr, gini_arr, equip_costs, S, R_eff, delta, n_grid=500):
    n_obs = len(gdp_arr)
    n_sp = len(equip_costs)
    result = np.zeros((n_obs, n_sp))
    thresholds = S + R_eff * np.array(equip_costs)

    for i in range(n_obs):
        gdp = gdp_arr[i]
        gini = gini_arr[i]
        gini_frac = max(gini / 100.0, 0.01)
        a = 1.0 / gini_frac
        b = gdp / dagum_mean_factor(a)

        for j in range(n_sp):
            T = thresholds[j]
            if T <= 0:
                T = 1.0
            if T > gdp * 20:
                result[i, j] = 0.0
                continue
            upper = max(T * 200, gdp * 20)
            log_lo = np.log(T)
            log_hi = np.log(upper)
            log_y = np.linspace(log_lo, log_hi, n_grid)
            y = np.exp(log_y)
            dy = np.diff(y)
            y_mid = 0.5 * (y[:-1] + y[1:])
            yb = y_mid / b
            yb_a = yb ** a
            pdf = a * yb ** (a - 1) / (b * (1 + yb_a) ** 2)
            w = ((y_mid - T) / y_mid) ** delta
            val = np.sum(w * pdf * dy)
            result[i, j] = max(0.0, min(1.0, val))

    return result


def build_preference_cache(params):
    S = params['subsistence']
    R = params['cost_ratio']
    disc_share = params['disc_share']
    R_eff = R / disc_share
    delta = params['delta']

    keys = []
    gdps = []
    ginis = []
    for (country, game_year), cgd in country_game_data.items():
        ci = country_to_idx.get(country)
        if ci is None:
            continue
        gdp = cgd['gdp']
        gini = cgd['gini']
        if gdp <= 0 or gini is None:
            continue
        keys.append((ci, game_year))
        gdps.append(gdp)
        ginis.append(gini)

    gdp_arr = np.array(gdps)
    gini_arr = np.array(ginis)
    costs = [float(c) for c in equip_cost]

    pref_matrix = build_preference_vectorized(gdp_arr, gini_arr, costs, S, R_eff, delta)

    cache = {}
    for idx, (ci, game_year) in enumerate(keys):
        for si in range(n_sports):
            cache[(ci, game_year, si)] = pref_matrix[idx, si]

    return cache


# ============================================================================
# LAYER 1: ALLOCATION WITH DAGUM PREFERENCE
# ============================================================================

def compute_quality_L1_dagum(params, game_year, prev_game_pts=None, pref_cache=None):
    alpha = params['alpha']
    kappa = params.get('infra_sensitivity', 5.0)
    tau = params.get('infra_threshold', 50.0)
    phi_football = params.get('football_pop', 5.0)
    psi = params.get('pop_feedback', 0.5)
    wealth_skew = params.get('wealth_skew', 0.0)
    w_m = params.get('w_muslim', 0.3)
    w_h = params.get('w_hindu', 0.1)
    w_b = params.get('w_buddhist', 0.1)
    lam = params.get('lam', 1.0)
    host_bonus = params.get('host_bonus', 1.0)

    football_idx = sport_to_idx.get('Football (Soccer)', -1)

    # Median GDP for wealth skewness
    gdps = []
    for c in all_countries:
        cgd = country_game_data.get((c, game_year))
        if cgd:
            gdps.append(cgd['gdp'])
    median_gdp = np.median(gdps) if gdps else 10000
    ln_median_gdp = np.log(median_gdp)

    quality = np.full((n_countries, n_sports), -999.0)

    for ci, country in enumerate(all_countries):
        cgd = country_game_data.get((country, game_year))
        if cgd is None:
            continue

        gdp = cgd['gdp']
        pop = cgd['pop']
        gini = cgd['gini']

        if gdp <= 0 or pop <= 0 or gini is None:
            continue

        Y = pop * YOUTH_SHARE

        # Religion penalty
        rel = country_religion[country]
        rel_penalty = (w_m * rel['pct_muslim'] +
                       w_h * rel['pct_hindu'] +
                       w_b * rel['pct_buddhist'])
        rel_penalty = min(rel_penalty, 0.5)
        pi_c = max(0.001, 1.0 - lam * rel_penalty)
        N_part = Y * pi_c

        weights = np.zeros(n_sports)
        for si in range(n_sports):
            aff = pref_cache.get((ci, game_year, si), 0.001) if pref_cache else 0.001

            # Infrastructure
            if infra_cost_m[si] <= 0:
                infra = 1.0
            else:
                x = gdp / (tau * infra_cost_m[si])
                infra = 1.0 / (1.0 + np.exp(-kappa * (x - 1.0)))

            # Popularity feedback
            if si == football_idx:
                pop_weight = phi_football
            elif prev_game_pts is not None and psi > 0:
                prev_pts = prev_game_pts.get((ci, si), 0.0)
                n_events = events_per_sport_game.get((all_sports[si], game_year), 1)
                max_pts = n_events * 21
                pop_weight = 1.0 + psi * (prev_pts / max(max_pts, 1))
            else:
                pop_weight = 1.0

            # Wealth skewness: only above median GDP
            if wealth_skew > 0 and gdp > median_gdp:
                ln_equip_ratio = np.log(max(equip_cost[si], 1) / max(equip_cost.min(), 1))
                wealth_factor = 1.0 + wealth_skew * (np.log(gdp) - ln_median_gdp) * ln_equip_ratio
            else:
                wealth_factor = 1.0

            weights[si] = aff * infra * pop_weight * wealth_factor

        total_w = weights.sum()
        if total_w > 0:
            norm_weights = weights / total_w
        else:
            norm_weights = np.ones(n_sports) / n_sports

        N_alloc = N_part * norm_weights
        drain = country_drain[country]
        N_drain = N_alloc * (1.0 - drain)
        N_drain = np.maximum(N_drain, 1.0)
        q = alpha * np.log(N_drain)

        # Host bonus: additive to quality
        if HOSTS.get(game_year) == country:
            q += host_bonus

        quality[ci, :] = q

    return quality


# ============================================================================
# LAYER 2: GDP QUALITY ADJUSTMENT
# ============================================================================

def compute_quality_L2(quality_L1, params, game_year):
    beta = params['beta']
    quality = quality_L1.copy()
    for ci, country in enumerate(all_countries):
        cgd = country_game_data.get((country, game_year))
        if cgd is None or cgd['gdp'] <= 0:
            continue
        if quality[ci, 0] < -900:
            continue
        quality[ci, :] += beta * np.log(cgd['gdp']) * ln_facility
    return quality


# ============================================================================
# LAYER 3: PERSISTENCE (experience-based, not Olympic points)
# ============================================================================

def compute_quality_L3(quality_L2, params, game_year, lag1_exp, lag2_exp=None, lag3_exp=None):
    gamma = params['gamma']
    if lag1_exp is None:
        return quality_L2.copy()
    gamma2 = LAG2_DECAY * gamma
    gamma3 = LAG3_DECAY * gamma

    quality = quality_L2.copy()
    for ci in range(n_countries):
        if quality[ci, 0] < -900:
            continue
        for si in range(n_sports):
            prev1 = lag1_exp.get((ci, si), 0.0)
            if prev1 > 0:
                quality[ci, si] += gamma * np.log(1.0 + prev1)
            if lag2_exp is not None:
                prev2 = lag2_exp.get((ci, si), 0.0)
                if prev2 > 0:
                    quality[ci, si] += gamma2 * np.log(1.0 + prev2)
            if lag3_exp is not None:
                prev3 = lag3_exp.get((ci, si), 0.0)
                if prev3 > 0:
                    quality[ci, si] += gamma3 * np.log(1.0 + prev3)
    return quality


# ============================================================================
# GUMBEL TOURNAMENT (with Euler-Mascheroni and experience tracking)
# ============================================================================

def run_tournament_gumbel(quality, game_year, rng, params):
    sigma = params['sigma']
    n_athletes = params.get('n_athletes', 3)
    points = np.zeros((n_countries, n_sports))
    experience = np.zeros((n_countries, n_sports))

    for si, sport in enumerate(all_sports):
        n_events = events_per_sport_game.get((sport, game_year), 1)
        valid = quality[:, si] > -900
        valid_indices = np.where(valid)[0]
        n_valid = len(valid_indices)
        if n_valid == 0:
            continue

        q = quality[valid_indices, si]
        draws = rng.gumbel(loc=0, scale=1.0, size=(n_events, n_valid, n_athletes))
        draws -= EULER_MASCHERONI
        perfs = q[np.newaxis, :, np.newaxis] + sigma * draws
        best = perfs.max(axis=2)

        for e_idx in range(n_events):
            ranks = spstats.rankdata(-best[e_idx, :], method='ordinal')
            for local_ci in range(n_valid):
                r = int(ranks[local_ci])
                if r <= 6:
                    points[valid_indices[local_ci], si] += SCORE_ARRAY[r - 1]
                if r <= EXP_LEN:
                    experience[valid_indices[local_ci], si] += EXPERIENCE_ARRAY[r - 1]

    return points, experience


# ============================================================================
# FULL SIMULATION
# ============================================================================

def run_full_simulation(params, seed=42):
    pref_cache = build_preference_cache(params)
    rng = np.random.default_rng(seed=seed)

    lag1_pts = None
    lag2_pts = None
    lag3_pts = None
    lag1_exp = None
    lag2_exp = None
    lag3_exp = None
    all_results = {}

    # Accumulator for country-sport points in regression years
    accum_points = np.zeros((n_countries, n_sports))

    for gi, game_year in enumerate(GAME_YEARS):
        if game_year in SEED_YEARS:
            current_pts = {}
            current_exp = {}
            source_year = 1992 if game_year in (1984, 1988) else game_year
            for ci, c in enumerate(all_countries):
                for si, s in enumerate(all_sports):
                    pts = empirical_pts.get((c, s, source_year), 0.0)
                    all_results[(ci, si, game_year)] = pts
                    current_pts[(ci, si)] = pts
                    # Experience from seed data
                    exp_val = empirical_exp.get((ci, si, source_year), 0.0)
                    if exp_val == 0 and pts > 0:
                        # Fallback: estimate experience from points
                        exp_val = pts * 5
                    current_exp[(ci, si)] = exp_val
            lag3_pts = lag2_pts
            lag2_pts = lag1_pts
            lag1_pts = current_pts
            lag3_exp = lag2_exp
            lag2_exp = lag1_exp
            lag1_exp = current_exp
            continue

        # Layer 1 with Dagum
        quality = compute_quality_L1_dagum(params, game_year, lag1_pts, pref_cache)
        # Layer 2
        quality = compute_quality_L2(quality, params, game_year)
        # Layer 3: experience-based persistence
        quality = compute_quality_L3(quality, params, game_year,
                                     lag1_exp, lag2_exp, lag3_exp)

        # Between-games noise
        noise_sd = params.get('noise_sd', 0.0)
        if noise_sd > 0:
            quality += rng.normal(0, noise_sd, size=quality.shape)

        # Tournament
        points, experience = run_tournament_gumbel(quality, game_year, rng, params)

        current_pts = {}
        current_exp = {}
        for ci in range(n_countries):
            for si in range(n_sports):
                all_results[(ci, si, game_year)] = points[ci, si]
                current_pts[(ci, si)] = points[ci, si]
                current_exp[(ci, si)] = experience[ci, si]

        # Accumulate for regression years
        if game_year in REGRESSION_YEARS:
            accum_points += points

        lag3_pts = lag2_pts
        lag2_pts = lag1_pts
        lag1_pts = current_pts
        lag3_exp = lag2_exp
        lag2_exp = lag1_exp
        lag1_exp = current_exp

    return all_results, accum_points


# ============================================================================
# REGRESSION
# ============================================================================

def run_regression_on_simulated(sim_results, sport_type='individual', gdp_half='upper',
                                include_lag=True, exclude_usa=False):
    rows = []
    for gi, game_year in enumerate(GAME_YEARS):
        if game_year not in REGRESSION_YEARS:
            continue
        for ci, country in enumerate(all_countries):
            if exclude_usa and country == 'United States':
                continue
            cgv = country_game_vars.get((country, game_year))
            if cgv is None:
                continue
            for si, sport in enumerate(all_sports):
                pts = sim_results.get((ci, si, game_year), 0.0)
                prev_year_idx = gi - 1
                lag1 = sim_results.get((ci, si, GAME_YEARS[prev_year_idx]), 0.0) if prev_year_idx >= 0 else None
                prev2_year_idx = gi - 2
                lag2 = sim_results.get((ci, si, GAME_YEARS[prev2_year_idx]), 0.0) if prev2_year_idx >= 0 else None

                rows.append({
                    'country': country, 'sport_name': sport, 'game_year': game_year,
                    'olympic_6pt': pts, 'lag1_olympic_6pt': lag1, 'lag2_olympic_6pt': lag2,
                    'gdp_pc_ppp': cgv['gdp_pc_ppp'], 'population': cgv['population'],
                    'gini': cgv['gini'], 'soviet_legacy': cgv['soviet_legacy'],
                    'pct_christian': cgv['pct_christian'], 'pct_muslim': cgv['pct_muslim'],
                    'pct_hindu': cgv['pct_hindu'], 'pct_buddhist': cgv['pct_buddhist'],
                    'noc': cgv['noc'],
                    'cost_equip_eur_pr_year': equip_cost[si],
                    'cost_national_facility_eur': facility_cost[si],
                    'sport_type': sport_types[si],
                })

    # GDP classification: fixed set from panel's upper_gdp_half field
    # Uses the same 36 countries as the empirical regression
    if gdp_half:
        if gdp_half == 'upper':
            upper_nocs = _UPPER_GDP_NOCS
        else:
            upper_nocs = {r['noc'] for r in game_panel} - _UPPER_GDP_NOCS
    else:
        upper_nocs = None

    filtered = rows
    if sport_type:
        filtered = [r for r in filtered if r['sport_type'] == sport_type]
    filtered = [r for r in filtered if r['olympic_6pt'] > 0]
    if upper_nocs is not None:
        filtered = [r for r in filtered if r['noc'] in upper_nocs]

    if len(filtered) < 50:
        return None

    data = []
    for r in filtered:
        eq = r['cost_equip_eur_pr_year']
        gdp = r['gdp_pc_ppp']
        pop = r['population']
        gini = r['gini']
        if any(v is None or v <= 0 for v in [eq, gdp, pop]) or gini is None:
            continue
        d = {
            'olympic_6pt': r['olympic_6pt'],
            'gini': gini,
            'gini_x_lnequip': gini * np.log(eq),
            'ln_gdp': np.log(gdp),
            'ln_pop': np.log(pop),
            'soviet': 1.0 if r['soviet_legacy'] else 0.0,
            'pct_christian': r['pct_christian'],
            'pct_muslim': r['pct_muslim'],
            'pct_buddhist': r['pct_buddhist'],
            'pct_hindu': r['pct_hindu'],
            'sport_name': r['sport_name'],
            'game_year': r['game_year'],
        }
        if include_lag:
            lag1 = r['lag1_olympic_6pt']
            lag2 = r['lag2_olympic_6pt']
            if lag1 is None or lag2 is None:
                continue
            d['ln_lag1'] = np.log(1 + lag1)
            d['ln_lag2'] = np.log(1 + lag2)
        data.append(d)

    if len(data) < 50:
        return None

    y = np.array([d['olympic_6pt'] for d in data])
    var_names = ['const', 'gini', 'gini_x_lnequip', 'ln_gdp', 'ln_pop',
                 'soviet', 'pct_christian', 'pct_muslim', 'pct_buddhist', 'pct_hindu']
    if include_lag:
        var_names += ['ln_lag1', 'ln_lag2']

    all_sp = sorted(set(d['sport_name'] for d in data))
    sport_dummies = all_sp[1:]
    var_names += [f'sport_{s}' for s in sport_dummies]

    all_gm = sorted(set(d['game_year'] for d in data))
    game_dummies = all_gm[1:]
    var_names += [f'game_{g}' for g in game_dummies]

    X = []
    for d in data:
        row = [1.0, d['gini'], d['gini_x_lnequip'], d['ln_gdp'], d['ln_pop'],
               d['soviet'], d['pct_christian'], d['pct_muslim'], d['pct_buddhist'], d['pct_hindu']]
        if include_lag:
            row += [d['ln_lag1'], d['ln_lag2']]
        for s in sport_dummies:
            row.append(1.0 if d['sport_name'] == s else 0.0)
        for g in game_dummies:
            row.append(1.0 if d['game_year'] == g else 0.0)
        X.append(row)

    X = np.array(X)
    n, k = X.shape
    if n <= k:
        return None

    try:
        beta_hat = np.linalg.lstsq(X, y, rcond=None)[0]
    except np.linalg.LinAlgError:
        return None

    resid = y - X @ beta_hat
    sse = resid @ resid
    sst = np.sum((y - np.mean(y)) ** 2)
    r2 = 1 - sse / sst if sst > 0 else 0
    dof = n - k

    try:
        XtX_inv = np.linalg.inv(X.T @ X)
    except:
        XtX_inv = np.linalg.pinv(X.T @ X)

    e2 = resid ** 2
    meat = X.T @ (X * e2[:, None])
    V_HC1 = (n / dof) * XtX_inv @ meat @ XtX_inv
    se = np.sqrt(np.maximum(np.diag(V_HC1), 0))

    idx_gxe = var_names.index('gini_x_lnequip')
    return {
        'gini_x_ln_equip': float(beta_hat[idx_gxe]),
        'gini_x_ln_equip_se': float(se[idx_gxe]),
        'n': n,
        'r2': round(r2, 6),
    }


def run_fourway_regression(sim_results, sport_type='individual', gdp_half='upper',
                           include_lag=True, exclude_usa=False):
    """Four-way regression: Gini x equip + GDP x facility + GDP x equip + Gini x facility."""
    rows = []
    for gi, game_year in enumerate(GAME_YEARS):
        if game_year not in REGRESSION_YEARS:
            continue
        for ci, country in enumerate(all_countries):
            if exclude_usa and country == 'United States':
                continue
            cgv = country_game_vars.get((country, game_year))
            if cgv is None:
                continue
            for si, sport in enumerate(all_sports):
                pts = sim_results.get((ci, si, game_year), 0.0)
                prev_year_idx = gi - 1
                lag1 = sim_results.get((ci, si, GAME_YEARS[prev_year_idx]), 0.0) if prev_year_idx >= 0 else None
                prev2_year_idx = gi - 2
                lag2 = sim_results.get((ci, si, GAME_YEARS[prev2_year_idx]), 0.0) if prev2_year_idx >= 0 else None

                rows.append({
                    'country': country, 'sport_name': sport, 'game_year': game_year,
                    'olympic_6pt': pts, 'lag1_olympic_6pt': lag1, 'lag2_olympic_6pt': lag2,
                    'gdp_pc_ppp': cgv['gdp_pc_ppp'], 'population': cgv['population'],
                    'gini': cgv['gini'], 'soviet_legacy': cgv['soviet_legacy'],
                    'pct_christian': cgv['pct_christian'], 'pct_muslim': cgv['pct_muslim'],
                    'pct_hindu': cgv['pct_hindu'], 'pct_buddhist': cgv['pct_buddhist'],
                    'noc': cgv['noc'],
                    'cost_equip_eur_pr_year': equip_cost[si],
                    'cost_national_facility_eur': facility_cost[si],
                    'sport_type': sport_types[si],
                })

    if gdp_half == 'upper':
        upper_nocs = _UPPER_GDP_NOCS
    else:
        upper_nocs = None

    filtered = rows
    if sport_type:
        filtered = [r for r in filtered if r['sport_type'] == sport_type]
    filtered = [r for r in filtered if r['olympic_6pt'] > 0]
    if upper_nocs is not None:
        filtered = [r for r in filtered if r['noc'] in upper_nocs]

    if len(filtered) < 50:
        return None

    data = []
    for r in filtered:
        eq = r['cost_equip_eur_pr_year']
        fac = r['cost_national_facility_eur']
        gdp = r['gdp_pc_ppp']
        pop = r['population']
        gini = r['gini']
        if any(v is None or v <= 0 for v in [eq, fac, gdp, pop]) or gini is None:
            continue
        d = {
            'olympic_6pt': r['olympic_6pt'],
            'gini': gini,
            'gini_x_lnequip': gini * np.log(eq),
            'gdp_x_lnfac': np.log(gdp) * np.log(fac),
            'gdp_x_lnequip': np.log(gdp) * np.log(eq),
            'gini_x_lnfac': gini * np.log(fac),
            'ln_gdp': np.log(gdp),
            'ln_pop': np.log(pop),
            'soviet': 1.0 if r['soviet_legacy'] else 0.0,
            'pct_christian': r['pct_christian'],
            'pct_muslim': r['pct_muslim'],
            'pct_buddhist': r['pct_buddhist'],
            'pct_hindu': r['pct_hindu'],
            'sport_name': r['sport_name'],
            'game_year': r['game_year'],
        }
        if include_lag:
            lag1 = r['lag1_olympic_6pt']
            lag2 = r['lag2_olympic_6pt']
            if lag1 is None or lag2 is None:
                continue
            d['ln_lag1'] = np.log(1 + lag1)
            d['ln_lag2'] = np.log(1 + lag2)
        data.append(d)

    if len(data) < 50:
        return None

    y = np.array([d['olympic_6pt'] for d in data])
    var_names = ['const', 'gini', 'gini_x_lnequip', 'gdp_x_lnfac',
                 'gdp_x_lnequip', 'gini_x_lnfac',
                 'ln_gdp', 'ln_pop',
                 'soviet', 'pct_christian', 'pct_muslim', 'pct_buddhist', 'pct_hindu']
    if include_lag:
        var_names += ['ln_lag1', 'ln_lag2']

    all_sp = sorted(set(d['sport_name'] for d in data))
    sport_dummies = all_sp[1:]
    var_names += [f'sport_{s}' for s in sport_dummies]

    all_gm = sorted(set(d['game_year'] for d in data))
    game_dummies = all_gm[1:]
    var_names += [f'game_{g}' for g in game_dummies]

    X = []
    for d in data:
        row = [1.0, d['gini'], d['gini_x_lnequip'], d['gdp_x_lnfac'],
               d['gdp_x_lnequip'], d['gini_x_lnfac'],
               d['ln_gdp'], d['ln_pop'],
               d['soviet'], d['pct_christian'], d['pct_muslim'], d['pct_buddhist'], d['pct_hindu']]
        if include_lag:
            row += [d['ln_lag1'], d['ln_lag2']]
        for s in sport_dummies:
            row.append(1.0 if d['sport_name'] == s else 0.0)
        for g in game_dummies:
            row.append(1.0 if d['game_year'] == g else 0.0)
        X.append(row)

    X = np.array(X)
    n, k = X.shape
    if n <= k:
        return None

    try:
        beta_hat = np.linalg.lstsq(X, y, rcond=None)[0]
    except np.linalg.LinAlgError:
        return None

    resid = y - X @ beta_hat
    sse = resid @ resid
    sst = np.sum((y - np.mean(y)) ** 2)
    r2 = 1 - sse / sst if sst > 0 else 0
    dof = n - k

    try:
        XtX_inv = np.linalg.inv(X.T @ X)
    except:
        XtX_inv = np.linalg.pinv(X.T @ X)

    e2 = resid ** 2
    meat = X.T @ (X * e2[:, None])
    V_HC1 = (n / dof) * XtX_inv @ meat @ XtX_inv
    se = np.sqrt(np.maximum(np.diag(V_HC1), 0))

    result = {'n': n, 'r2': round(r2, 6)}
    for vname in ['gini_x_lnequip', 'gdp_x_lnfac', 'gdp_x_lnequip', 'gini_x_lnfac']:
        idx = var_names.index(vname)
        result[vname] = float(beta_hat[idx])
        result[vname + '_se'] = float(se[idx])
    return result


# ============================================================================
# MAIN
# ============================================================================

if __name__ == '__main__':
    print(f"v1.06 Production Simulation")
    print(f"{'='*70}")

    start_time = time.time()

    all_gradients = []
    all_gradients_no_usa = []
    all_fourway = []
    total_accum = np.zeros((n_countries, n_sports))

    for run_idx in range(n_runs):
        seed = base_seed + run_idx
        if run_idx % 10 == 0:
            print(f"  Run {run_idx+1}/{n_runs} (seed={seed})...", flush=True)

        sim_results, accum_points = run_full_simulation(params, seed=seed)
        total_accum += accum_points

        # Regression: individual, upper GDP, with lags
        res = run_regression_on_simulated(sim_results)
        if res:
            all_gradients.append(res['gini_x_ln_equip'])

        res_nu = run_regression_on_simulated(sim_results, exclude_usa=True)
        if res_nu:
            all_gradients_no_usa.append(res_nu['gini_x_ln_equip'])

        # Four-way regression: both channels
        res_4w = run_fourway_regression(sim_results)
        if res_4w:
            all_fourway.append(res_4w)

    avg_accum = total_accum / n_runs
    elapsed = time.time() - start_time

    # Summary
    mean_grad = np.mean(all_gradients)
    ci_lo = np.percentile(all_gradients, 2.5)
    ci_hi = np.percentile(all_gradients, 97.5)
    n_neg = sum(1 for g in all_gradients if g < 0)
    mean_grad_nu = np.mean(all_gradients_no_usa)

    # Four-way summary
    fourway_means = {}
    if all_fourway:
        for vname in ['gini_x_lnequip', 'gdp_x_lnfac', 'gdp_x_lnequip', 'gini_x_lnfac']:
            vals = [r[vname] for r in all_fourway if vname in r]
            if vals:
                fourway_means[vname] = {
                    'mean': float(np.mean(vals)),
                    'sd': float(np.std(vals)),
                    'ci_lo': float(np.percentile(vals, 2.5)),
                    'ci_hi': float(np.percentile(vals, 97.5)),
                }

    print(f"\n{'='*70}")
    print(f"RESULTS ({n_runs} seeds, {elapsed:.0f}s)")
    print(f"  Gradient: {mean_grad:.4f} (95% CI: {ci_lo:.4f} to {ci_hi:.4f})")
    print(f"  Negative: {n_neg}/{len(all_gradients)}")
    print(f"  % of empirical (-0.6776): {mean_grad / -0.6776 * 100:.0f}%")
    print(f"  Excl USA: {mean_grad_nu:.4f}")
    if fourway_means:
        print(f"\n  Four-way regression (mean across {len(all_fourway)} seeds):")
        print(f"    Gini x ln(equip):    {fourway_means.get('gini_x_lnequip', {}).get('mean', 0):.4f}  (emp: -0.70)")
        print(f"    GDP x ln(facility):  {fourway_means.get('gdp_x_lnfac', {}).get('mean', 0):.4f}  (emp: 0.45)")
        print(f"    GDP x ln(equip):     {fourway_means.get('gdp_x_lnequip', {}).get('mean', 0):.4f}  (emp: ~0)")
        print(f"    Gini x ln(facility): {fourway_means.get('gini_x_lnfac', {}).get('mean', 0):.4f}  (emp: ~0)")

    # Save accumulated country-sport points
    country_sport_output = {}
    for ci, c in enumerate(all_countries):
        for si, s in enumerate(all_sports):
            val = float(avg_accum[ci, si])
            if val > 0:
                country_sport_output[f"{c}|{s}"] = round(val, 2)

    # Save empirical accumulated points for comparison
    emp_accum = defaultdict(float)
    for r in game_panel:
        if r['game_year'] in REGRESSION_YEARS and r['sport_name'] in sport_to_idx:
            emp_accum[f"{r['country']}|{r['sport_name']}"] += r['olympic_6pt']

    output = {
        'metadata': {
            'version': '1.06',
            'timestamp': datetime.utcnow().isoformat() + 'Z',
            'n_runs': n_runs,
            'base_seed': base_seed,
            'regression_years': sorted(REGRESSION_YEARS),
        },
        'gradient': {
            'mean': round(float(mean_grad), 6),
            'ci_lo': round(float(ci_lo), 6),
            'ci_hi': round(float(ci_hi), 6),
            'n_negative': n_neg,
            'n_total': len(all_gradients),
            'empirical': -0.6776,
            'pct_reproduced': round(float(mean_grad / -0.6776 * 100), 1),
        },
        'gradient_excl_usa': {
            'mean': round(float(mean_grad_nu), 6),
            'empirical': -0.2215,
        },
        'fourway_regression': fourway_means,
        'simulated_country_sport_points': country_sport_output,
        'empirical_country_sport_points': dict(emp_accum),
    }

    out_path = os.path.join(RESULTS_DIR, 'v106_simulation_results.json')
    with open(out_path, 'w') as f:
        json.dump(output, f, indent=2, default=lambda x: float(x) if hasattr(x, 'item') else x)

    print(f"\nSaved to {out_path}")
    print("DONE")
