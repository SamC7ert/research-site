#!/usr/bin/env python3
"""
v1.06 Two-Way Clustering Robustness Check
==========================================
Cameron, Gelbach & Miller (2011) two-way clustering by country AND sport.

V_twoway = V_country + V_sport - V_country×sport

Compares standard errors and significance levels for key specifications
against the one-way (country-only) baseline.

Input:  ../data/v106_game_level_panel.json
Output: ../results/v106_twoway_clustering.json  (+ console report)
"""

import json
import os
import sys
import numpy as np
from collections import defaultdict
from scipy import stats as spstats
import warnings
warnings.filterwarnings('ignore')

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, '..', 'data')
RESULTS_DIR = os.path.join(SCRIPT_DIR, '..', 'results')
os.makedirs(RESULTS_DIR, exist_ok=True)

# ============================================================
# LOAD DATA (same as main pipeline)
# ============================================================
print("=" * 70)
print("TWO-WAY CLUSTERING ROBUSTNESS CHECK")
print("  Cameron, Gelbach & Miller (2011)")
print("  V_twoway = V_country + V_sport - V_intersection")
print("=" * 70)

with open(os.path.join(DATA_DIR, 'v106_game_level_panel.json')) as f:
    raw_rows = json.load(f)
print(f"Loaded: {len(raw_rows)} total rows")

reg_rows = [r for r in raw_rows if r.get('regression_eligible')]
print(f"Regression sample (2000-2024): {len(reg_rows)} rows")

# Compute lag2
_pts_lookup = {}
for r in raw_rows:
    _pts_lookup[(r['noc'], r['sport_name'], r['game_year'])] = r['olympic_6pt']

_game_years = sorted(set(r['game_year'] for r in raw_rows))
_gi_to_year = {i: y for i, y in enumerate(_game_years)}
_year_to_gi = {y: i for i, y in enumerate(_game_years)}

for r in raw_rows:
    gi = _year_to_gi[r['game_year']]
    if gi >= 2:
        prev2_year = _gi_to_year[gi - 2]
        r['lag2_olympic_6pt'] = _pts_lookup.get((r['noc'], r['sport_name'], prev2_year), 0.0)
    else:
        r['lag2_olympic_6pt'] = None

RELIGION_COLS = ['pct_muslim', 'pct_hindu', 'pct_buddhist', 'pct_christian']

# GDP split: use upper_gdp_half from panel if available, else compute dynamically
def compute_gdp_ranking(rows):
    if rows and 'upper_gdp_half' in rows[0]:
        upper_nocs = set()
        lower_nocs = set()
        gdp_by_noc = defaultdict(list)
        for r in rows:
            if r['gdp_pc_ppp'] is not None:
                gdp_by_noc[r['noc']].append(r['gdp_pc_ppp'])
            if r.get('upper_gdp_half'):
                upper_nocs.add(r['noc'])
            else:
                lower_nocs.add(r['noc'])
        gdp_avg = {noc: np.mean(list(set(gs))) for noc, gs in gdp_by_noc.items()}
        median_gdp = np.median(list(gdp_avg.values()))
        return gdp_avg, median_gdp, upper_nocs, lower_nocs
    gdp_by_noc = defaultdict(list)
    for r in rows:
        if r['gdp_pc_ppp'] is not None:
            gdp_by_noc[r['noc']].append(r['gdp_pc_ppp'])
    gdp_avg = {}
    for noc, gdps in gdp_by_noc.items():
        unique_gdps = list(set(gdps))
        gdp_avg[noc] = np.mean(unique_gdps)
    median_gdp = np.median(list(gdp_avg.values()))
    upper_nocs = {noc for noc, g in gdp_avg.items() if g >= median_gdp}
    lower_nocs = {noc for noc, g in gdp_avg.items() if g < median_gdp}
    return gdp_avg, median_gdp, upper_nocs, lower_nocs

GDP_AVG, GDP_MEDIAN, UPPER_NOCS, LOWER_NOCS = compute_gdp_ranking(reg_rows)
print(f"GDP split: median ${GDP_MEDIAN:,.0f}, upper={len(UPPER_NOCS)}, lower={len(LOWER_NOCS)}")


# ============================================================
# CLUSTERING ENGINE
# ============================================================

def _cluster_meat(X, resid, cluster_ids):
    """Compute the clustered 'meat' of the sandwich estimator for one dimension."""
    k = X.shape[1]
    cluster_ids = np.array(cluster_ids)
    unique = np.unique(cluster_ids)
    G = len(unique)
    meat = np.zeros((k, k))
    for cl in unique:
        idx = cluster_ids == cl
        Xi = X[idx]
        ei = resid[idx]
        score = Xi.T @ ei
        meat += np.outer(score, score)
    return meat, G


def ols_twoway(y, X, var_names, country_ids, sport_ids):
    """OLS with one-way AND two-way clustered standard errors.

    Returns a result dict with both sets of SEs so they can be compared.
    Two-way: V = V_country + V_sport - V_intersection
    where intersection clusters are unique (country, sport) pairs.
    """
    y = np.array(y, dtype=float)
    X = np.array(X, dtype=float)
    n, k = X.shape

    if n <= k + 1:
        return None

    try:
        beta = np.linalg.lstsq(X, y, rcond=None)[0]
    except np.linalg.LinAlgError:
        return None

    resid = y - X @ beta
    sse = resid @ resid
    sst = np.sum((y - np.mean(y))**2)
    r2 = 1 - sse / sst if sst > 0 else 0
    dof = n - k

    try:
        XtX_inv = np.linalg.inv(X.T @ X)
    except np.linalg.LinAlgError:
        try:
            XtX_inv = np.linalg.pinv(X.T @ X)
        except:
            return None

    country_ids = np.array(country_ids)
    sport_ids = np.array(sport_ids)

    # Intersection clusters: unique (country, sport) pairs
    intersection_ids = np.array([f"{c}_{s}" for c, s in zip(country_ids, sport_ids)])

    # One-way (country only) — baseline
    meat_c, G_c = _cluster_meat(X, resid, country_ids)
    scale_c = (G_c / (G_c - 1)) * (n / dof)
    V_country = scale_c * XtX_inv @ meat_c @ XtX_inv

    # One-way (sport only)
    meat_s, G_s = _cluster_meat(X, resid, sport_ids)
    scale_s = (G_s / (G_s - 1)) * (n / dof)
    V_sport = scale_s * XtX_inv @ meat_s @ XtX_inv

    # Intersection
    meat_i, G_i = _cluster_meat(X, resid, intersection_ids)
    scale_i = (G_i / (G_i - 1)) * (n / dof)
    V_inter = scale_i * XtX_inv @ meat_i @ XtX_inv

    # Two-way: Cameron, Gelbach & Miller (2011)
    V_twoway = V_country + V_sport - V_inter

    # Fix potential negative diagonal elements (can happen with few clusters)
    # by flooring at the country-only variance
    diag_tw = np.diag(V_twoway).copy()
    diag_c = np.diag(V_country)
    for i in range(k):
        if diag_tw[i] < 0:
            diag_tw[i] = diag_c[i]  # fall back to country-only

    # Compute SEs and p-values for both
    def _compute_inference(V_mat, dof_p):
        se = np.sqrt(np.maximum(np.diag(V_mat), 0))
        t_stats = np.where(se > 0, beta / se, 0)
        p_vals = 2 * (1 - spstats.t.cdf(np.abs(t_stats), dof_p))
        return se, t_stats, p_vals

    se_1w, t_1w, p_1w = _compute_inference(V_country, G_c - 1)

    # For two-way, use min(G_c, G_s) - 1 as conservative dof
    dof_tw = min(G_c, G_s) - 1
    se_tw_raw = np.sqrt(np.maximum(diag_tw, 0))
    t_tw = np.where(se_tw_raw > 0, beta / se_tw_raw, 0)
    p_tw = 2 * (1 - spstats.t.cdf(np.abs(t_tw), dof_tw))

    names = var_names or [f'x{i}' for i in range(k)]

    result = {
        'n': n,
        'k': k,
        'r2': round(r2, 6),
        'n_country_clusters': int(G_c),
        'n_sport_clusters': int(G_s),
        'n_intersection_clusters': int(G_i),
        'dof_oneway': int(G_c - 1),
        'dof_twoway': int(dof_tw),
        'coefficients': {},
    }

    for i, name in enumerate(names):
        result['coefficients'][name] = {
            'beta': round(float(beta[i]), 6),
            'se_1way': round(float(se_1w[i]), 6),
            'p_1way': round(float(p_1w[i]), 6),
            'se_2way': round(float(se_tw_raw[i]), 6),
            'p_2way': round(float(p_tw[i]), 6),
            'se_ratio': round(float(se_tw_raw[i] / se_1w[i]), 4) if se_1w[i] > 0 else None,
        }

    return result


# ============================================================
# DATA HELPERS (from main pipeline)
# ============================================================

def subset(rows, sport_type=None, gdp_half=None, drop_zeros=True):
    out = rows
    if sport_type:
        out = [r for r in out if r['sport_type'] == sport_type]
    if drop_zeros:
        out = [r for r in out if r['olympic_6pt'] > 0]
    if gdp_half:
        if gdp_half == 'upper':
            out = [r for r in out if r['noc'] in UPPER_NOCS]
        elif gdp_half == 'lower':
            out = [r for r in out if r['noc'] in LOWER_NOCS]
    return out


def build_matrices_2way(rows, control='religion',
                        include_lag=True, include_lag2=True,
                        cost_var='cost_equip_eur_pr_year',
                        facility_var=None,
                        include_gini_x_cost=True,
                        include_gdp_x_fac=False,
                        include_gini_x_fac=False,
                        include_gdp_x_cost=False,
                        sport_fe=True, game_fe=True):
    """Build y, X, var_names, country_ids, sport_ids for two-way clustering."""
    data = []
    country_ids = []
    sport_ids = []

    for r in rows:
        equip = r.get(cost_var)
        gdp = r['gdp_pc_ppp']
        pop = r['population']
        gini = r['gini']
        if any(v is None for v in [equip, gdp, pop, gini]):
            continue
        if equip <= 0 or gdp <= 0 or pop <= 0:
            continue

        ln_equip = np.log(equip)
        ln_fac = None
        if facility_var:
            fac = r.get(facility_var)
            if fac is None or fac <= 0:
                continue
            ln_fac = np.log(fac)

        d = {
            'olympic_6pt': r['olympic_6pt'],
            'gini': gini,
            'gini_x_cost': gini * ln_equip,
            'sport_name': r['sport_name'],
            'game_year': r['game_year'],
            'noc': r['noc'],
            'ln_gdp': np.log(gdp),
            'ln_pop': np.log(pop),
            'soviet': 1.0 if r.get('soviet_legacy') else 0.0,
        }

        if control == 'religion':
            for rc in RELIGION_COLS:
                d[rc] = r.get(rc, 0) or 0
        elif control == 'region':
            d['region_id'] = r.get('region_id')

        if include_lag:
            lag = r.get('lag_olympic_6pt')
            if lag is None:
                continue
            d['ln_lag'] = np.log(1 + lag)

        if include_lag2:
            lag2 = r.get('lag2_olympic_6pt')
            if lag2 is None:
                continue
            d['ln_lag2'] = np.log(1 + lag2)

        if ln_fac is not None:
            if include_gdp_x_fac:
                d['gdp_x_fac'] = np.log(gdp) * ln_fac
            if include_gini_x_fac:
                d['gini_x_fac'] = gini * ln_fac
            if include_gdp_x_cost:
                d['gdp_x_cost'] = np.log(gdp) * ln_equip

        data.append(d)
        country_ids.append(r['noc'])
        sport_ids.append(r['sport_name'])

    if not data or len(data) < 30:
        return None, None, None, None, None

    y = np.array([d['olympic_6pt'] for d in data])

    # Build var_names
    var_names = ['const', 'ln_gdp', 'ln_pop', 'soviet', 'gini']
    if include_gini_x_cost:
        var_names.append('gini_x_cost')

    if control == 'religion':
        var_names += list(RELIGION_COLS)
    elif control == 'region':
        all_regions = sorted(set(d['region_id'] for d in data if d.get('region_id') is not None))
        ref_region = max(all_regions) if all_regions else 10
        region_dummies = [r for r in all_regions if r != ref_region]
        var_names += [f'region_{r}' for r in region_dummies]

    if include_lag:
        var_names.append('ln_lag')
    if include_lag2:
        var_names.append('ln_lag2')

    if include_gdp_x_fac:
        var_names.append('gdp_x_fac')
    if include_gini_x_fac:
        var_names.append('gini_x_fac')
    if include_gdp_x_cost:
        var_names.append('gdp_x_cost')

    # Sport FE
    sport_dummies = []
    if sport_fe:
        all_sports = sorted(set(d['sport_name'] for d in data))
        sport_dummies = all_sports[1:]
        var_names += [f'sport_{s}' for s in sport_dummies]

    # Game FE
    game_dummies = []
    if game_fe:
        all_games = sorted(set(d['game_year'] for d in data))
        game_dummies = all_games[1:]
        var_names += [f'game_{g}' for g in game_dummies]

    # Build X
    X = []
    for d in data:
        row = [1.0, d['ln_gdp'], d['ln_pop'], d['soviet'], d['gini']]
        if include_gini_x_cost:
            row.append(d['gini_x_cost'])

        if control == 'religion':
            for rc in RELIGION_COLS:
                row.append(d[rc])
        elif control == 'region':
            for r_id in region_dummies:
                row.append(1.0 if d.get('region_id') == r_id else 0.0)

        if include_lag:
            row.append(d['ln_lag'])
        if include_lag2:
            row.append(d['ln_lag2'])

        if include_gdp_x_fac:
            row.append(d.get('gdp_x_fac', 0))
        if include_gini_x_fac:
            row.append(d.get('gini_x_fac', 0))
        if include_gdp_x_cost:
            row.append(d.get('gdp_x_cost', 0))

        for s in sport_dummies:
            row.append(1.0 if d['sport_name'] == s else 0.0)
        for g in game_dummies:
            row.append(1.0 if d['game_year'] == g else 0.0)

        X.append(row)

    return y, np.array(X), var_names, country_ids, sport_ids


# ============================================================
# KEY VARIABLES TO REPORT
# ============================================================
KEY_VARS = ['gini_x_cost', 'gini', 'ln_gdp', 'ln_pop', 'ln_lag', 'ln_lag2']


def print_comparison(label, res):
    """Print side-by-side comparison of one-way vs two-way SEs."""
    if res is None:
        print(f"\n  {label}: no result")
        return

    print(f"\n  {label}")
    print(f"  n={res['n']}, R²={res['r2']:.4f}")
    print(f"  Country clusters: {res['n_country_clusters']}, "
          f"Sport clusters: {res['n_sport_clusters']}, "
          f"Intersection: {res['n_intersection_clusters']}")
    print(f"  {'Variable':<20} {'β':>10} {'SE(1way)':>10} {'SE(2way)':>10} "
          f"{'Ratio':>8} {'p(1way)':>10} {'p(2way)':>10} {'Δ sig?':>8}")
    print(f"  {'-'*88}")

    for var in KEY_VARS:
        c = res['coefficients'].get(var)
        if c is None:
            continue
        beta = c['beta']
        se1 = c['se_1way']
        se2 = c['se_2way']
        p1 = c['p_1way']
        p2 = c['p_2way']
        ratio = c['se_ratio'] if c['se_ratio'] else 0

        # Check if significance level changes
        def sig_level(p):
            if p < 0.001: return '***'
            if p < 0.01: return '**'
            if p < 0.05: return '*'
            if p < 0.10: return '†'
            return 'n.s.'

        s1 = sig_level(p1)
        s2 = sig_level(p2)
        changed = '  YES' if s1 != s2 else ''

        print(f"  {var:<20} {beta:>10.4f} {se1:>10.4f} {se2:>10.4f} "
              f"{ratio:>8.3f} {p1:>8.4f}{s1:>3} {p2:>8.4f}{s2:>3} {changed}")


def sig_star(p):
    if p < 0.001: return '***'
    if p < 0.01: return '**'
    if p < 0.05: return '*'
    return ''


# ============================================================
# RUN KEY SPECIFICATIONS
# ============================================================

results = {}

# --- Spec 1: Individual sports, upper GDP, with lags (primary) ---
print("\n" + "=" * 70)
print("SPECIFICATION COMPARISONS: ONE-WAY vs TWO-WAY CLUSTERING")
print("=" * 70)

sub = subset(reg_rows, sport_type='individual', gdp_half='upper')
y, X, names, cl_c, cl_s = build_matrices_2way(sub, control='religion')
if y is not None:
    res = ols_twoway(y, X, names, cl_c, cl_s)
    print_comparison("Individual, Upper GDP, With Lags (PRIMARY)", res)
    results['individual_upper_lags'] = res

# --- Spec 2: Individual sports, upper GDP, NO lags ---
y, X, names, cl_c, cl_s = build_matrices_2way(sub, control='religion',
                                                include_lag=False, include_lag2=False)
if y is not None:
    res = ols_twoway(y, X, names, cl_c, cl_s)
    print_comparison("Individual, Upper GDP, No Lags", res)
    results['individual_upper_nolags'] = res

# --- Spec 3: Individual sports, full sample, with lags ---
sub_full = subset(reg_rows, sport_type='individual')
y, X, names, cl_c, cl_s = build_matrices_2way(sub_full, control='religion')
if y is not None:
    res = ols_twoway(y, X, names, cl_c, cl_s)
    print_comparison("Individual, Full Sample, With Lags", res)
    results['individual_full_lags'] = res

# --- Spec 4: Individual sports, full sample, no lags ---
y, X, names, cl_c, cl_s = build_matrices_2way(sub_full, control='religion',
                                                include_lag=False, include_lag2=False)
if y is not None:
    res = ols_twoway(y, X, names, cl_c, cl_s)
    print_comparison("Individual, Full Sample, No Lags", res)
    results['individual_full_nolags'] = res

# --- Spec 5: Team sports, full sample, with lags ---
sub_team = subset(reg_rows, sport_type='team')
y, X, names, cl_c, cl_s = build_matrices_2way(sub_team, control='religion')
if y is not None:
    res = ols_twoway(y, X, names, cl_c, cl_s)
    print_comparison("Team, Full Sample, With Lags", res)
    results['team_full_lags'] = res

# --- Spec 6: Four-way model (individual, upper GDP) ---
sub_upper_ind = subset(reg_rows, sport_type='individual', gdp_half='upper')
y, X, names, cl_c, cl_s = build_matrices_2way(
    sub_upper_ind, control='religion',
    facility_var='cost_national_facility_eur',
    include_gdp_x_fac=True,
    include_gini_x_fac=True,
    include_gdp_x_cost=True
)
if y is not None:
    res = ols_twoway(y, X, names, cl_c, cl_s)
    four_way_vars = KEY_VARS + ['gdp_x_fac', 'gini_x_fac', 'gdp_x_cost']
    print_comparison("Four-Way Model, Individual, Upper GDP", res)
    # Also print the extra four-way vars
    for var in ['gdp_x_fac', 'gini_x_fac', 'gdp_x_cost']:
        c = res['coefficients'].get(var)
        if c:
            print(f"  {var:<20} {c['beta']:>10.4f} {c['se_1way']:>10.4f} {c['se_2way']:>10.4f} "
                  f"{c['se_ratio']:>8.3f} {c['p_1way']:>8.4f}{'***' if c['p_1way']<0.001 else '**' if c['p_1way']<0.01 else '*' if c['p_1way']<0.05 else '':>3} "
                  f"{c['p_2way']:>8.4f}{'***' if c['p_2way']<0.001 else '**' if c['p_2way']<0.01 else '*' if c['p_2way']<0.05 else '':>3}")
    results['four_way_upper'] = res

# --- Spec 7: Region controls instead of religion ---
y, X, names, cl_c, cl_s = build_matrices_2way(
    subset(reg_rows, sport_type='individual', gdp_half='upper'),
    control='region'
)
if y is not None:
    res = ols_twoway(y, X, names, cl_c, cl_s)
    print_comparison("Individual, Upper GDP, Region Controls", res)
    results['individual_upper_region'] = res


# ============================================================
# SUMMARY TABLE
# ============================================================
print("\n" + "=" * 70)
print("SUMMARY: Gini × ln(equip) across specifications")
print("=" * 70)
print(f"  {'Specification':<45} {'β':>8} {'SE(1w)':>8} {'p(1w)':>8} {'SE(2w)':>8} {'p(2w)':>8} {'Ratio':>7}")
print(f"  {'-'*92}")

summary_specs = [
    ('individual_upper_lags', 'Indiv, Upper GDP, With Lags (PRIMARY)'),
    ('individual_upper_nolags', 'Indiv, Upper GDP, No Lags'),
    ('individual_full_lags', 'Indiv, Full Sample, With Lags'),
    ('individual_full_nolags', 'Indiv, Full Sample, No Lags'),
    ('team_full_lags', 'Team, Full Sample, With Lags'),
    ('four_way_upper', 'Four-Way, Indiv, Upper GDP'),
    ('individual_upper_region', 'Indiv, Upper GDP, Region Controls'),
]

for key, label in summary_specs:
    res = results.get(key)
    if res is None:
        continue
    c = res['coefficients'].get('gini_x_cost')
    if c is None:
        continue
    print(f"  {label:<45} {c['beta']:>8.4f} {c['se_1way']:>8.4f} {c['p_1way']:>8.4f} "
          f"{c['se_2way']:>8.4f} {c['p_2way']:>8.4f} {c['se_ratio']:>7.3f}")

# ============================================================
# SAVE
# ============================================================
# Strip numpy types for JSON serialization
def clean_for_json(obj):
    if isinstance(obj, dict):
        return {k: clean_for_json(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [clean_for_json(v) for v in obj]
    elif isinstance(obj, (np.integer,)):
        return int(obj)
    elif isinstance(obj, (np.floating,)):
        return float(obj)
    elif isinstance(obj, np.ndarray):
        return obj.tolist()
    return obj

out_path = os.path.join(RESULTS_DIR, 'v106_twoway_clustering.json')
with open(out_path, 'w') as f:
    json.dump(clean_for_json(results), f, indent=2)
print(f"\nResults saved to {out_path}")
