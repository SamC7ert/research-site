#!/usr/bin/env python3
"""
v1.06 Game-Level Pipeline — TWO-LAG PRIMARY SPECIFICATION
===========================================================
Based on v1.00/v1.01 pipeline. Key change: the primary specification
now includes two lags (lag1 + lag2) instead of one. lag2 is computed
from the panel data at load time.

Changes from v0.99:
  1. GDP median split: time-invariant, based on mean GDP across all games for
     all 71 countries in the regression sample. >= median = upper half.
     Computed once at script start, passed to all functions.
  2. Country-clustered standard errors throughout (maintained from v0.99.4).
  3. Population elasticity (Section 8.5): ln(total_points) ~ ln(pop) + ln(GDP)
     + game FE on country-game aggregates with positive total points.
     No +1 trick.
  4. Gender decomposition (Section 7.7): uses pre-built points_men/points_women
     columns from v100 panel. Gender-specific lags computed in this script.
  5. Positive-points filter: documented at every application point.

Analyses:
  A. Aggregate ladder (country-game totals, no sport FE)
  B. Sport-type decomposition (Gini×equip by type and GDP half)
  C. Facility interactions (GDP×ln_fac_maxcomp, Gini×ln_fac)
  D. Cost gradient + crossover (individual sports, with delta method)
  E. Horse race + four-way (facility vs equipment channels)
  F. GGI ladder (aggregate with Gender Gap Index)
  G. Robustness: no-lag vs lag comparison, with-zeros, Soviet split, per-sport,
     region vs religion, Mundlak, EFW, GDP specification
  G7.7. Gender decomposition (men/women points as DV)
  H. Population elasticity (Section 8.5)
  I. Two-period comparison (load from secondary script)

Input:  ../data/v106_game_level_panel.json + ancillary data
Output: ../results/v106_game_level_results.json
"""

import json
import os
import sys
import numpy as np
from collections import defaultdict
from scipy import stats as spstats
from scipy.optimize import minimize as sp_minimize
from scipy.stats import norm as sp_norm
import warnings
warnings.filterwarnings('ignore')

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, '..', 'data')
RESULTS_DIR = os.path.join(SCRIPT_DIR, '..', 'results')
os.makedirs(RESULTS_DIR, exist_ok=True)

# ============================================================
# LOAD DATA
# ============================================================
print("=" * 70)
print("v1.06 GAME-LEVEL PIPELINE — PRIMARY SPECIFICATION")
print("  4 religion vars (other=ref), max-comp facility, lag control")
print("  GDP split: time-invariant, >= median, all 71 countries")
print("=" * 70)

with open(os.path.join(DATA_DIR, 'v106_game_level_panel.json')) as f:
    raw_rows = json.load(f)
print(f"Loaded: {len(raw_rows)} total rows")

reg_rows = [r for r in raw_rows if r.get('regression_eligible')]
print(f"Regression sample (2000-2024): {len(reg_rows)} rows")

# --- v1.03: Compute lag2_points from the full panel ---
# Build lookup: (noc, sport, game_year) -> points
_pts_lookup = {}
for r in raw_rows:
    _pts_lookup[(r['noc'], r['sport_name'], r['game_year'])] = r['olympic_6pt']

# Game years in order
_game_years = sorted(set(r['game_year'] for r in raw_rows))
_gi_to_year = {i: y for i, y in enumerate(_game_years)}
_year_to_gi = {y: i for i, y in enumerate(_game_years)}

lag2_count = 0
for r in raw_rows:
    gi = _year_to_gi[r['game_year']]
    if gi >= 2:
        prev2_year = _gi_to_year[gi - 2]
        r['lag2_olympic_6pt'] = _pts_lookup.get((r['noc'], r['sport_name'], prev2_year), 0.0)
        lag2_count += 1
    else:
        r['lag2_olympic_6pt'] = None

print(f"v1.03: Computed lag2_points for {lag2_count} rows")

# EFW and GGI are now included directly in the panel (game-year-specific)
# No separate loading needed — access via r.get('efw') and r.get('ggi')

RELIGION_COLS = ['pct_muslim', 'pct_hindu', 'pct_buddhist', 'pct_christian']

# ============================================================
# GDP SPLIT: TIME-INVARIANT, COMPUTED ONCE
# ============================================================
# Fix #1: Compute each country's mean GDP per capita across all games
# in the regression sample. Rank the 71 countries ONCE.
# >= median = upper half (includes the median country).
# This ranking is passed to all functions — never recomputed.

def compute_gdp_ranking(rows):
    """Compute time-invariant GDP ranking for all countries in the regression sample.

    If rows contain an 'upper_gdp_half' field, use it directly (single source of truth).
    Otherwise fall back to dynamic computation from GDP values.

    Returns:
        gdp_avg: dict noc -> mean GDP per capita across all games
        median_gdp: the median of those means
        upper_nocs: set of NOCs in the upper half (>= median)
        lower_nocs: set of NOCs in the lower half (< median)
    """
    # Check if panel already has the classification
    if rows and 'upper_gdp_half' in rows[0]:
        # Use pre-computed classification from panel
        upper_nocs = set()
        lower_nocs = set()
        gdp_by_noc = defaultdict(list)
        for r in rows:
            if r['gdp_pc_ppp'] is not None:
                gdp_by_noc[r['noc']].append(r['gdp_pc_ppp'])
            if r.get('upper_gdp_half'):
                upper_nocs.add(r['noc'])
            else:
                lower_nocs.add(r['noc'])
        gdp_avg = {}
        for noc, gdps in gdp_by_noc.items():
            unique_gdps = list(set(gdps))
            gdp_avg[noc] = np.mean(unique_gdps)
        median_gdp = np.median(list(gdp_avg.values()))
        return gdp_avg, median_gdp, upper_nocs, lower_nocs

    # Fallback: compute dynamically
    gdp_by_noc = defaultdict(list)
    for r in rows:
        if r['gdp_pc_ppp'] is not None:
            gdp_by_noc[r['noc']].append(r['gdp_pc_ppp'])

    # Mean GDP per capita across all games (use unique values per game to avoid
    # double-counting from multiple sports in the same country-game)
    gdp_avg = {}
    for noc, gdps in gdp_by_noc.items():
        unique_gdps = list(set(gdps))
        gdp_avg[noc] = np.mean(unique_gdps)

    median_gdp = np.median(list(gdp_avg.values()))

    upper_nocs = {noc for noc, g in gdp_avg.items() if g >= median_gdp}
    lower_nocs = {noc for noc, g in gdp_avg.items() if g < median_gdp}

    return gdp_avg, median_gdp, upper_nocs, lower_nocs


# Compute once, use everywhere
GDP_AVG, GDP_MEDIAN, UPPER_NOCS, LOWER_NOCS = compute_gdp_ranking(reg_rows)
print(f"\nGDP split (time-invariant, all {len(GDP_AVG)} countries):")
print(f"  Median GDP per capita: ${GDP_MEDIAN:,.0f}")
print(f"  Upper half (>= median): {len(UPPER_NOCS)} countries")
print(f"  Lower half (< median): {len(LOWER_NOCS)} countries")


# ============================================================
# OLS ENGINE (HC1 robust SE + optional clustering)
# ============================================================

def ols(y, X, var_names=None, cluster_ids=None):
    """OLS with HC1 or clustered standard errors."""
    y = np.array(y, dtype=float)
    X = np.array(X, dtype=float)
    n, k = X.shape

    if n <= k + 1:
        return None

    try:
        beta = np.linalg.lstsq(X, y, rcond=None)[0]
    except np.linalg.LinAlgError:
        return None

    resid = y - X @ beta
    sse = resid @ resid
    sst = np.sum((y - np.mean(y))**2)
    r2 = 1 - sse / sst if sst > 0 else 0
    dof = n - k

    try:
        XtX_inv = np.linalg.inv(X.T @ X)
    except np.linalg.LinAlgError:
        try:
            XtX_inv = np.linalg.pinv(X.T @ X)
        except:
            return None

    if cluster_ids is not None:
        # Clustered SE at country level
        cluster_ids = np.array(cluster_ids)
        unique_clusters = np.unique(cluster_ids)
        G = len(unique_clusters)
        meat = np.zeros((k, k))
        for cl in unique_clusters:
            idx = cluster_ids == cl
            Xi = X[idx]
            ei = resid[idx]
            score = Xi.T @ ei  # k x 1
            meat += np.outer(score, score)
        scale = (G / (G - 1)) * (n / dof)
        V = scale * XtX_inv @ meat @ XtX_inv
    else:
        # HC1 sandwich
        e2 = resid ** 2
        meat = X.T @ (X * e2[:, None])
        V = (n / dof) * XtX_inv @ meat @ XtX_inv

    diag_V = np.diag(V)
    se = np.sqrt(np.maximum(diag_V, 0))
    t_stats = np.where(se > 0, beta / se, 0)
    # For clustered SEs, use G-1 dof (Cameron, Gelbach & Miller 2008)
    # For HC1 (non-clustered), use n-k
    p_dof = G - 1 if cluster_ids is not None else dof
    p_vals = 2 * (1 - spstats.t.cdf(np.abs(t_stats), p_dof))

    result = {
        'n': n,
        'k': k,
        'r2': round(r2, 6),
        'coefficients': {},
    }

    names = var_names or [f'x{i}' for i in range(k)]
    for i, name in enumerate(names):
        result['coefficients'][name] = {
            'beta': round(float(beta[i]), 6),
            'se': round(float(se[i]), 6),
            't': round(float(t_stats[i]), 4),
            'p': round(float(p_vals[i]), 6),
        }

    if cluster_ids is not None:
        result['n_clusters'] = int(G)

    # Store variance-covariance for delta method
    result['_vcov'] = V
    result['_var_names'] = names

    return result


def coeff(res, name):
    """Extract coefficient dict from result."""
    if res is None:
        return {'beta': None, 'se': None, 'p': None}
    c = res.get('coefficients', {}).get(name, {})
    return {
        'beta': c.get('beta'),
        'se': c.get('se'),
        'p': c.get('p'),
    }

def fmt(res, name):
    """Format coefficient for printing."""
    c = coeff(res, name)
    if c['beta'] is None:
        return "N/A"
    return f"β={c['beta']:.4f} (SE={c['se']:.4f}, p={c['p']:.4f})"


# ============================================================
# DATA HELPERS
# ============================================================

def subset(rows, sport_type=None, gdp_half=None, drop_zeros=True):
    """Filter panel rows.

    GDP split uses the pre-computed time-invariant ranking (UPPER_NOCS / LOWER_NOCS).
    Positive-points filter: when drop_zeros=True, rows with points <= 0 are excluded.
    This is the standard filter for regression samples (Section 4 onwards).
    """
    out = rows
    if sport_type:
        out = [r for r in out if r['sport_type'] == sport_type]
    if drop_zeros:
        # POSITIVE-POINTS FILTER: exclude zero-scoring country-sport-game observations.
        # Applied here for all sport-cost gradient regressions. The GDP split is
        # independent of this filter (computed on all 71 countries).
        out = [r for r in out if r['olympic_6pt'] > 0]
    if gdp_half:
        # GDP SPLIT: uses pre-computed time-invariant ranking.
        # Upper = mean GDP >= median across all games. Lower = below median.
        if gdp_half == 'upper':
            out = [r for r in out if r['noc'] in UPPER_NOCS]
        elif gdp_half == 'lower':
            out = [r for r in out if r['noc'] in LOWER_NOCS]
    return out


def build_matrices(rows, include_lag=True, include_lag2=True, control='religion',
                   cost_var='cost_equip_eur_pr_year',
                   facility_var=None,
                   include_gini_x_cost=True,
                   include_gdp_x_fac=False,
                   include_gini_x_fac=False,
                   include_gdp_x_cost=False,
                   include_efw=False,
                   include_efw_x_cost=False,
                   include_ggi=False,
                   include_mundlak=False,
                   gdp_level=False,
                   sport_fe=True,
                   game_fe=True):
    """Build y, X, var_names, cluster_ids for game-level regression."""
    data = []
    cluster_ids = []

    for r in rows:
        equip = r.get(cost_var)
        gdp = r['gdp_pc_ppp']
        pop = r['population']
        gini = r['gini']
        if any(v is None for v in [equip, gdp, pop, gini]):
            continue
        if equip <= 0 or gdp <= 0 or pop <= 0:
            continue

        ln_equip = np.log(equip)
        ln_fac = None
        if facility_var:
            fac = r.get(facility_var)
            if fac is None or fac <= 0:
                continue
            ln_fac = np.log(fac)

        d = {
            'olympic_6pt': r['olympic_6pt'],
            'gini': gini,
            'gini_x_cost': gini * ln_equip,
            'sport_name': r['sport_name'],
            'game_year': r['game_year'],
            'noc': r['noc'],
        }

        if gdp_level:
            d['gdp_level_k'] = gdp / 1000.0
        else:
            d['ln_gdp'] = np.log(gdp)
        d['ln_pop'] = np.log(pop)
        d['soviet'] = 1.0 if r.get('soviet_legacy') else 0.0

        if control == 'religion':
            for rc in RELIGION_COLS:
                d[rc] = r.get(rc, 0) or 0
        elif control == 'region':
            d['region_id'] = r.get('region_id')

        if include_lag:
            lag = r.get('lag_olympic_6pt')
            if lag is None:
                continue
            d['ln_lag'] = np.log(1 + lag)

        if include_lag2:
            lag2 = r.get('lag2_olympic_6pt')
            if lag2 is None:
                continue
            d['ln_lag2'] = np.log(1 + lag2)

        if ln_fac is not None:
            if include_gdp_x_fac:
                d['gdp_x_fac'] = np.log(gdp) * ln_fac
            if include_gini_x_fac:
                d['gini_x_fac'] = gini * ln_fac
            if include_gdp_x_cost:
                d['gdp_x_cost'] = np.log(gdp) * ln_equip

        if include_efw:
            efw_val = r.get('efw')
            if efw_val is None:
                continue
            d['efw'] = efw_val
            if include_efw_x_cost:
                d['efw_x_cost'] = efw_val * ln_equip

        if include_ggi:
            ggi = r.get('ggi')
            if ggi is None:
                continue
            d['ggi'] = ggi

        data.append(d)
        cluster_ids.append(r['noc'])

    if not data or len(data) < 30:
        return None, None, None, None

    y = np.array([d['olympic_6pt'] for d in data])

    # Build var_names
    var_names = ['const']
    if gdp_level:
        var_names.append('gdp_level_k')
    else:
        var_names.append('ln_gdp')
    var_names += ['ln_pop', 'soviet', 'gini']

    if include_gini_x_cost:
        var_names.append('gini_x_cost')

    if control == 'religion':
        var_names += list(RELIGION_COLS)
    elif control == 'region':
        all_regions = sorted(set(d['region_id'] for d in data if d.get('region_id') is not None))
        ref_region = max(all_regions) if all_regions else 10
        region_dummies = [r for r in all_regions if r != ref_region]
        var_names += [f'region_{r}' for r in region_dummies]

    if include_lag:
        var_names.append('ln_lag')
    if include_lag2:
        var_names.append('ln_lag2')

    if include_gdp_x_fac:
        var_names.append('gdp_x_fac')
    if include_gini_x_fac:
        var_names.append('gini_x_fac')
    if include_gdp_x_cost:
        var_names.append('gdp_x_cost')

    if include_efw:
        var_names.append('efw')
    if include_efw_x_cost:
        var_names.append('efw_x_cost')

    if include_ggi:
        var_names.append('ggi')

    # Sport FE
    sport_dummies = []
    if sport_fe:
        all_sports = sorted(set(d['sport_name'] for d in data))
        sport_dummies = all_sports[1:]
        var_names += [f'sport_{s}' for s in sport_dummies]

    # Game FE
    game_dummies = []
    if game_fe:
        all_games = sorted(set(d['game_year'] for d in data))
        game_dummies = all_games[1:]
        var_names += [f'game_{g}' for g in game_dummies]

    # Mundlak means (country-level means of time-varying vars)
    mundlak_means = {}
    if include_mundlak:
        from collections import defaultdict as dd
        gdp_by_noc = dd(list)
        gini_by_noc = dd(list)
        pop_by_noc = dd(list)
        for d in data:
            noc = d['noc']
            gdp_by_noc[noc].append(d.get('ln_gdp', 0))
            gini_by_noc[noc].append(d['gini'])
            pop_by_noc[noc].append(d['ln_pop'])
        for noc in gdp_by_noc:
            mundlak_means[noc] = {
                'mean_ln_gdp': np.mean(gdp_by_noc[noc]),
                'mean_gini': np.mean(gini_by_noc[noc]),
                'mean_ln_pop': np.mean(pop_by_noc[noc]),
            }
        var_names += ['mean_ln_gdp', 'mean_gini', 'mean_ln_pop']

    # Build X
    X = []
    for d in data:
        row = [1.0]
        if gdp_level:
            row.append(d['gdp_level_k'])
        else:
            row.append(d['ln_gdp'])
        row += [d['ln_pop'], d['soviet'], d['gini']]

        if include_gini_x_cost:
            row.append(d['gini_x_cost'])

        if control == 'religion':
            for rc in RELIGION_COLS:
                row.append(d[rc])
        elif control == 'region':
            for r_id in region_dummies:
                row.append(1.0 if d.get('region_id') == r_id else 0.0)

        if include_lag:
            row.append(d['ln_lag'])
        if include_lag2:
            row.append(d['ln_lag2'])

        if include_gdp_x_fac:
            row.append(d.get('gdp_x_fac', 0))
        if include_gini_x_fac:
            row.append(d.get('gini_x_fac', 0))
        if include_gdp_x_cost:
            row.append(d.get('gdp_x_cost', 0))

        if include_efw:
            row.append(d['efw'])
        if include_efw_x_cost:
            row.append(d['efw_x_cost'])
        if include_ggi:
            row.append(d['ggi'])

        for s in sport_dummies:
            row.append(1.0 if d['sport_name'] == s else 0.0)
        for g in game_dummies:
            row.append(1.0 if d['game_year'] == g else 0.0)

        if include_mundlak:
            m = mundlak_means.get(d['noc'], {})
            row.append(m.get('mean_ln_gdp', 0))
            row.append(m.get('mean_gini', 0))
            row.append(m.get('mean_ln_pop', 0))

        X.append(row)

    return y, np.array(X), var_names, cluster_ids


def run_reg(rows, label='', control='religion', print_key='gini_x_cost', **kwargs):
    """Convenience: build matrices and run OLS, print result."""
    y, X, names, cl = build_matrices(rows, control=control, **kwargs)
    if y is None:
        print(f"  {label}: insufficient data")
        return None
    res = ols(y, X, names, cluster_ids=cl)
    if res:
        clusters = res.get('n_clusters', '?')
        print(f"  {label} (n={res['n']}, clusters={clusters}, R²={res['r2']:.4f}): {fmt(res, print_key)}")
    return res


# ============================================================
# A. AGGREGATE LADDER
# ============================================================

def section_A_aggregate_ladder(rows):
    """Aggregate model ladder on country-game totals."""
    print("\n" + "=" * 60)
    print("  A. AGGREGATE LADDER (country-game totals)")
    print("=" * 60)

    # Aggregate: sum points per country per game
    agg = defaultdict(lambda: defaultdict(float))
    meta = {}
    for r in rows:
        key = (r['noc'], r['game_year'])
        agg[key]['olympic_6pt'] += r['olympic_6pt']
        if key not in meta:
            meta[key] = r  # store country-level vars

    agg_rows = []
    for (noc, game), vals in agg.items():
        base = meta[(noc, game)]
        agg_rows.append({
            'olympic_6pt': vals['olympic_6pt'],
            'noc': noc,
            'game_year': game,
            'gdp_pc_ppp': base['gdp_pc_ppp'],
            'population': base['population'],
            'gini': base['gini'],
            'soviet_legacy': base['soviet_legacy'],
            'pct_muslim': base.get('pct_muslim', 0),
            'pct_hindu': base.get('pct_hindu', 0),
            'pct_buddhist': base.get('pct_buddhist', 0),
            'pct_christian': base.get('pct_christian', 0),
            'region_id': base.get('region_id'),
            'lag_olympic_6pt': None,  # no lag at aggregate level
            'ggi': base.get('ggi'),
            'period': base.get('period'),
            'cost_equip_eur_pr_year': 1000,  # placeholder, not used in aggregate
        })

    results = {}
    for control in ['religion', 'region']:
        ctrl_results = {}

        # M1: GDP + Pop + game FE
        # M2: + Gini
        # M3: + Soviet
        # M4: + Galton controls

        for model_name, inc_gini, inc_soviet, inc_galton in [
            ('M1', False, False, False),
            ('M2', True, False, False),
            ('M3', True, True, False),
            ('M4', True, True, True),
        ]:
            data = []
            cluster_ids = []
            for r in agg_rows:
                gdp = r['gdp_pc_ppp']
                pop = r['population']
                if gdp is None or pop is None or gdp <= 0 or pop <= 0:
                    continue
                gini = r['gini']
                if inc_gini and gini is None:
                    continue

                d = {'olympic_6pt': r['olympic_6pt'], 'ln_gdp': np.log(gdp), 'ln_pop': np.log(pop),
                     'game_year': r['game_year'], 'noc': r['noc']}
                if inc_gini:
                    d['gini'] = gini
                if inc_soviet:
                    d['soviet'] = 1.0 if r['soviet_legacy'] else 0.0
                if inc_galton and control == 'religion':
                    for rc in RELIGION_COLS:
                        d[rc] = r.get(rc, 0) or 0
                if inc_galton and control == 'region':
                    d['region_id'] = r.get('region_id')

                data.append(d)
                cluster_ids.append(r['noc'])

            if len(data) < 30:
                continue

            y = np.array([d['olympic_6pt'] for d in data])
            var_names = ['const', 'ln_gdp', 'ln_pop']
            if inc_gini:
                var_names.append('gini')
            if inc_soviet:
                var_names.append('soviet')
            if inc_galton and control == 'religion':
                var_names += list(RELIGION_COLS)
            if inc_galton and control == 'region':
                all_regions = sorted(set(d['region_id'] for d in data if d.get('region_id') is not None))
                ref_region = max(all_regions)
                region_dummies = [r for r in all_regions if r != ref_region]
                var_names += [f'region_{r}' for r in region_dummies]

            # Game FE
            all_games = sorted(set(d['game_year'] for d in data))
            game_dummies = all_games[1:]
            var_names += [f'game_{g}' for g in game_dummies]

            Xm = []
            for d in data:
                row = [1.0, d['ln_gdp'], d['ln_pop']]
                if inc_gini:
                    row.append(d['gini'])
                if inc_soviet:
                    row.append(d['soviet'])
                if inc_galton and control == 'religion':
                    for rc in RELIGION_COLS:
                        row.append(d.get(rc, 0))
                if inc_galton and control == 'region':
                    for r_id in region_dummies:
                        row.append(1.0 if d.get('region_id') == r_id else 0.0)
                for g in game_dummies:
                    row.append(1.0 if d['game_year'] == g else 0.0)
                Xm.append(row)

            res = ols(y, np.array(Xm), var_names, cluster_ids=cluster_ids)
            if res:
                gini_c = coeff(res, 'gini')
                soviet_c = coeff(res, 'soviet')
                ctrl_results[model_name] = {
                    'r2': res['r2'], 'n': res['n'],
                    'gini_b': gini_c['beta'], 'gini_p': gini_c['p'],
                    'soviet_b': soviet_c['beta'], 'soviet_p': soviet_c['p'],
                }
                print(f"  {control}/{model_name} (n={res['n']}, R²={res['r2']:.4f}): "
                      f"Gini {fmt(res, 'gini')}")

        results[control] = ctrl_results

    # A2: Regional heterogeneity F-test (Section 3.2)
    # Uses region_id from the panel data directly (1-10)
    print("\n  --- A2: Regional heterogeneity (Gini slopes by region) ---")

    # Filter to valid aggregate rows with region_id
    valid_agg = [r for r in agg_rows if r['gdp_pc_ppp'] and r['population'] and
                 r['gdp_pc_ppp'] > 0 and r['population'] > 0 and
                 r['gini'] is not None and r.get('region_id') is not None]

    if valid_agg:
        region_list = sorted(set(r['region_id'] for r in valid_agg))
        print(f"  Regions: {len(region_list)}, observations: {len(valid_agg)}")

        # Per-region Gini slopes
        region_slopes = {}
        n_positive = 0
        n_negative = 0
        for reg_id in region_list:
            r_rows = [r for r in valid_agg if r['region_id'] == reg_id]
            if len(r_rows) < 10:
                continue
            yv = np.array([r['olympic_6pt'] for r in r_rows])
            vn = ['const', 'ln_gdp', 'ln_pop', 'gini']
            gms = sorted(set(r['game_year'] for r in r_rows))
            gm_d = gms[1:]
            vn += [f'game_{g}' for g in gm_d]
            Xv = []
            for r in r_rows:
                row = [1.0, np.log(r['gdp_pc_ppp']), np.log(r['population']), r['gini']]
                for g in gm_d:
                    row.append(1.0 if r['game_year'] == g else 0.0)
                Xv.append(row)
            if len(Xv) < 10:
                continue
            Xv = np.array(Xv)
            yv_c = yv[:len(Xv)]
            res = ols(yv_c, Xv, vn)
            if res:
                gc = coeff(res, 'gini')
                region_slopes[str(reg_id)] = {'beta': gc['beta'], 'p': gc['p'], 'n': res['n']}
                if gc['beta'] > 0:
                    n_positive += 1
                else:
                    n_negative += 1

        # F-test: restricted (common Gini slope) vs unrestricted (region-specific slopes)
        yv = np.array([r['olympic_6pt'] for r in valid_agg])
        gms = sorted(set(r['game_year'] for r in valid_agg))
        gm_d = gms[1:]

        # Restricted: GDP, Pop, Gini (common), game FE
        vn_r = ['const', 'ln_gdp', 'ln_pop', 'gini'] + [f'game_{g}' for g in gm_d]
        Xr = []
        for r in valid_agg:
            row = [1.0, np.log(r['gdp_pc_ppp']), np.log(r['population']), r['gini']]
            for g in gm_d:
                row.append(1.0 if r['game_year'] == g else 0.0)
            Xr.append(row)
        Xr = np.array(Xr)
        res_r = ols(yv, Xr, vn_r)

        # Unrestricted: GDP, Pop, region-specific Gini slopes, game FE
        vn_u = ['const', 'ln_gdp', 'ln_pop']
        for reg_id in region_list:
            vn_u.append(f'gini_r{reg_id}')
        vn_u += [f'game_{g}' for g in gm_d]
        Xu = []
        for r in valid_agg:
            row = [1.0, np.log(r['gdp_pc_ppp']), np.log(r['population'])]
            for reg_id in region_list:
                row.append(r['gini'] if r['region_id'] == reg_id else 0.0)
            for g in gm_d:
                row.append(1.0 if r['game_year'] == g else 0.0)
            Xu.append(row)
        Xu = np.array(Xu)
        res_u = ols(yv, Xu, vn_u)

        # Cluster-robust Wald test for regional heterogeneity
        # Run unrestricted model WITH country-clustered SEs
        cluster_ids_u = [r['noc'] for r in valid_agg]
        res_u_cl = ols(yv, Xu, vn_u, cluster_ids=cluster_ids_u)

        if res_u_cl and res_u_cl.get('_vcov') is not None:
            # Wald test: are all region-specific Gini slopes equal?
            # q = n_regions - 1 restrictions (slope_2 = slope_1, slope_3 = slope_1, ...)
            gini_cols = [f'gini_r{reg_id}' for reg_id in region_list]
            q = len(gini_cols) - 1
            idx0 = vn_u.index(gini_cols[0])
            R = np.zeros((q, len(vn_u)))
            for i in range(q):
                idx_i = vn_u.index(gini_cols[i + 1])
                R[i, idx0] = 1.0
                R[i, idx_i] = -1.0
            beta_vec = np.array([res_u_cl['coefficients'][v]['beta'] for v in vn_u])
            Rb = R @ beta_vec
            V = res_u_cl['_vcov']
            RVRt = R @ V @ R.T
            try:
                RVRt_inv = np.linalg.inv(RVRt)
            except np.linalg.LinAlgError:
                RVRt_inv = np.linalg.pinv(RVRt)
            f_stat = float(Rb @ RVRt_inv @ Rb) / q
            G = res_u_cl['n_clusters']
            f_dfd = G - 1
            f_p = 1 - spstats.f.cdf(f_stat, q, f_dfd)

            results['A2_regional_heterogeneity'] = {
                'n_regions': len(region_list),
                'n_positive_slopes': n_positive,
                'n_negative_slopes': n_negative,
                'f_stat': round(f_stat, 3),
                'f_dfn': q,
                'f_dfd': f_dfd,
                'f_p': round(f_p, 6),
                'f_type': 'cluster-robust Wald',
                'region_slopes': region_slopes,
            }
            print(f"  Positive slopes: {n_positive}, Negative slopes: {n_negative}")
            print(f"  Cluster-robust Wald: F({q},{f_dfd}) = {f_stat:.3f}, p = {f_p:.4f}")

    return results


# ============================================================
# B. SPORT-TYPE DECOMPOSITION
# ============================================================

def section_B_sport_type(rows):
    """Gini × equipment cost by sport type and GDP half."""
    print("\n" + "=" * 60)
    print("  B. SPORT-TYPE DECOMPOSITION")
    print("=" * 60)

    results = {}
    for control in ['religion', 'region']:
        ctrl = {}
        for stype in [None, 'individual', 'team', 'duel']:
            for gdp_half in [None, 'upper', 'lower']:
                label = f"{stype or 'all'}_{gdp_half or 'full'}"
                # POSITIVE-POINTS FILTER: applied via subset(drop_zeros=True)
                sub = subset(rows, sport_type=stype, gdp_half=gdp_half)
                res = run_reg(sub, label=f"{control}/{label}", control=control,
                              print_key='gini_x_cost')
                if res:
                    ctrl[label] = {
                        'n': res['n'], 'r2': res['r2'],
                        'n_clusters': res.get('n_clusters'),
                        'gini_x_cost': coeff(res, 'gini_x_cost'),
                        'gini': coeff(res, 'gini'),
                        'ln_lag': coeff(res, 'ln_lag'),
                    }
        results[control] = ctrl

    return results


# ============================================================
# C. FACILITY INTERACTIONS
# ============================================================

def section_C_facility(rows):
    """GDP × ln(facility) and Gini × ln(facility) interactions."""
    print("\n" + "=" * 60)
    print("  C. FACILITY INTERACTIONS (max-comp)")
    print("=" * 60)

    results = {}
    fac_var = 'cost_national_facility_eur'

    for control in ['religion']:  # primary only
        ctrl = {}
        for gdp_half in [None, 'upper', 'lower']:
            label = f"ind_{gdp_half or 'full'}"
            # POSITIVE-POINTS FILTER: applied via subset(drop_zeros=True)
            sub = subset(rows, sport_type='individual', gdp_half=gdp_half)

            # GDP × facility
            res_gdp = run_reg(sub, label=f"GDP×fac {label}", control=control,
                              facility_var=fac_var, include_gdp_x_fac=True,
                              print_key='gdp_x_fac')

            # Gini × facility
            res_gini = run_reg(sub, label=f"Gini×fac {label}", control=control,
                               facility_var=fac_var, include_gini_x_fac=True,
                               print_key='gini_x_fac')

            ctrl[label] = {
                'gdp_x_fac': coeff(res_gdp, 'gdp_x_fac') if res_gdp else None,
                'gini_x_fac': coeff(res_gini, 'gini_x_fac') if res_gini else None,
                'n': res_gdp['n'] if res_gdp else None,
            }

        results[control] = ctrl

    return results


# ============================================================
# D. COST GRADIENT + CROSSOVER
# ============================================================

def section_D_cost_gradient(rows):
    """Cost gradient in individual sports with crossover analysis."""
    print("\n" + "=" * 60)
    print("  D. COST GRADIENT + CROSSOVER")
    print("=" * 60)

    results = {'gradient': {}, 'crossover': {}}

    for gdp_half in [None, 'upper']:
        label = f"ind_{gdp_half or 'full'}"
        # POSITIVE-POINTS FILTER: applied via subset(drop_zeros=True)
        sub = subset(rows, sport_type='individual', gdp_half=gdp_half)

        # Primary: religion control with lag
        y, X, names, cl = build_matrices(sub, control='religion')
        if y is None:
            continue
        res = ols(y, X, names, cluster_ids=cl)
        if res is None:
            continue

        gc = coeff(res, 'gini_x_cost')
        gm = coeff(res, 'gini')
        lag_c = coeff(res, 'ln_lag')
        print(f"\n  {label} (n={res['n']}, clusters={res.get('n_clusters', '?')}, R²={res['r2']:.4f}):")
        print(f"    Gini×ln(equip) = {gc['beta']:.4f} (SE={gc['se']:.4f}, p={gc['p']:.4f})")
        print(f"    Gini (main)    = {gm['beta']:.4f} (p={gm['p']:.4f})")
        print(f"    ln(1+lag)      = {lag_c['beta']:.4f} (p={lag_c['p']:.4f})")

        results['gradient'][label] = {
            'n': res['n'], 'r2': res['r2'],
            'n_clusters': res.get('n_clusters'),
            'gini_x_cost': gc,
            'gini': gm,
            'ln_lag': lag_c,
            'ln_lag2': coeff(res, 'ln_lag2'),
            'ln_gdp': coeff(res, 'ln_gdp'),
            'ln_pop': coeff(res, 'ln_pop'),
            'soviet': coeff(res, 'soviet'),
            'pct_christian': coeff(res, 'pct_christian'),
            'pct_muslim': coeff(res, 'pct_muslim'),
            'pct_hindu': coeff(res, 'pct_hindu'),
            'pct_buddhist': coeff(res, 'pct_buddhist'),
        }

        # No-lag comparison
        y0, X0, n0, cl0 = build_matrices(sub, control='religion', include_lag=False, include_lag2=False)
        res0 = ols(y0, X0, n0, cluster_ids=cl0) if y0 is not None else None
        if res0:
            gc0 = coeff(res0, 'gini_x_cost')
            attenuation = (1 - gc['beta'] / gc0['beta']) * 100 if gc0['beta'] != 0 else 0
            print(f"    No-lag: Gini×ln(equip) = {gc0['beta']:.4f} (p={gc0['p']:.4f})")
            print(f"    Attenuation from lag: {attenuation:.1f}%")
            results['gradient'][f'{label}_no_lag'] = {
                'n': res0['n'], 'r2': res0['r2'],
                'gini_x_cost': gc0,
                'gini': coeff(res0, 'gini'),
                'ln_gdp': coeff(res0, 'ln_gdp'),
                'ln_pop': coeff(res0, 'ln_pop'),
                'soviet': coeff(res0, 'soviet'),
                'pct_christian': coeff(res0, 'pct_christian'),
                'pct_muslim': coeff(res0, 'pct_muslim'),
                'pct_hindu': coeff(res0, 'pct_hindu'),
                'pct_buddhist': coeff(res0, 'pct_buddhist'),
                'attenuation_pct': round(attenuation, 1),
            }

        # Region robustness
        yr, Xr, nr, clr = build_matrices(sub, control='region')
        resr = ols(yr, Xr, nr, cluster_ids=clr) if yr is not None else None
        if resr:
            results['gradient'][f'{label}_region'] = {
                'n': resr['n'], 'r2': resr['r2'],
                'gini_x_cost': coeff(resr, 'gini_x_cost'),
            }

        # CROSSOVER (delta method)
        if gc['beta'] is not None and gm['beta'] is not None and gc['beta'] != 0:
            crossover_ln = -gm['beta'] / gc['beta']
            crossover_eur = np.exp(crossover_ln)

            # Delta method for CI
            vcov = res.get('_vcov')
            vnames = res.get('_var_names', [])
            if vcov is not None:
                try:
                    idx_gini = vnames.index('gini')
                    idx_gxc = vnames.index('gini_x_cost')
                    b1 = gm['beta']
                    b2 = gc['beta']
                    v11 = vcov[idx_gini, idx_gini]
                    v22 = vcov[idx_gxc, idx_gxc]
                    v12 = vcov[idx_gini, idx_gxc]
                    # Var of ratio -b1/b2 via delta method
                    grad = np.array([-1.0/b2, b1/b2**2])
                    var_ratio = grad @ np.array([[v11, v12], [v12, v22]]) @ grad
                    se_ln_cross = np.sqrt(max(var_ratio, 0))
                    ci_lo = np.exp(crossover_ln - 1.96 * se_ln_cross)
                    ci_hi = np.exp(crossover_ln + 1.96 * se_ln_cross)
                except (ValueError, IndexError):
                    ci_lo, ci_hi = None, None
            else:
                ci_lo, ci_hi = None, None

            # Effect at specific cost points
            test_costs = [300, 500, 650, 1000, 1400, 2000, 4000, 10000, 50000]
            effects = []
            for c in test_costs:
                ln_c = np.log(c)
                eff = gm['beta'] + gc['beta'] * ln_c
                if vcov is not None:
                    try:
                        idx_gini = vnames.index('gini')
                        idx_gxc = vnames.index('gini_x_cost')
                        var_eff = vcov[idx_gini, idx_gini] + ln_c**2 * vcov[idx_gxc, idx_gxc] + 2 * ln_c * vcov[idx_gini, idx_gxc]
                        se_eff = np.sqrt(max(var_eff, 0))
                        t_eff = eff / se_eff if se_eff > 0 else 0
                        p_eff = 2 * (1 - spstats.t.cdf(abs(t_eff), res['n'] - res['k']))
                    except:
                        se_eff, p_eff = None, None
                else:
                    se_eff, p_eff = None, None
                effects.append({
                    'cost_eur': c, 'effect': round(eff, 4),
                    'se': round(se_eff, 4) if se_eff else None,
                    'p': round(p_eff, 4) if p_eff else None,
                })

            results['crossover'][label] = {
                'crossover_eur': round(crossover_eur, 0),
                'crossover_ln': round(crossover_ln, 4),
                'ci_lo': round(ci_lo, 0) if ci_lo else None,
                'ci_hi': round(ci_hi, 0) if ci_hi else None,
                'effects_at_cost': effects,
            }
            print(f"    Crossover: €{crossover_eur:,.0f} (95% CI: €{ci_lo:,.0f} – €{ci_hi:,.0f})" if ci_lo else f"    Crossover: €{crossover_eur:,.0f}")

    return results


# ============================================================
# E. HORSE RACE + FOUR-WAY
# ============================================================

def section_E_horse_race(rows):
    """Horse race between equipment and facility channels."""
    print("\n" + "=" * 60)
    print("  E. HORSE RACE + FOUR-WAY")
    print("=" * 60)

    fac_var = 'cost_national_facility_eur'
    results = {'horse_race': {}, 'four_way': {}}

    for gdp_half in [None, 'upper']:
        label = f"ind_{gdp_half or 'full'}"
        # POSITIVE-POINTS FILTER: applied via subset(drop_zeros=True)
        sub = subset(rows, sport_type='individual', gdp_half=gdp_half)

        # Gini × equip alone
        res_alone = run_reg(sub, label=f"equip alone {label}",
                            print_key='gini_x_cost')

        # Gini × equip + GDP × facility (horse race)
        res_joint = run_reg(sub, label=f"joint {label}",
                            facility_var=fac_var,
                            include_gdp_x_fac=True,
                            print_key='gini_x_cost')

        if res_alone and res_joint:
            b_alone = coeff(res_alone, 'gini_x_cost')['beta']
            b_joint = coeff(res_joint, 'gini_x_cost')['beta']
            attenuation = (1 - b_joint / b_alone) * 100 if b_alone != 0 else 0

            results['horse_race'][label] = {
                'gini_x_cost_alone': coeff(res_alone, 'gini_x_cost'),
                'gini_x_cost_joint': coeff(res_joint, 'gini_x_cost'),
                'gdp_x_fac': coeff(res_joint, 'gdp_x_fac'),
                'attenuation_pct': round(attenuation, 1),
                'n': res_joint['n'],
            }
            print(f"    Attenuation: {attenuation:.1f}%")

        # Four-way: all interactions
        res_4w = run_reg(sub, label=f"four-way {label}",
                         facility_var=fac_var,
                         include_gdp_x_fac=True,
                         include_gini_x_fac=True,
                         include_gdp_x_cost=True,
                         print_key='gini_x_cost')

        if res_4w:
            results['four_way'][label] = {
                'gini_x_cost': coeff(res_4w, 'gini_x_cost'),
                'gdp_x_fac': coeff(res_4w, 'gdp_x_fac'),
                'gini_x_fac': coeff(res_4w, 'gini_x_fac'),
                'gdp_x_cost': coeff(res_4w, 'gdp_x_cost'),
                'n': res_4w['n'], 'r2': res_4w['r2'],
            }

    return results


# ============================================================
# F. GGI LADDER
# ============================================================

def section_F_ggi(rows):
    """Gender Gap Index model ladder on country-game aggregates."""
    print("\n" + "=" * 60)
    print("  F. GGI LADDER")
    print("=" * 60)

    # Aggregate
    agg = defaultdict(lambda: defaultdict(float))
    meta = {}
    for r in rows:
        key = (r['noc'], r['game_year'])
        agg[key]['olympic_6pt'] += r['olympic_6pt']
        if key not in meta:
            meta[key] = r

    agg_rows = []
    for (noc, game), vals in agg.items():
        base = meta[(noc, game)]
        if base.get('ggi') is None:
            continue
        agg_rows.append({
            'olympic_6pt': vals['olympic_6pt'], 'noc': noc, 'game_year': game,
            'gdp_pc_ppp': base['gdp_pc_ppp'], 'population': base['population'],
            'gini': base['gini'], 'ggi': base['ggi'],
            'soviet_legacy': base['soviet_legacy'],
            'pct_muslim': base.get('pct_muslim', 0),
            'pct_hindu': base.get('pct_hindu', 0),
            'pct_buddhist': base.get('pct_buddhist', 0),
            'pct_christian': base.get('pct_christian', 0),
            'cost_equip_eur_pr_year': 1000,
            'lag_olympic_6pt': None,
        })

    results = {}
    for model_name, inc_soviet, inc_galton, inc_gini in [
        ('GGI_only', False, False, False),
        ('GGI+Soviet', True, False, False),
        ('GGI+Galton', True, True, False),
        ('GGI+Gini+Galton', True, True, True),
    ]:
        data = []
        cluster_ids = []
        for r in agg_rows:
            gdp = r['gdp_pc_ppp']
            pop = r['population']
            if gdp is None or pop is None or gdp <= 0 or pop <= 0:
                continue
            if inc_gini and r['gini'] is None:
                continue
            d = {'olympic_6pt': r['olympic_6pt'], 'ln_gdp': np.log(gdp), 'ln_pop': np.log(pop),
                 'ggi': r['ggi'], 'game_year': r['game_year']}
            if inc_soviet:
                d['soviet'] = 1.0 if r['soviet_legacy'] else 0.0
            if inc_galton:
                for rc in RELIGION_COLS:
                    d[rc] = r.get(rc, 0) or 0
            if inc_gini:
                d['gini'] = r['gini']
            data.append(d)
            cluster_ids.append(r['noc'])

        if len(data) < 30:
            continue

        y = np.array([d['olympic_6pt'] for d in data])
        var_names = ['const', 'ln_gdp', 'ln_pop', 'ggi']
        if inc_soviet:
            var_names.append('soviet')
        if inc_galton:
            var_names += list(RELIGION_COLS)
        if inc_gini:
            var_names.append('gini')

        all_games = sorted(set(d['game_year'] for d in data))
        game_dummies = all_games[1:]
        var_names += [f'game_{g}' for g in game_dummies]

        Xm = []
        for d in data:
            row = [1.0, d['ln_gdp'], d['ln_pop'], d['ggi']]
            if inc_soviet:
                row.append(d['soviet'])
            if inc_galton:
                for rc in RELIGION_COLS:
                    row.append(d.get(rc, 0))
            if inc_gini:
                row.append(d['gini'])
            for g in game_dummies:
                row.append(1.0 if d['game_year'] == g else 0.0)
            Xm.append(row)

        res = ols(y, np.array(Xm), var_names, cluster_ids=cluster_ids)
        if res:
            results[model_name] = {
                'n': res['n'], 'r2': res['r2'],
                'ggi': coeff(res, 'ggi'),
                'gini': coeff(res, 'gini'),
            }
            print(f"  {model_name} (n={res['n']}, R²={res['r2']:.4f}): "
                  f"GGI {fmt(res, 'ggi')}, Gini {fmt(res, 'gini')}")

    return results


# ============================================================
# G. ROBUSTNESS
# ============================================================

def section_G_robustness(rows):
    """Robustness checks."""
    print("\n" + "=" * 60)
    print("  G. ROBUSTNESS")
    print("=" * 60)

    results = {}

    # G1: No-lag vs one-lag vs two-lag comparison
    print("\n  --- G1: Lag comparison by sport type (no-lag / one-lag / two-lag) ---")
    lag_comparison = {}
    for stype in [None, 'individual', 'team', 'duel']:
        for gdp_half in [None, 'upper']:
            label = f"{stype or 'all'}_{gdp_half or 'full'}"
            # POSITIVE-POINTS FILTER: applied via subset(drop_zeros=True)
            sub = subset(rows, sport_type=stype, gdp_half=gdp_half)

            res_twolag = run_reg(sub, label=f"twolag {label}", print_key='gini_x_cost')
            res_onelag = run_reg(sub, label=f"onelag {label}",
                                 include_lag=True, include_lag2=False, print_key='gini_x_cost')
            res_nolag = run_reg(sub, label=f"nolag {label}",
                                include_lag=False, include_lag2=False, print_key='gini_x_cost')

            if res_twolag and res_onelag and res_nolag:
                b_twolag = coeff(res_twolag, 'gini_x_cost')['beta']
                b_onelag = coeff(res_onelag, 'gini_x_cost')['beta']
                b_nolag = coeff(res_nolag, 'gini_x_cost')['beta']
                att_twolag = (1 - b_twolag / b_nolag) * 100 if b_nolag != 0 else 0
                att_onelag = (1 - b_onelag / b_nolag) * 100 if b_nolag != 0 else 0
                lag_comparison[label] = {
                    'with_lag': coeff(res_twolag, 'gini_x_cost'),
                    'one_lag': coeff(res_onelag, 'gini_x_cost'),
                    'no_lag': coeff(res_nolag, 'gini_x_cost'),
                    'lag_coeff': coeff(res_twolag, 'ln_lag'),
                    'lag2_coeff': coeff(res_twolag, 'ln_lag2'),
                    'attenuation_pct': round(att_twolag, 1),
                    'attenuation_onelag_pct': round(att_onelag, 1),
                    'r2_with_lag': res_twolag['r2'], 'r2_no_lag': res_nolag['r2'],
                    'n_lag': res_twolag['n'], 'n_nolag': res_nolag['n'],
                }
    results['lag_comparison'] = lag_comparison

    # G1b: Participation rate by cost bracket and GDP half (Section 4.2)
    print("\n  --- G1b: Participation rate by cost bracket and GDP half ---")
    brackets = [(0, 500), (500, 1000), (1000, 1500), (1500, 2500), (2500, 5000)]
    participation = {}
    for gdp_half, noc_set in [('upper', UPPER_NOCS), ('lower', LOWER_NOCS)]:
        sub = [r for r in rows if r['noc'] in noc_set and r.get('sport_type') == 'individual']
        bracket_data = {}
        for lo, hi in brackets:
            total = sum(1 for r in sub if lo <= r.get('cost_equip_eur_pr_year', 0) < hi)
            positive = sum(1 for r in sub if lo <= r.get('cost_equip_eur_pr_year', 0) < hi and r.get('olympic_6pt', 0) > 0)
            rate = positive / total * 100 if total > 0 else 0
            bracket_data[f"{lo}-{hi}"] = {'total': total, 'positive': positive, 'rate': round(rate, 1)}
            print(f"    {gdp_half} {lo}-{hi}: {positive}/{total} = {rate:.1f}%")
        participation[gdp_half] = bracket_data
    results['participation_by_cost_bracket'] = participation

    # G2: With zeros
    print("\n  --- G2: With zeros ---")
    with_zeros = {}
    for gdp_half in [None, 'upper']:
        label = f"ind_{gdp_half or 'full'}"
        # NO positive-points filter: drop_zeros=False includes zero-scoring observations
        sub = subset(rows, sport_type='individual', gdp_half=gdp_half, drop_zeros=False)
        res = run_reg(sub, label=f"with_zeros {label}", print_key='gini_x_cost')
        if res:
            with_zeros[label] = {
                'n': res['n'], 'r2': res['r2'],
                'gini_x_cost': coeff(res, 'gini_x_cost'),
            }
    results['with_zeros'] = with_zeros

    # G2b: Tobit estimation (left-censored at 0, including zeros)
    print("\n  --- G2b: Tobit estimation ---")

    def tobit_loglik(params, y, X):
        beta = params[:-1]
        log_sigma = params[-1]
        sigma = np.exp(log_sigma)
        xb = X @ beta
        obs = y > 0
        cens = ~obs
        ll = 0.0
        if obs.sum() > 0:
            z = (y[obs] - xb[obs]) / sigma
            ll += np.sum(-0.5 * np.log(2 * np.pi) - log_sigma - 0.5 * z**2)
        if cens.sum() > 0:
            ll += np.sum(np.log(np.maximum(sp_norm.cdf(-xb[cens] / sigma), 1e-20)))
        return -ll

    def tobit_gradient(params, y, X):
        beta = params[:-1]
        log_sigma = params[-1]
        sigma = np.exp(log_sigma)
        xb = X @ beta
        obs = y > 0
        cens = ~obs
        grad_beta = np.zeros_like(beta)
        grad_log_sigma = 0.0
        if obs.sum() > 0:
            z = (y[obs] - xb[obs]) / sigma
            grad_beta += (X[obs].T @ z) / sigma
            grad_log_sigma += np.sum(z**2 - 1)
        if cens.sum() > 0:
            phi_over_Phi = sp_norm.pdf(-xb[cens] / sigma) / np.maximum(sp_norm.cdf(-xb[cens] / sigma), 1e-20)
            grad_beta -= (X[cens].T @ phi_over_Phi) / sigma
            grad_log_sigma += np.sum(phi_over_Phi * xb[cens] / sigma)
        return -np.append(grad_beta, grad_log_sigma)

    def run_tobit(y, X, var_names, cluster_ids=None):
        n, k = X.shape
        n_obs = int((y > 0).sum())
        n_cens = int((y == 0).sum())
        obs = y > 0
        if obs.sum() < k + 1:
            return None
        try:
            beta_ols = np.linalg.lstsq(X[obs], y[obs], rcond=None)[0]
        except np.linalg.LinAlgError:
            return None
        resid = y[obs] - X[obs] @ beta_ols
        sigma_ols = max(np.std(resid), 0.1)
        params_init = np.append(beta_ols, np.log(sigma_ols))
        result = sp_minimize(tobit_loglik, params_init, args=(y, X),
                             jac=tobit_gradient, method='L-BFGS-B',
                             options={'maxiter': 5000, 'ftol': 1e-10, 'gtol': 1e-6})
        if not result.success:
            result2 = sp_minimize(tobit_loglik, params_init, args=(y, X),
                                  method='L-BFGS-B', options={'maxiter': 5000, 'ftol': 1e-10})
            if result2.fun < result.fun:
                result = result2
            if not result.success:
                print(f"    Tobit did not converge: {result.message}")
                return None
        beta = result.x[:-1]
        sigma = np.exp(result.x[-1])
        # ML standard errors via numerical Hessian of gradient
        from scipy.optimize import approx_fprime
        n_p = len(result.x)
        hess = np.zeros((n_p, n_p))
        for i_h in range(n_p):
            def f_i(p, _i=i_h):
                return tobit_gradient(p, y, X)[_i]
            hess[i_h] = approx_fprime(result.x, f_i, 1e-5)
        try:
            H_inv = np.linalg.inv(hess)
            se_ml = np.sqrt(np.maximum(np.diag(H_inv)[:k], 0))
        except np.linalg.LinAlgError:
            se_ml = np.full(k, np.nan)
            H_inv = None
        # Cluster-robust SEs (sandwich: H_inv @ meat @ H_inv)
        se_cl = se_ml.copy()
        if cluster_ids is not None and H_inv is not None:
            try:
                params_opt = result.x
                beta_opt = params_opt[:-1]
                log_sigma_opt = params_opt[-1]
                sigma_opt = np.exp(log_sigma_opt)
                xb = X @ beta_opt
                # Per-observation score contributions
                scores_all = np.zeros((n, n_p))
                for i_obs in range(n):
                    if y[i_obs] > 0:
                        z_i = (y[i_obs] - xb[i_obs]) / sigma_opt
                        scores_all[i_obs, :k] = (z_i / sigma_opt) * X[i_obs]
                        scores_all[i_obs, k] = z_i**2 - 1
                    else:
                        ratio = sp_norm.pdf(-xb[i_obs] / sigma_opt) / max(sp_norm.cdf(-xb[i_obs] / sigma_opt), 1e-20)
                        scores_all[i_obs, :k] = -(ratio / sigma_opt) * X[i_obs]
                        scores_all[i_obs, k] = ratio * xb[i_obs] / sigma_opt
                # Cluster the scores
                cl_arr = np.array(cluster_ids)
                unique_clusters = np.unique(cl_arr)
                G = len(unique_clusters)
                meat = np.zeros((n_p, n_p))
                for c in unique_clusters:
                    mask = cl_arr == c
                    s_c = scores_all[mask].sum(axis=0)
                    meat += np.outer(s_c, s_c)
                meat *= G / (G - 1)  # small-sample correction
                sandwich = H_inv @ meat @ H_inv
                se_cl = np.sqrt(np.maximum(np.diag(sandwich)[:k], 0))
                print(f"    Cluster-robust SEs computed (G={G})")
            except Exception as e:
                print(f"    Cluster-robust SE failed ({e}), using ML SEs")
                se_cl = se_ml.copy()
        coeffs = {}
        for i, name in enumerate(var_names):
            # Report cluster-robust as primary, ML as secondary
            t_cl = beta[i] / se_cl[i] if se_cl[i] > 0 and not np.isnan(se_cl[i]) else np.nan
            n_clusters = len(np.unique(cluster_ids)) if cluster_ids is not None else n
            p_cl = 2 * spstats.t.sf(abs(t_cl), df=n_clusters - 1) if not np.isnan(t_cl) else np.nan
            t_ml = beta[i] / se_ml[i] if se_ml[i] > 0 and not np.isnan(se_ml[i]) else np.nan
            p_ml = 2 * (1 - sp_norm.cdf(abs(t_ml))) if not np.isnan(t_ml) else np.nan
            coeffs[name] = {
                'beta': float(beta[i]),
                'se': float(se_cl[i]), 'p': float(p_cl),
                'se_ml': float(se_ml[i]), 'p_ml': float(p_ml),
            }
        return {'n': n, 'n_observed': n_obs, 'n_censored': n_cens, 'sigma': float(sigma),
                'n_clusters': len(np.unique(cluster_ids)) if cluster_ids is not None else None,
                'converged': True, 'coefficients': coeffs}

    tobit_results = {}
    for gdp_half, gdp_label in [(None, 'ind_full'), ('upper', 'ind_upper')]:
        # Build matrices including zeros, with sport FE
        sub = subset(rows, sport_type='individual', gdp_half=gdp_half, drop_zeros=False)
        y, X, names, cl = build_matrices(sub, include_lag=True, include_lag2=True,
                                          sport_fe=True, game_fe=True)
        if y is None:
            print(f"    Tobit {gdp_label}: insufficient data")
            continue
        print(f"    Tobit {gdp_label}: n={len(y)}, obs={int((y>0).sum())}, cens={int((y==0).sum())}, k={X.shape[1]}")
        tres = run_tobit(y, X, names, cluster_ids=cl)
        if tres:
            gc = tres['coefficients'].get('gini_x_cost', {})
            p_cl = gc.get('p', 1)
            p_ml = gc.get('p_ml', 1)
            s_cl = '***' if p_cl < 0.001 else '**' if p_cl < 0.01 else '*' if p_cl < 0.05 else ''
            s_ml = '***' if p_ml < 0.001 else '**' if p_ml < 0.01 else '*' if p_ml < 0.05 else ''
            print(f"    Tobit {gdp_label}: gini_x_cost β={gc.get('beta', 0):.4f}, p_cluster={p_cl:.4f}{s_cl}, p_ml={p_ml:.4f}{s_ml}")
            tobit_results[gdp_label] = {
                'n': tres['n'], 'n_observed': tres['n_observed'], 'n_censored': tres['n_censored'],
                'gini_x_cost': tres['coefficients'].get('gini_x_cost'),
                'gini': tres['coefficients'].get('gini'),
                'ln_gdp': tres['coefficients'].get('ln_gdp'),
                'ln_pop': tres['coefficients'].get('ln_pop'),
                'ln_lag': tres['coefficients'].get('ln_lag'),
                'ln_lag2': tres['coefficients'].get('ln_lag2'),
            }
    results['tobit'] = tobit_results

    # G3: Soviet split
    print("\n  --- G3: Soviet split ---")
    soviet_split = {}
    for is_soviet in [True, False]:
        label = 'soviet' if is_soviet else 'non_soviet'
        # POSITIVE-POINTS FILTER: applied via subset(drop_zeros=True)
        sub_all = subset(rows, sport_type='individual', gdp_half='upper')
        sub = [r for r in sub_all if bool(r.get('soviet_legacy')) == is_soviet]

        # Build matrices without the soviet dummy (meaningless within split)
        data = []
        cluster_ids = []
        for r in sub:
            equip = r['cost_equip_eur_pr_year']
            gdp = r['gdp_pc_ppp']
            pop = r['population']
            gini = r['gini']
            lag = r.get('lag_olympic_6pt')
            lag2 = r.get('lag2_olympic_6pt')
            if any(v is None for v in [equip, gdp, pop, gini]) or lag is None or lag2 is None:
                continue
            if equip <= 0 or gdp <= 0 or pop <= 0:
                continue
            data.append({
                'olympic_6pt': r['olympic_6pt'],
                'ln_gdp': np.log(gdp), 'ln_pop': np.log(pop),
                'gini': gini, 'gini_x_cost': gini * np.log(equip),
                'ln_lag': np.log(1 + lag),
                'ln_lag2': np.log(1 + lag2),
                'pct_muslim': r.get('pct_muslim', 0) or 0,
                'pct_hindu': r.get('pct_hindu', 0) or 0,
                'pct_buddhist': r.get('pct_buddhist', 0) or 0,
                'pct_christian': r.get('pct_christian', 0) or 0,
                'sport_name': r['sport_name'], 'game_year': r['game_year'], 'noc': r['noc'],
            })
            cluster_ids.append(r['noc'])

        if len(data) < 20:
            print(f"  {label}: n={len(data)} too small")
            continue

        yv = np.array([d['olympic_6pt'] for d in data])
        vn = ['const', 'ln_gdp', 'ln_pop', 'gini', 'gini_x_cost'] + list(RELIGION_COLS) + ['ln_lag', 'ln_lag2']
        all_sports = sorted(set(d['sport_name'] for d in data))
        sport_d = all_sports[1:]
        all_games = sorted(set(d['game_year'] for d in data))
        game_d = all_games[1:]
        vn += [f'sport_{s}' for s in sport_d] + [f'game_{g}' for g in game_d]

        Xv = []
        for d in data:
            row = [1.0, d['ln_gdp'], d['ln_pop'], d['gini'], d['gini_x_cost']]
            for rc in RELIGION_COLS:
                row.append(d[rc])
            row.append(d['ln_lag'])
            row.append(d['ln_lag2'])
            for s in sport_d:
                row.append(1.0 if d['sport_name'] == s else 0.0)
            for g in game_d:
                row.append(1.0 if d['game_year'] == g else 0.0)
            Xv.append(row)

        res = ols(yv, np.array(Xv), vn, cluster_ids=cluster_ids)
        if res:
            soviet_split[label] = {
                'n': res['n'], 'r2': res['r2'],
                'n_clusters': res.get('n_clusters'),
                'gini_x_cost': coeff(res, 'gini_x_cost'),
                'gini': coeff(res, 'gini'),
                'ln_lag': coeff(res, 'ln_lag'),
            }
            print(f"  {label} (n={res['n']}): {fmt(res, 'gini_x_cost')}")

    results['soviet_split'] = soviet_split

    # G4: Per-sport betas
    print("\n  --- G4: Per-sport betas ---")
    per_sport = []
    # POSITIVE-POINTS FILTER: applied via subset(drop_zeros=True)
    sub_upper = subset(rows, sport_type='individual', gdp_half='upper')
    sports = sorted(set(r['sport_name'] for r in sub_upper))
    for sport in sports:
        sport_rows = [r for r in sub_upper if r['sport_name'] == sport]
        if len(sport_rows) < 10:
            continue
        data = []
        cluster_ids = []
        for r in sport_rows:
            gdp = r['gdp_pc_ppp']
            pop = r['population']
            gini = r['gini']
            lag = r.get('lag_olympic_6pt')
            lag2 = r.get('lag2_olympic_6pt')
            if any(v is None for v in [gdp, pop, gini]) or lag is None or lag2 is None:
                continue
            if gdp <= 0 or pop <= 0:
                continue
            data.append({
                'olympic_6pt': r['olympic_6pt'], 'ln_gdp': np.log(gdp),
                'ln_pop': np.log(pop), 'gini': gini,
                'soviet': 1.0 if r.get('soviet_legacy') else 0.0,
                'ln_lag': np.log(1 + lag),
                'ln_lag2': np.log(1 + lag2),
                'game_year': r['game_year'], 'noc': r['noc'],
            })
            cluster_ids.append(r['noc'])

        if len(data) < 10:
            continue

        yv = np.array([d['olympic_6pt'] for d in data])
        vn = ['const', 'ln_gdp', 'ln_pop', 'soviet', 'gini', 'ln_lag', 'ln_lag2']
        all_games = sorted(set(d['game_year'] for d in data))
        game_d = all_games[1:]
        vn += [f'game_{g}' for g in game_d]

        Xv = []
        for d in data:
            row = [1.0, d['ln_gdp'], d['ln_pop'], d['soviet'], d['gini'], d['ln_lag'], d['ln_lag2']]
            for g in game_d:
                row.append(1.0 if d['game_year'] == g else 0.0)
            Xv.append(row)

        res = ols(yv, np.array(Xv), vn, cluster_ids=cluster_ids)
        if res:
            gc = coeff(res, 'gini')
            equip = sport_rows[0]['cost_equip_eur_pr_year']
            per_sport.append({
                'sport_name': sport, 'equipment_eur': equip,
                'gini_b': gc['beta'], 'gini_p': gc['p'],
                'n': res['n'],
            })

    results['per_sport'] = per_sport
    print(f"  Per-sport: {len(per_sport)} sports estimated")

    # G5: Religion vs Region comparison
    print("\n  --- G5: Religion vs Region ---")
    rel_vs_reg = {}
    for gdp_half in [None, 'upper']:
        label = f"ind_{gdp_half or 'full'}"
        sub = subset(rows, sport_type='individual', gdp_half=gdp_half)

        res_rel = run_reg(sub, label=f"religion {label}", control='religion',
                          print_key='gini_x_cost')
        res_reg = run_reg(sub, label=f"region {label}", control='region',
                          print_key='gini_x_cost')

        rel_vs_reg[label] = {
            'religion': {
                'gini_x_cost': coeff(res_rel, 'gini_x_cost') if res_rel else None,
                'n': res_rel['n'] if res_rel else None,
                'r2': res_rel['r2'] if res_rel else None,
            },
            'region': {
                'gini_x_cost': coeff(res_reg, 'gini_x_cost') if res_reg else None,
                'n': res_reg['n'] if res_reg else None,
                'r2': res_reg['r2'] if res_reg else None,
            },
        }
    results['religion_vs_region'] = rel_vs_reg

    # G6: Mundlak
    print("\n  --- G6: Mundlak ---")
    mundlak = {}
    for gdp_half in [None, 'upper']:
        label = f"ind_{gdp_half or 'full'}"
        sub = subset(rows, sport_type='individual', gdp_half=gdp_half)

        res_no = run_reg(sub, label=f"no_mundlak {label}", print_key='gini_x_cost')
        res_m = run_reg(sub, label=f"mundlak {label}", include_mundlak=True,
                        print_key='gini_x_cost')

        mundlak[label] = {
            'without': coeff(res_no, 'gini_x_cost') if res_no else None,
            'with': coeff(res_m, 'gini_x_cost') if res_m else None,
        }
    results['mundlak'] = mundlak

    # G7: EFW (now in panel directly)
    print("\n  --- G7: Economic Freedom (EFW) ---")
    efw_results = {}

    rows_efw = [r for r in rows if r.get('efw') is not None]

    if rows_efw:
        sub = subset(rows_efw, sport_type='individual', gdp_half='upper')
        if sub:
            res_efw = run_reg(sub, label="EFW control", include_efw=True,
                              print_key='gini_x_cost')
            res_efw_int = run_reg(sub, label="EFW×cost", include_efw=True,
                                  include_efw_x_cost=True, print_key='gini_x_cost')

            efw_results['ind_upper'] = {
                'with_efw_control': {
                    'gini_x_cost': coeff(res_efw, 'gini_x_cost') if res_efw else None,
                    'efw': coeff(res_efw, 'efw') if res_efw else None,
                },
                'with_efw_interaction': {
                    'gini_x_cost': coeff(res_efw_int, 'gini_x_cost') if res_efw_int else None,
                    'efw_x_cost': coeff(res_efw_int, 'efw_x_cost') if res_efw_int else None,
                },
            }

        results['efw'] = efw_results

    # G8: GDP specification
    print("\n  --- G8: GDP specification ---")
    gdp_spec = {}
    for gdp_half in [None, 'upper']:
        label = f"ind_{gdp_half or 'full'}"
        sub = subset(rows, sport_type='individual', gdp_half=gdp_half)

        res_ln = run_reg(sub, label=f"ln_gdp {label}", print_key='gini_x_cost')
        res_lev = run_reg(sub, label=f"gdp_level {label}", gdp_level=True,
                          print_key='gini_x_cost')

        gdp_spec[label] = {
            'ln_gdp': coeff(res_ln, 'gini_x_cost') if res_ln else None,
            'gdp_level': coeff(res_lev, 'gini_x_cost') if res_lev else None,
        }
    results['gdp_specification'] = gdp_spec

    # G9: Soviet no-lag and attenuation
    print("\n  --- G9: Soviet attenuation (with/without lag) ---")
    soviet_attenuation = {}
    for is_soviet in [True, False]:
        label = 'soviet' if is_soviet else 'non_soviet'
        sub_all = subset(rows, sport_type='individual', gdp_half='upper')
        sub = [r for r in sub_all if bool(r.get('soviet_legacy')) == is_soviet]

        # Build manually (same as G3 but also run without lag)
        def _soviet_reg(sub_rows, use_lag):
            data_s = []
            cl_s = []
            for r in sub_rows:
                equip = r['cost_equip_eur_pr_year']
                gdp = r['gdp_pc_ppp']
                pop = r['population']
                gini = r['gini']
                lag = r.get('lag_olympic_6pt')
                lag2 = r.get('lag2_olympic_6pt')
                if any(v is None for v in [equip, gdp, pop, gini]):
                    continue
                if use_lag and (lag is None or lag2 is None):
                    continue
                if equip <= 0 or gdp <= 0 or pop <= 0:
                    continue
                d = {
                    'olympic_6pt': r['olympic_6pt'],
                    'ln_gdp': np.log(gdp), 'ln_pop': np.log(pop),
                    'gini': gini, 'gini_x_cost': gini * np.log(equip),
                    'pct_muslim': r.get('pct_muslim', 0) or 0,
                    'pct_hindu': r.get('pct_hindu', 0) or 0,
                    'pct_buddhist': r.get('pct_buddhist', 0) or 0,
                    'pct_christian': r.get('pct_christian', 0) or 0,
                    'sport_name': r['sport_name'], 'game_year': r['game_year'], 'noc': r['noc'],
                }
                if use_lag:
                    d['ln_lag'] = np.log(1 + lag)
                    d['ln_lag2'] = np.log(1 + lag2)
                data_s.append(d)
                cl_s.append(r['noc'])
            if len(data_s) < 20:
                return None
            yv = np.array([d['olympic_6pt'] for d in data_s])
            vn = ['const', 'ln_gdp', 'ln_pop', 'gini', 'gini_x_cost'] + list(RELIGION_COLS)
            if use_lag:
                vn.append('ln_lag')
                vn.append('ln_lag2')
            all_sp = sorted(set(d['sport_name'] for d in data_s))
            sp_d = all_sp[1:]
            all_gm = sorted(set(d['game_year'] for d in data_s))
            gm_d = all_gm[1:]
            vn += [f'sport_{s}' for s in sp_d] + [f'game_{g}' for g in gm_d]
            Xv = []
            for d in data_s:
                row = [1.0, d['ln_gdp'], d['ln_pop'], d['gini'], d['gini_x_cost']]
                for rc in RELIGION_COLS:
                    row.append(d[rc])
                if use_lag:
                    row.append(d['ln_lag'])
                    row.append(d['ln_lag2'])
                for s in sp_d:
                    row.append(1.0 if d['sport_name'] == s else 0.0)
                for g in gm_d:
                    row.append(1.0 if d['game_year'] == g else 0.0)
                Xv.append(row)
            return ols(yv, np.array(Xv), vn, cluster_ids=cl_s)

        res_lag = _soviet_reg(sub, True)
        res_nolag = _soviet_reg(sub, False)
        if res_lag and res_nolag:
            b_lag = coeff(res_lag, 'gini_x_cost')['beta']
            b_nolag = coeff(res_nolag, 'gini_x_cost')['beta']
            att = (1 - b_lag / b_nolag) * 100 if b_nolag != 0 else 0
            soviet_attenuation[label] = {
                'with_lag': {
                    'gini_x_cost': coeff(res_lag, 'gini_x_cost'),
                    'gini': coeff(res_lag, 'gini'),
                    'ln_lag': coeff(res_lag, 'ln_lag'),
                    'n': res_lag['n'], 'r2': res_lag['r2'],
                    'n_clusters': res_lag.get('n_clusters'),
                },
                'without_lag': {
                    'gini_x_cost': coeff(res_nolag, 'gini_x_cost'),
                    'gini': coeff(res_nolag, 'gini'),
                    'n': res_nolag['n'], 'r2': res_nolag['r2'],
                    'n_clusters': res_nolag.get('n_clusters'),
                },
                'attenuation_pct': round(att, 1),
            }
            print(f"  {label} with lag: {fmt(res_lag, 'gini_x_cost')}")
            print(f"  {label} no lag: {fmt(res_nolag, 'gini_x_cost')}")
            print(f"  {label} attenuation: {att:.1f}%")

    # Also Soviet in lower GDP half
    for is_soviet in [True, False]:
        label = f"{'soviet' if is_soviet else 'non_soviet'}_lower"
        sub_all = subset(rows, sport_type='individual', gdp_half='lower')
        sub = [r for r in sub_all if bool(r.get('soviet_legacy')) == is_soviet]
        res_lag = _soviet_reg(sub, True)
        res_nolag = _soviet_reg(sub, False)
        if res_lag and res_nolag:
            b_lag = coeff(res_lag, 'gini_x_cost')['beta']
            b_nolag = coeff(res_nolag, 'gini_x_cost')['beta']
            att = (1 - b_lag / b_nolag) * 100 if b_nolag != 0 else 0
            soviet_attenuation[label] = {
                'with_lag': {
                    'gini_x_cost': coeff(res_lag, 'gini_x_cost'),
                    'gini': coeff(res_lag, 'gini'),
                    'ln_lag': coeff(res_lag, 'ln_lag'),
                    'n': res_lag['n'], 'r2': res_lag['r2'],
                },
                'without_lag': {
                    'gini_x_cost': coeff(res_nolag, 'gini_x_cost'),
                    'gini': coeff(res_nolag, 'gini'),
                    'n': res_nolag['n'], 'r2': res_nolag['r2'],
                },
                'attenuation_pct': round(att, 1),
            }
            print(f"  {label} with lag: {fmt(res_lag, 'gini_x_cost')}")
            print(f"  {label} no lag: {fmt(res_nolag, 'gini_x_cost')}")
        elif res_lag:
            soviet_attenuation[label] = {
                'with_lag': {
                    'gini_x_cost': coeff(res_lag, 'gini_x_cost'),
                    'n': res_lag['n'], 'r2': res_lag['r2'],
                },
            }
            print(f"  {label} with lag only: {fmt(res_lag, 'gini_x_cost')}")

    results['soviet_attenuation'] = soviet_attenuation

    # G10: Team excluding football
    print("\n  --- G10: Team excl. football ---")
    team_excl_fb = {}
    for gdp_half in [None, 'upper']:
        label = f"team_excl_fb_{gdp_half or 'full'}"
        sub = subset(rows, sport_type='team', gdp_half=gdp_half)
        sub = [r for r in sub if r['sport_name'] != 'Football (Soccer)']
        res = run_reg(sub, label=label, print_key='gini_x_cost')
        if res:
            team_excl_fb[gdp_half or 'full'] = {
                'n': res['n'], 'r2': res['r2'],
                'n_clusters': res.get('n_clusters'),
                'gini_x_cost': coeff(res, 'gini_x_cost'),
                'gini': coeff(res, 'gini'),
                'ln_lag': coeff(res, 'ln_lag'),
            }
    results['team_excl_football'] = team_excl_fb

    return results


# ============================================================
# G7.7. GENDER DECOMPOSITION (NEW IN v1.00)
# ============================================================

def section_G77_gender_decomposition(rows):
    """Gender decomposition: run main spec with points_men / points_women as DV.

    Fix #4: Uses pre-built points_men and points_women columns from the v1.00 panel.
    Gender-specific lags are computed here (same country, same sport, previous game).
    """
    print("\n" + "=" * 60)
    print("  G7.7. GENDER DECOMPOSITION")
    print("=" * 60)

    # Step 1: Compute gender-specific lags from the full regression sample.
    # Lag = points_men (or points_women) for the same country-sport in the previous game.
    # Games: 1992, 1996 are seeds; regression starts at 2000.

    # Build lookup: (noc, sport, game_year) -> {points_men, points_women}
    # We need ALL rows (including 1992/1996 seeds) for lag computation
    all_rows_for_lag = [r for r in raw_rows if r.get('simulation_eligible', True)]
    gender_lookup = {}
    for r in all_rows_for_lag:
        key = (r['noc'], r['sport_name'], r['game_year'])
        gender_lookup[key] = {
            'olympic_6pt_men': r.get('olympic_6pt_men', 0) or 0,
            'olympic_6pt_women': r.get('olympic_6pt_women', 0) or 0,
        }

    # Game sequence for lag computation
    GAME_SEQUENCE = [1992, 1996, 2000, 2004, 2008, 2012, 2016, 2020, 2024]
    game_to_prev = {GAME_SEQUENCE[i]: GAME_SEQUENCE[i-1] for i in range(1, len(GAME_SEQUENCE))}
    game_to_prev2 = {GAME_SEQUENCE[i]: GAME_SEQUENCE[i-2] for i in range(2, len(GAME_SEQUENCE))}

    # Add gender lags to regression rows
    for r in rows:
        prev_game = game_to_prev.get(r['game_year'])
        prev2_game = game_to_prev2.get(r['game_year'])
        if prev_game is not None:
            prev_key = (r['noc'], r['sport_name'], prev_game)
            prev = gender_lookup.get(prev_key, {})
            r['lag_olympic_6pt_men'] = prev.get('olympic_6pt_men', 0)
            r['lag_olympic_6pt_women'] = prev.get('olympic_6pt_women', 0)
        else:
            r['lag_olympic_6pt_men'] = None
            r['lag_olympic_6pt_women'] = None
        if prev2_game is not None:
            prev2_key = (r['noc'], r['sport_name'], prev2_game)
            prev2 = gender_lookup.get(prev2_key, {})
            r['lag2_olympic_6pt_men'] = prev2.get('olympic_6pt_men', 0)
            r['lag2_olympic_6pt_women'] = prev2.get('olympic_6pt_women', 0)
        else:
            r['lag2_olympic_6pt_men'] = None
            r['lag2_olympic_6pt_women'] = None

    results = {}

    for gender_label, pts_col, lag_col, lag2_col in [
        ('men', 'olympic_6pt_men', 'lag_olympic_6pt_men', 'lag2_olympic_6pt_men'),
        ('women', 'olympic_6pt_women', 'lag_olympic_6pt_women', 'lag2_olympic_6pt_women'),
    ]:
        print(f"\n  --- {gender_label.upper()} ---")

        for gdp_half in [None, 'upper']:
            label = f"ind_{gdp_half or 'full'}_{gender_label}"

            # POSITIVE-POINTS FILTER: filter on gender-specific points > 0
            sub_base = [r for r in rows if r.get('sport_type') == 'individual']
            if gdp_half == 'upper':
                sub_base = [r for r in sub_base if r['noc'] in UPPER_NOCS]
            elif gdp_half == 'lower':
                sub_base = [r for r in sub_base if r['noc'] in LOWER_NOCS]
            sub = [r for r in sub_base if (r.get(pts_col) or 0) > 0]

            # Build matrices manually with gender-specific DV and lag
            data = []
            cluster_ids = []
            for r in sub:
                equip = r.get('cost_equip_eur_pr_year')
                gdp = r['gdp_pc_ppp']
                pop = r['population']
                gini = r['gini']
                lag_g = r.get(lag_col)
                lag2_g = r.get(lag2_col)
                if any(v is None for v in [equip, gdp, pop, gini]) or lag_g is None or lag2_g is None:
                    continue
                if equip <= 0 or gdp <= 0 or pop <= 0:
                    continue

                data.append({
                    'olympic_6pt': r[pts_col],
                    'ln_gdp': np.log(gdp), 'ln_pop': np.log(pop),
                    'soviet': 1.0 if r.get('soviet_legacy') else 0.0,
                    'gini': gini,
                    'gini_x_cost': gini * np.log(equip),
                    'ln_lag': np.log(1 + lag_g),
                    'ln_lag2': np.log(1 + lag2_g),
                    'pct_muslim': r.get('pct_muslim', 0) or 0,
                    'pct_hindu': r.get('pct_hindu', 0) or 0,
                    'pct_buddhist': r.get('pct_buddhist', 0) or 0,
                    'pct_christian': r.get('pct_christian', 0) or 0,
                    'sport_name': r['sport_name'], 'game_year': r['game_year'], 'noc': r['noc'],
                })
                cluster_ids.append(r['noc'])

            if len(data) < 30:
                print(f"  {label}: insufficient data ({len(data)} rows)")
                continue

            yv = np.array([d['olympic_6pt'] for d in data])
            vn = ['const', 'ln_gdp', 'ln_pop', 'soviet', 'gini', 'gini_x_cost'] + \
                 list(RELIGION_COLS) + ['ln_lag', 'ln_lag2']

            all_sports = sorted(set(d['sport_name'] for d in data))
            sport_d = all_sports[1:]
            all_games = sorted(set(d['game_year'] for d in data))
            game_d = all_games[1:]
            vn += [f'sport_{s}' for s in sport_d] + [f'game_{g}' for g in game_d]

            Xv = []
            for d in data:
                row = [1.0, d['ln_gdp'], d['ln_pop'], d['soviet'], d['gini'], d['gini_x_cost']]
                for rc in RELIGION_COLS:
                    row.append(d[rc])
                row.append(d['ln_lag'])
                row.append(d['ln_lag2'])
                for s in sport_d:
                    row.append(1.0 if d['sport_name'] == s else 0.0)
                for g in game_d:
                    row.append(1.0 if d['game_year'] == g else 0.0)
                Xv.append(row)

            res = ols(yv, np.array(Xv), vn, cluster_ids=cluster_ids)
            if res:
                results[label] = {
                    'n': res['n'], 'r2': res['r2'],
                    'n_clusters': res.get('n_clusters'),
                    'gini_x_cost': coeff(res, 'gini_x_cost'),
                    'gini': coeff(res, 'gini'),
                    'ln_lag': coeff(res, 'ln_lag'),
                }
                print(f"  {label} (n={res['n']}, clusters={res.get('n_clusters', '?')}): "
                      f"Gini×equip {fmt(res, 'gini_x_cost')}")

    # GGI × equipment cost (on combined gender sample)
    print("\n  --- GGI × equipment cost ---")
    sub_upper = subset(rows, sport_type='individual', gdp_half='upper')
    ggi_sub = [r for r in sub_upper if r.get('ggi') is not None]
    if len(ggi_sub) >= 30:
        res_ggi = run_reg(ggi_sub, label="GGI×equip ind_upper",
                          include_ggi=True, print_key='ggi')
        if res_ggi:
            results['ggi_x_equip'] = {
                'n': res_ggi['n'], 'r2': res_ggi['r2'],
                'ggi': coeff(res_ggi, 'ggi'),
                'gini_x_cost': coeff(res_ggi, 'gini_x_cost'),
            }

    return results


# ============================================================
# H. POPULATION ELASTICITY (Section 8.5, NEW IN v1.00)
# ============================================================

def section_H_population_elasticity(rows):
    """Population elasticity: ln(total_points) ~ ln(pop) + ln(GDP) + game FE.

    Fix #3: Uses ln(total_points) NOT ln(total_points + 1).
    Filters to country-game observations with positive total points first.
    Country-clustered SEs.
    """
    print("\n" + "=" * 60)
    print("  H. POPULATION ELASTICITY (Section 8.5)")
    print("=" * 60)

    # Aggregate to country-game level
    agg = defaultdict(lambda: defaultdict(float))
    meta = {}
    for r in rows:
        key = (r['noc'], r['game_year'])
        agg[key]['olympic_6pt'] += r['olympic_6pt']
        if key not in meta:
            meta[key] = r

    results = {}

    # Build regression data
    data = []
    cluster_ids = []
    for (noc, game), vals in agg.items():
        total_pts = vals['olympic_6pt']
        # POSITIVE-POINTS FILTER: must have positive total points for ln(total)
        if total_pts <= 0:
            continue
        base = meta[(noc, game)]
        gdp = base['gdp_pc_ppp']
        pop = base['population']
        gini = base['gini']
        if any(v is None for v in [gdp, pop, gini]) or gdp <= 0 or pop <= 0:
            continue

        data.append({
            'ln_total_points': np.log(total_pts),
            'ln_gdp': np.log(gdp),
            'ln_pop': np.log(pop),
            'gini': gini,
            'soviet': 1.0 if base.get('soviet_legacy') else 0.0,
            'game_year': game,
            'noc': noc,
        })
        cluster_ids.append(noc)

    if len(data) < 30:
        print("  Insufficient data for population elasticity")
        return results

    print(f"  Aggregate observations (positive total points): {len(data)}")
    print(f"  Countries: {len(set(d['noc'] for d in data))}")

    # Specification: ln(total_points) ~ ln(pop) + ln(GDP) + gini + soviet + religion + game FE
    yv = np.array([d['ln_total_points'] for d in data])

    # Also add religion controls from meta
    for d in data:
        base = meta[(d['noc'], d['game_year'])]
        for rc in RELIGION_COLS:
            d[rc] = base.get(rc, 0) or 0

    vn = ['const', 'ln_gdp', 'ln_pop', 'gini', 'soviet'] + list(RELIGION_COLS)
    all_games = sorted(set(d['game_year'] for d in data))
    game_d = all_games[1:]
    vn += [f'game_{g}' for g in game_d]

    Xv = []
    for d in data:
        row = [1.0, d['ln_gdp'], d['ln_pop'], d['gini'], d['soviet']]
        for rc in RELIGION_COLS:
            row.append(d[rc])
        for g in game_d:
            row.append(1.0 if d['game_year'] == g else 0.0)
        Xv.append(row)

    res = ols(yv, np.array(Xv), vn, cluster_ids=cluster_ids)
    if res:
        alpha = coeff(res, 'ln_pop')
        print(f"  Population elasticity α = {alpha['beta']:.4f} (SE={alpha['se']:.4f})")

        # Test α ≠ 1
        if alpha['se'] and alpha['se'] > 0:
            t_not1 = (alpha['beta'] - 1) / alpha['se']
            # Two-sided test
            n_clusters = res.get('n_clusters', len(set(cluster_ids)))
            p_not1 = 2 * (1 - spstats.t.cdf(abs(t_not1), n_clusters - 1))
            # One-sided: test α < 1
            p_below1 = spstats.t.cdf(t_not1, n_clusters - 1)
            print(f"  Test α ≠ 1: t = {t_not1:.4f}, p = {p_not1:.4f}")
            print(f"  Test α < 1: p = {p_below1:.4f}")
        else:
            t_not1, p_not1, p_below1 = None, None, None

        results['aggregate_log_log'] = {
            'n': res['n'], 'r2': res['r2'],
            'n_clusters': res.get('n_clusters'),
            'alpha': alpha,
            'gini': coeff(res, 'gini'),
            'ln_gdp': coeff(res, 'ln_gdp'),
            'test_alpha_ne_1': {
                't': round(t_not1, 4) if t_not1 is not None else None,
                'p': round(p_not1, 4) if p_not1 is not None else None,
            },
            'test_alpha_lt_1': {
                'p': round(p_below1, 4) if p_below1 is not None else None,
            },
        }

    # Also report sport-level α from primary spec (Section D individual upper)
    print("\n  --- Sport-level α (from primary spec) ---")
    sub_upper = subset(rows, sport_type='individual', gdp_half='upper')
    y_sp, X_sp, names_sp, cl_sp = build_matrices(sub_upper, control='religion')
    if y_sp is not None:
        res_sp = ols(y_sp, X_sp, names_sp, cluster_ids=cl_sp)
        if res_sp:
            alpha_sp = coeff(res_sp, 'ln_pop')
            print(f"  Sport-level α = {alpha_sp['beta']:.4f} (SE={alpha_sp['se']:.4f})")
            if alpha_sp['se'] and alpha_sp['se'] > 0:
                t_sp = (alpha_sp['beta'] - 1) / alpha_sp['se']
                n_cl_sp = res_sp.get('n_clusters', len(set(cl_sp)))
                p_sp = spstats.t.cdf(t_sp, n_cl_sp - 1)
            else:
                t_sp, p_sp = None, None
            results['sport_level'] = {
                'alpha': alpha_sp,
                'test_alpha_lt_1': {
                    't': round(t_sp, 4) if t_sp is not None else None,
                    'p': round(p_sp, 4) if p_sp is not None else None,
                },
            }

    # Correlation between Gini and ln(Pop)
    gini_vals = [d['gini'] for d in data]
    pop_vals = [d['ln_pop'] for d in data]
    if len(gini_vals) > 2:
        corr, _ = spstats.pearsonr(gini_vals, pop_vals)
        results['corr_gini_ln_pop'] = round(corr, 4)
        print(f"  Corr(Gini, ln(Pop)): r = {corr:.4f}")

    return results


# ============================================================
# I. TWO-PERIOD ROBUSTNESS (load from secondary script)
# ============================================================

def section_J_discussion_stats(rows):
    """Descriptive stats and supplementary regressions for Section 8."""
    print("\n" + "=" * 60)
    print("  J. DISCUSSION STATISTICS (Section 8)")
    print("=" * 60)

    results = {}

    # J1: Persistence correlation — consecutive game-to-game, individual sports
    # This is the cleanest definition: it matches what the lag variable controls for.
    print("\n  --- J1: Persistence correlation (consecutive game-to-game) ---")
    ind_with_lag = [r for r in rows if r['sport_type'] == 'individual'
                    and r['olympic_6pt'] > 0 and r.get('lag_olympic_6pt') is not None]
    if len(ind_with_lag) > 5:
        pts = np.array([r['olympic_6pt'] for r in ind_with_lag])
        lags = np.array([r['lag_olympic_6pt'] for r in ind_with_lag])
        r_corr, r_p = spstats.pearsonr(pts, lags)
        results['persistence_correlation'] = {
            'r': round(r_corr, 3),
            'p': round(r_p, 6),
            'n': len(ind_with_lag),
            'description': 'Pearson r between olympic_6pt and lag_olympic_6pt, individual sports with positive points, all consecutive games',
        }
        print(f"  r(olympic_6pt, lag_olympic_6pt) for individual sports: r = {r_corr:.3f} (n = {len(ind_with_lag)})")

    # J1b: Mean reversion test (Section 5.1)
    # Uses full 9-game panel (1992-2024) for maximum power — the test constructs
    # its own lags from consecutive appearances, so no regression-sample restriction needed.
    print("\n  --- J1b: Mean reversion test (full 9-game panel) ---")
    ind_upper_pos = [r for r in raw_rows if r.get('sport_type') == 'individual'
                     and r.get('noc') in UPPER_NOCS and (r.get('olympic_6pt') or 0) > 0]
    # Group by (noc, sport), sorted by game_year
    from collections import defaultdict
    pair_groups = defaultdict(list)
    for r in ind_upper_pos:
        pair_groups[(r['noc'], r['sport_name'])].append(r)

    dev_data = []
    for (noc, sport), grp in pair_groups.items():
        grp_sorted = sorted(grp, key=lambda r: r['game_year'])
        pair_mean = np.mean([r['olympic_6pt'] for r in grp_sorted])
        for i in range(1, len(grp_sorted)):
            dev_data.append({
                'noc': noc,
                'dev_t': grp_sorted[i]['olympic_6pt'] - pair_mean,
                'dev_t1': grp_sorted[i - 1]['olympic_6pt'] - pair_mean,
            })

    if len(dev_data) > 10:
        dev_y = np.array([d['dev_t'] for d in dev_data])
        dev_X = np.column_stack([np.ones(len(dev_data)),
                                  [d['dev_t1'] for d in dev_data]])
        dev_cl = [d['noc'] for d in dev_data]
        dev_res = ols(dev_y, dev_X, ['const', 'dev_t1'], cluster_ids=dev_cl)
        if dev_res:
            mr_coef = dev_res['coefficients']['dev_t1']['beta']
            mr_p = dev_res['coefficients']['dev_t1']['p']
            results['mean_reversion'] = {
                'coefficient': round(mr_coef, 4),
                'p': round(mr_p, 6),
                'n_pairs': len(dev_data),
                'n_obs_source': len(ind_upper_pos),
                'description': 'Deviation from pair mean at t regressed on deviation at t-1, country-clustered SE',
            }
            print(f"  Momentum coefficient: {mr_coef:.4f} (p = {mr_p:.4f}), {len(dev_data)} pairs from {len(ind_upper_pos)} obs")

    # J2: Lag × cost interactions
    print("\n  --- J2: Lag × cost interactions ---")
    sub = subset(rows, sport_type='individual', gdp_half='upper')
    # Build regression: points ~ ... + ln_lag × ln(facility) + ln_lag × ln(equip)
    data = []
    cluster_ids = []
    for r in sub:
        equip = r['cost_equip_eur_pr_year']
        fac = r.get('cost_national_facility_eur')
        gdp = r['gdp_pc_ppp']
        pop = r['population']
        gini = r['gini']
        lag = r.get('lag_olympic_6pt')
        lag2 = r.get('lag2_olympic_6pt')
        if any(v is None for v in [equip, gdp, pop, gini, lag, lag2, fac]):
            continue
        if equip <= 0 or gdp <= 0 or pop <= 0 or fac <= 0:
            continue
        ln_lag = np.log(1 + lag)
        ln_lag2 = np.log(1 + lag2)
        ln_equip = np.log(equip)
        ln_fac = np.log(fac)
        d = {
            'olympic_6pt': r['olympic_6pt'],
            'ln_gdp': np.log(gdp), 'ln_pop': np.log(pop),
            'gini': gini, 'gini_x_cost': gini * ln_equip,
            'soviet': 1.0 if r.get('soviet_legacy') else 0.0,
            'ln_lag': ln_lag,
            'ln_lag2': ln_lag2,
            'lag_x_fac': ln_lag * ln_fac,
            'lag_x_equip': ln_lag * ln_equip,
            'sport_name': r['sport_name'], 'game_year': r['game_year'], 'noc': r['noc'],
        }
        for rc in RELIGION_COLS:
            d[rc] = r.get(rc, 0) or 0
        data.append(d)
        cluster_ids.append(r['noc'])

    if len(data) >= 30:
        yv = np.array([d['olympic_6pt'] for d in data])
        vn = ['const', 'ln_gdp', 'ln_pop', 'soviet', 'gini', 'gini_x_cost'] + list(RELIGION_COLS) + ['ln_lag', 'ln_lag2', 'lag_x_fac', 'lag_x_equip']
        all_sp = sorted(set(d['sport_name'] for d in data))
        sp_d = all_sp[1:]
        all_gm = sorted(set(d['game_year'] for d in data))
        gm_d = all_gm[1:]
        vn += [f'sport_{s}' for s in sp_d] + [f'game_{g}' for g in gm_d]

        Xv = []
        for d in data:
            row = [1.0, d['ln_gdp'], d['ln_pop'], d['soviet'], d['gini'], d['gini_x_cost']]
            for rc in RELIGION_COLS:
                row.append(d[rc])
            row += [d['ln_lag'], d['ln_lag2'], d['lag_x_fac'], d['lag_x_equip']]
            for s in sp_d:
                row.append(1.0 if d['sport_name'] == s else 0.0)
            for g in gm_d:
                row.append(1.0 if d['game_year'] == g else 0.0)
            Xv.append(row)

        res = ols(yv, np.array(Xv), vn, cluster_ids=cluster_ids)
        if res:
            results['lag_x_facility'] = coeff(res, 'lag_x_fac')
            results['lag_x_equipment'] = coeff(res, 'lag_x_equip')
            results['lag_cost_n'] = res['n']
            results['lag_cost_r2'] = res['r2']
            print(f"  Lag × ln(facility): {fmt(res, 'lag_x_fac')}")
            print(f"  Lag × ln(equip): {fmt(res, 'lag_x_equip')}")

    # J3: Per-sport lag coefficients (for Figure 6)
    print("\n  --- J3: Per-sport lag coefficients ---")
    all_sports = sorted(set(r['sport_name'] for r in rows if r['olympic_6pt'] > 0))
    sport_lags = []
    for sport in all_sports:
        sp_rows = [r for r in rows if r['sport_name'] == sport and r['olympic_6pt'] > 0]
        if len(sp_rows) < 15:
            continue
        data = []
        cl = []
        for r in sp_rows:
            gdp = r['gdp_pc_ppp']
            pop = r['population']
            gini = r['gini']
            lag = r.get('lag_olympic_6pt')
            lag2 = r.get('lag2_olympic_6pt')
            if any(v is None for v in [gdp, pop, gini, lag, lag2]):
                continue
            if gdp <= 0 or pop <= 0:
                continue
            data.append({
                'olympic_6pt': r['olympic_6pt'], 'ln_gdp': np.log(gdp), 'ln_pop': np.log(pop),
                'gini': gini, 'soviet': 1.0 if r.get('soviet_legacy') else 0.0,
                'ln_lag': np.log(1 + lag), 'ln_lag2': np.log(1 + lag2),
                'game_year': r['game_year'], 'noc': r['noc'],
            })
            cl.append(r['noc'])
        if len(data) < 15:
            continue
        yv = np.array([d['olympic_6pt'] for d in data])
        vn = ['const', 'ln_gdp', 'ln_pop', 'soviet', 'gini', 'ln_lag', 'ln_lag2']
        gms = sorted(set(d['game_year'] for d in data))
        gm_d = gms[1:]
        vn += [f'game_{g}' for g in gm_d]
        Xv = []
        for d in data:
            row = [1.0, d['ln_gdp'], d['ln_pop'], d['soviet'], d['gini'], d['ln_lag'], d['ln_lag2']]
            for g in gm_d:
                row.append(1.0 if d['game_year'] == g else 0.0)
            Xv.append(row)
        res = ols(yv, np.array(Xv), vn, cluster_ids=cl)
        if res:
            lc = coeff(res, 'ln_lag')
            fac_val = sp_rows[0].get('cost_national_facility_eur', 0)
            sport_lags.append({
                'sport_name': sport,
                'sport_type': sp_rows[0].get('sport_type', ''),
                'lag_beta': lc['beta'], 'lag_se': lc['se'], 'lag_p': lc['p'],
                'facility_cost': fac_val,
                'equipment_cost': sp_rows[0].get('cost_equip_eur_pr_year', 0),
                'n': res['n'],
            })
    results['per_sport_lags'] = sport_lags
    print(f"  Sports with lag estimates: {len(sport_lags)}")

    return results


# ============================================================
# MAIN
# ============================================================

def clean_for_json(obj):
    """Remove numpy arrays and internal fields from results."""
    if isinstance(obj, dict):
        return {k: clean_for_json(v) for k, v in obj.items()
                if not k.startswith('_')}
    elif isinstance(obj, list):
        return [clean_for_json(v) for v in obj]
    elif isinstance(obj, (np.integer,)):
        return int(obj)
    elif isinstance(obj, (np.floating,)):
        return float(obj)
    elif isinstance(obj, np.ndarray):
        return obj.tolist()
    return obj


def section_K_cost_classification_comparison():
    """Section 7.1: Spearman rank correlation between v0.91 and v0.93/v1.00
    cost classifications for the 41 main-sample sports."""
    print("\n=== K. Cost Classification Comparison (Section 7.1) ===")

    v091_path = os.path.join(DATA_DIR, 'v091_sport_cost_classification.json')
    v106_path = os.path.join(DATA_DIR, 'v106_sport_cost_classification.json')

    with open(v091_path) as f:
        d91 = json.load(f)
    with open(v106_path) as f:
        d100 = json.load(f)

    sports91 = d91['sports']
    sports100 = d100['sports']

    # Find common main-sample sports
    # The regression variable is equipment cost, so the relevant robustness test
    # is whether the equipment ranking is stable across independent reconstruction.
    # v0.91 cost_equip_eur_pr_year vs v1.00 equipment_annual_eur.
    common = []
    for name in sports100:
        s100 = sports100[name]
        if not s100.get('simulation_eligible', False):
            continue
        # v091 still uses old field names (legacy reference file)
        if name in sports91 and sports91[name].get('in_main_sample', False):
            equip91 = sports91[name].get('equipment_midpoint_eur')
            equip100 = s100.get('equipment_annual_eur')
            if equip91 is not None and equip100 is not None:
                common.append((name, equip91, equip100))

    n_matched = len(common)
    ranks91 = spstats.rankdata([c[1] for c in common])
    ranks100 = spstats.rankdata([c[2] for c in common])
    rho, p_val = spstats.spearmanr([c[1] for c in common], [c[2] for c in common])

    # Rank shift statistics
    abs_shifts = np.abs(ranks91 - ranks100)
    mean_abs_shift = float(np.mean(abs_shifts))
    n_shift_ge5 = int(np.sum(abs_shifts >= 5))
    n_shift_ge10 = int(np.sum(abs_shifts >= 10))

    print(f"  Matched main-sample sports: {n_matched}")
    print(f"  Spearman rho = {rho:.3f}, p = {p_val:.4f}")
    print(f"  Mean abs rank shift: {mean_abs_shift:.1f}")
    print(f"  Sports shifting >=5: {n_shift_ge5}, >=10: {n_shift_ge10}")

    return {
        'n_matched_sports': n_matched,
        'spearman_rho': round(rho, 3),
        'spearman_p': round(p_val, 4),
        'mean_abs_rank_shift': round(mean_abs_shift, 1),
        'n_shift_ge5': n_shift_ge5,
        'n_shift_ge10': n_shift_ge10,
        'shared_rank_variance_pct': round(rho**2 * 100, 1),
        'sports_compared': [(c[0], c[1], c[2]) for c in common],
    }


def main():
    rows = reg_rows

    results = {}

    results['A_aggregate_ladder'] = section_A_aggregate_ladder(rows)
    results['B_sport_type'] = section_B_sport_type(rows)
    results['C_facility'] = section_C_facility(rows)
    results['D_cost_gradient'] = section_D_cost_gradient(rows)
    results['E_horse_race'] = section_E_horse_race(rows)
    results['F_ggi'] = section_F_ggi(rows)
    results['G_robustness'] = section_G_robustness(rows)
    results['G77_gender'] = section_G77_gender_decomposition(rows)
    results['H_pop_elasticity'] = section_H_population_elasticity(rows)
    results['J_discussion'] = section_J_discussion_stats(rows)
    results['K_cost_classification'] = section_K_cost_classification_comparison()

    # Metadata
    results['metadata'] = {
        'version': 'v1.00',
        'specification': 'game-level panel, 2000-2024',
        'lag': 'ln(1 + points_{i,s,g-1})',
        'religion_vars': RELIGION_COLS,
        'reference_category': 'pct_other (secular/folk/Jewish/other)',
        'facility_cost': 'max-comp',
        'gdp_split': 'time-invariant, mean GDP across all games, >= median = upper',
        'n_total_rows': len(rows),
        'n_countries': len(GDP_AVG),
        'n_upper': len(UPPER_NOCS),
        'n_lower': len(LOWER_NOCS),
        'gdp_median': round(GDP_MEDIAN, 0),
        'upper_nocs': sorted(UPPER_NOCS),
        'lower_nocs': sorted(LOWER_NOCS),
        'games': sorted(set(r['game_year'] for r in rows)),
        'fixes_applied': [
            '#1: GDP split time-invariant, >= median, all 71 countries',
            '#2: Country-clustered SEs throughout',
            '#3: Pop elasticity uses ln(total) not ln(total+1), positive filter',
            '#4: Gender decomposition from pre-built panel columns',
            '#5: Positive-points filter documented at each application point',
            '#6: EFW switched from two-period averages to game-year-specific (Fraser Institute 2025 edition)',
            '#7: Team sport data corrected for 1992/1996 (scraper bug: pool standings -> final standings)',
        ],
    }

    # Save
    out_path = os.path.join(RESULTS_DIR, 'v106_game_level_results.json')
    with open(out_path, 'w') as f:
        json.dump(clean_for_json(results), f, indent=2, default=str)
    print(f"\n{'='*60}")
    print(f"  RESULTS SAVED: {out_path}")
    print(f"{'='*60}")


if __name__ == '__main__':
    main()
