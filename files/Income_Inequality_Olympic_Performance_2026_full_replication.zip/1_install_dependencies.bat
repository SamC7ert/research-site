@echo off
echo ============================================================
echo  Installing dependencies for replication package v1.06
echo ============================================================
echo.
pip install numpy pandas scipy statsmodels matplotlib adjustText
echo.
echo ============================================================
echo  Done. You can close this window or run 2_run_all.bat next.
echo ============================================================
echo.
cmd /k
