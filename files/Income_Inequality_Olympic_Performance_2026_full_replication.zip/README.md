# Replication Package

**Paper:** How Income Distribution and Sports Participation Cost Shape Olympic Performance
**Author:** Sam Carsten Syvertsen
**Version:** 1.06 (March 2026)
**License:** Data: CC-BY 4.0 | Code: MIT License

## Overview

This package contains all input data, analysis scripts, and output needed to reproduce the results in the paper. The analysis uses a game-level panel of Olympic performance (2000-2024) with country-level economic predictors and sport-level cost classifications.

## Requirements

Python 3.10+ with:

- numpy
- pandas
- scipy
- statsmodels
- matplotlib
- adjustText

Install with: `pip install numpy pandas scipy statsmodels matplotlib adjustText`

## Folder Structure

```
v1.06/
  README.md
  simulation_technical_appendix.md  <- full implementation spec for the microsimulation
  data/                   <- input data (JSON)
    events/               <- per-game event-level results (9 files, 1992-2024)
    v106_game_level_panel.json        <- main analysis panel (71 countries, 41 sports, 7 games)
    v106_sport_cost_classification.json  <- equipment and facility costs per sport
    v106_sport_properties.json        <- sport type, gender, event counts
    v106_predictors_master.json       <- GDP, Gini, population, religion, EFW
    v106_gdp_by_game_year.json        <- GDP per capita by country-year
    v106_gini_by_game_year.json       <- Gini coefficients by country-year
    v106_population_by_game_year.json <- population by country-year
    v106_efw_data.json                <- Economic Freedom of the World
    v106_region_classification.json   <- country-to-region mapping
    v106_religion_classification.json <- country religion shares
    v106_country_sport_panel_2period.json  <- two-period aggregated panel
    v106_sim_parameters.json          <- calibrated simulation parameters
    v106_experience_seed_data.json    <- 1992/1996 experience for persistence model
    v106_non_olympic_sport_drain.json <- non-Olympic sport talent drain fractions
    v091_sport_cost_classification.json   <- original cost classification (v0.91, for robustness)
  scripts/                <- analysis scripts
    v106_game_level_pipeline.py       <- main empirical analysis (Tables 1-4)
    v106_two_period_pipeline.py       <- two-period robustness
    v106_twoway_clustering.py         <- two-way clustered standard errors
    sim_v106_production.py            <- forward microsimulation (100 seeds, incl. US exclusion)
    v106_generate_figures.py          <- all paper figures (Figures 1-6)
  results_reference/      <- author's results (for comparison)
    v106_game_level_results.json
    v106_two_period_results.json
    v106_twoway_clustering.json
    simulation/
      v106_simulation_results.json
  figures_reference/      <- author's figures (for comparison)
    fig1_sport_cost_segmentation.png
    fig2_regional_gini_map.png
    fig3_per_sport_gini_scatter.png
    fig4_crossover_marginal_effect.png
    fig5_persistence_vs_facility.png
    fig6_population_elasticity.png
  results/                <- empty, filled by scripts
  figures/                <- empty, filled by scripts
```

## How to Reproduce

All scripts use relative paths and should be run from the `scripts/` directory.

```bash
cd v1.06/scripts
```

Steps 1-4 are independent and can be run in any order. Step 5 requires steps 1 and 4 to have completed.

### 1. Empirical analysis (Tables 1-4)

```bash
python v106_game_level_pipeline.py
```

Reads `data/v106_game_level_panel.json` and related predictor files. Writes results to `results/v106_game_level_results.json`. Runtime: under 1 minute.

### 2. Two-period robustness

```bash
python v106_two_period_pipeline.py
```

Reads `data/v106_country_sport_panel_2period.json`. Writes to `results/v106_two_period_results.json`. Runtime: under 1 minute.

### 3. Two-way clustering

```bash
python v106_twoway_clustering.py
```

Computes standard errors clustered by both country and sport. Runtime: under 1 minute.

### 4. Simulation (Section 7)

```bash
python sim_v106_production.py
```

Runs the forward microsimulation with 100 random seeds. Produces the all-countries gradient, the US-exclusion gradient (Section 7.3), and the four-way regression decomposition. Reads calibrated parameters from `data/v106_sim_parameters.json`. Writes to `results/simulation/v106_simulation_results.json`. Runtime: approximately 4 minutes.

### 5. Figures

```bash
python v106_generate_figures.py
```

Generates all six paper figures from the results files. Writes PNG files to `figures/`.

### 6. Compare

Your generated files in `results/` and `figures/` should match `results_reference/` and `figures_reference/`. Regression coefficients and sample sizes will be identical. Simulation results use fixed seeds and should match exactly.

## Data Sources

The input data are assembled from the following sources (see paper Section 2 for full details):

- Olympic results: Olympedia.org (2000-2024, top-6 scoring)
- Income inequality: World Bank Gini coefficients
- GDP per capita: World Bank (constant 2015 USD)
- Population: World Bank
- Equipment cost: Author classification based on national federation surveys and retail pricing (41 sports)
- Facility cost: Author classification based on construction cost databases
- Economic Freedom: Fraser Institute (EFW index)
- Religion: Pew Research Center (2000, 2010 surveys, interpolated)
- Regions: UN geoscheme

## Citation

If you use this data or code, please cite:

Syvertsen, S. C. (2026). How Income Distribution and Sports Participation Cost Shape Olympic Performance. Working paper.

## Contact

Sam Carsten Syvertsen -- research@syvertsen.com
Project page: https://research.syvertsen.com/projects/sport-cost-gradient/
