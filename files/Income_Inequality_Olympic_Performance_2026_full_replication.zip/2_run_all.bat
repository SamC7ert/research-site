@echo off
cd /d "%~dp0scripts"
echo ============================================================
echo  Replication package v1.06 — running all scripts
echo ============================================================

echo.
echo [1/5] Empirical analysis (Tables 1-4)...
echo ------------------------------------------------------------
python v106_game_level_pipeline.py
if errorlevel 1 goto :error

echo.
echo [2/5] Two-period robustness...
echo ------------------------------------------------------------
python v106_two_period_pipeline.py
if errorlevel 1 goto :error

echo.
echo [3/5] Two-way clustering...
echo ------------------------------------------------------------
python v106_twoway_clustering.py
if errorlevel 1 goto :error

echo.
echo [4/5] Simulation (100 seeds, ~4 min)...
echo ------------------------------------------------------------
python sim_v106_production.py
if errorlevel 1 goto :error

echo.
echo [5/5] Figures...
echo ------------------------------------------------------------
python v106_generate_figures.py
if errorlevel 1 goto :error

echo.
echo ============================================================
echo  All 5 scripts completed successfully.
echo  Results in: ..\results\
echo  Figures in: ..\figures\
echo  Compare against results_reference\ and figures_reference\
echo ============================================================
echo.
cmd /k
goto :eof

:error
echo.
echo ============================================================
echo  ERROR: Script failed. See output above.
echo ============================================================
echo.
cmd /k
