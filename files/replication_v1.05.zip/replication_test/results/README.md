# Test Replication Package
This is a test file with nonsensical data.
Real replication package will be available when paper is published on SSRN.

## Contents
- data/olympic_panel_test.csv — fake panel data
- scripts/run_analysis_test.py — placeholder script
- results/README.md — this file
